// Unit tests for the scoring rules. Run: node test/scoring.test.js
const assert = require('assert');
const { scoreMainRound, scoreCoordinates, haversineKm, scoreAuction, wartaLists } = require('../server/game/scoring');
const { Bank } = require('../server/game/bank');

let n = 0;
function t(name, fn) {
  fn();
  n++;
  console.log('  ✓', name);
}

const P = ['A', 'B', 'C', 'D'];

t('active correct: +2 and +1 per opponent who answered wrong; correct opponents +2', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 1, B: 1, C: 0, D: 3 }, participants: P });
  assert.deepStrictEqual(r.deltas, { A: 2 + 2, B: 2, C: 0, D: 0 });
});

t('active correct: players who did not answer do not count as wrong', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 1, B: 0 }, participants: P });
  assert.strictEqual(r.deltas.A, 3);
  assert.strictEqual(r.deltas.C, 0);
});

t('active wrong: 0 plus +1 per opponent who picked the same wrong option', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 2, B: 2, C: 2, D: 0 }, participants: P });
  assert.deepStrictEqual(r.deltas, { A: 2, B: 0, C: 0, D: 0 });
  assert.deepStrictEqual(r.victims.sort(), ['B', 'C']);
});

t('active wrong: opponents who answer correctly still get +2', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 2, B: 1, C: 2 }, participants: P });
  assert.deepStrictEqual(r.deltas, { A: 1, B: 2 + 1, C: 0, D: 0 }); // B is also الوحيد (+1)
});

t('active did not answer: 0 and no bonus', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { B: 0 }, participants: P });
  assert.deepStrictEqual(r.deltas, { A: 0, B: 0, C: 0, D: 0 });
});

t('اقنصه: target wrong → bettor +1, target −1; target right → bettor −1, target +1', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 1, B: 1, C: 0, D: 1 }, wartas: { B: 'C', C: 'D' }, participants: P });
  // A: +2 and +1 for C being wrong. B: +2, caught C +1. C: wrong 0, caught by B −1, D escaped C −1. D: +2, escaped +1.
  assert.deepStrictEqual(r.deltas, { A: 3, B: 3, C: -2, D: 3 });
  assert.deepStrictEqual(r.wartaResults, { B: 'caught', C: 'escaped' });
});

t('اقنصه: the asker can ورّط and be ورّط; no answer from the target = nothing', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 0, B: 1 }, wartas: { B: 'A', A: 'C' }, participants: P });
  assert.strictEqual(r.wartaResults.A, 'void');
  // B: +2 answer, +1 الوحيد, +1 caught A. A: 0 answer, −1 caught.
  assert.strictEqual(r.deltas.B, 4);
  assert.strictEqual(r.deltas.A, -1);
  assert.strictEqual(r.deltas.C, 0);
});

t('الوحيد: the only correct player (not the asker) gets +1 with 3+ players', () => {
  const r = scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 0, B: 0, C: 1, D: 2 }, participants: P });
  assert.strictEqual(r.loneId, 'C');
  assert.strictEqual(r.deltas.C, 3);
});

t('الوحيد: not for the asker, not when two are right, not in 2-player games', () => {
  assert.strictEqual(scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 1, B: 0, C: 0 }, participants: P }).loneId, null);
  assert.strictEqual(scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 1, B: 1, C: 0 }, participants: P }).loneId, null);
  assert.strictEqual(scoreMainRound({ activeId: 'A', correct: 1, answers: { A: 0, B: 1 }, participants: ['A', 'B'] }).loneId, null);
});

t('اقنصه lists: ≤3 names, never yourself, gap rule removes over-targeted players', () => {
  const ids = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  for (let k = 0; k < 200; k++) {
    const counts = { a: 0, b: 1, c: 2, d: 5, e: 0, f: 1, g: 0, h: 3 };
    const lists = wartaLists(ids, counts);
    for (const me of ids) {
      const l = lists[me];
      assert.ok(l.length >= 1 && l.length <= 3, `size ${l.length}`);
      assert.ok(!l.includes(me));
      for (const t of l) assert.ok(counts[t] < 2, `over-targeted ${t} shown`); // min is 0 → only 0 or 1 allowed
      assert.strictEqual(new Set(l).size, l.length);
    }
  }
});

t('اقنصه lists: 2 players always see each other; nobody appears in more than 2 lists', () => {
  const two = wartaLists(['a', 'b'], {});
  assert.deepStrictEqual(two, { a: ['b'], b: ['a'] });
  const ids = 'abcdefghij'.split('');
  let worst = 0;
  for (let k = 0; k < 300; k++) {
    const lists = wartaLists(ids, {});
    const shown = {};
    for (const l of Object.values(lists)) for (const t of l) shown[t] = (shown[t] || 0) + 1;
    worst = Math.max(worst, ...Object.values(shown));
  }
  assert.ok(worst <= 2, `a player appeared in ${worst} of 10 lists`);
});

t('haversine Amman→Riyadh ≈ 1,320 km', () => {
  const d = haversineKm({ lat: 31.95, lng: 35.93 }, { lat: 24.71, lng: 46.68 });
  assert.ok(d > 1250 && d < 1400, String(d));
});

t('coordinates: first inside wins +2, outside pins -1, inside-but-late 0', () => {
  const pins = { A: { distanceKm: 50 }, B: { distanceKm: 500 }, C: { distanceKm: 90 } };
  const r = scoreCoordinates({ pins, radiusKm: 100, winnerId: 'A' });
  assert.deepStrictEqual(r.deltas, { A: 2, B: -1, C: 0 });
});

t('coordinates: nobody inside → closest +2, the rest -1, no pin = not listed (0)', () => {
  const pins = { A: { distanceKm: 300 }, B: { distanceKm: 500 } };
  const r = scoreCoordinates({ pins, radiusKm: 100 });
  assert.deepStrictEqual(r.deltas, { A: 2, B: -1 });
});

t('auction: +1 per correct pick, −1 per wrong pick, duplicates ignored', () => {
  const r = scoreAuction({ selections: { A: [0, 1, 2], B: [0, 7, 8, 8], C: [] }, correct: [0, 1, 2, 3, 4] });
  assert.deepStrictEqual(r.deltas, { A: 3, B: -1, C: 0 });
});

t('auction instance always has 10 options: exactly 5 correct and 5 wrong', () => {
  const bank = new Bank();
  const item = { id: 'x', prompt: 'p', correct: ['a', 'b', 'c', 'd', 'e', 'f', 'g'], wrong: ['1', '2', '3', '4', '5', '6'] };
  for (let i = 0; i < 50; i++) {
    const a = bank.instantiateAuction(item);
    assert.strictEqual(a.options.length, 10);
    assert.strictEqual(new Set(a.options).size, 10);
    assert.strictEqual(a.correctIdx.length, 5);
    for (const k of a.correctIdx) assert.ok(item.correct.includes(a.options[k]));
  }
});

t('main question instance: N options (2–8), correct one always present and marked', () => {
  const bank = new Bank();
  const q = { id: 'q', options: ['ص', 'خ1', 'خ2', 'خ3', 'خ4', 'خ5', 'خ6', 'خ7'], answer: 0 };
  for (let n = 2; n <= 8; n++) {
    for (let i = 0; i < 20; i++) {
      const x = bank.instantiate(q, n);
      assert.strictEqual(x.options.length, n);
      assert.strictEqual(x.options[x.answer], 'ص');
      assert.strictEqual(new Set(x.options).size, n);
    }
  }
});

console.log(`scoring: ${n} tests passed`);
