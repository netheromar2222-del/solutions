// End-to-end simulation: real server + WebSocket bots playing full games at 20x speed.
// Run: node test/simulate.js
process.env.TT_TIME_SCALE = process.env.TT_TIME_SCALE || '0.05';
process.env.PORT = '0';
const assert = require('assert');
const WebSocket = require('ws');
const { server, rooms } = require('../server/index.js');
const coords = require('../server/data/bonus/coordinates.json');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rnd = (n) => Math.floor(Math.random() * n);

function bot(port, name, opts = {}) {
  const b = { name, state: null, phases: new Set(), bonusTypes: new Set(), errors: [], token: null, code: null, leaks: 0, opts };
  b.connect = () =>
    new Promise((resolve) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);
      b.ws = ws;
      ws.on('open', () => resolve());
      ws.on('message', (raw) => onMsg(b, JSON.parse(raw)));
    });
  b.send = (e, d = {}) => b.ws.readyState === 1 && b.ws.send(JSON.stringify({ e, d }));
  return b;
}

function onMsg(b, { e, d }) {
  if (e === 'joined') {
    b.token = d.token;
    b.code = d.code;
    b.id = d.playerId;
    // New flow: pick name + character inside the room (skip on rejoin: already set).
    if (!b.opts.noProfile && !b.profiled) {
      b.profiled = true;
      b.send('set_profile', { name: b.name });
    }
  }
  if (e === 'profile_error') b.profileErrors = (b.profileErrors || []).concat(d);
  if (e === 'left') b.leftReason = d.reason;
  if (e === 'error') b.errors.push(d.message);
  if (e === 'rejoin_failed') b.rejoinFailed = true;
  if (e !== 'state') return;
  b.state = d;
  b.phases.add(d.phase);
  if (d.question && 'answer' in d.question) b.leaks++;
  if (d.question) b.optionCounts = (b.optionCounts || new Set()).add(d.question.options.length);
  if (d.bonus && d.bonus.type === 'auction' && d.phase === 'BONUS_ROUND' && ('correctIdx' in d.bonus || 'correct' in d.bonus)) b.leaks++;
  if (d.bonus && d.phase === 'BONUS_ROUND' && ('answer' in d.bonus || 'target' in d.bonus)) b.leaks++;
  if (d.bonus) b.bonusTypes.add(d.bonus.type);
  if (d.phase === 'BONUS_ROUND' && d.bonus && !d.bonus.clockStarted) {
    const key = `${d.bonus.type}|${d.round}|${d.inTiebreak ? 't' : ''}`;
    b.bonusSeq = b.bonusSeq || [];
    if (b.bonusSeq[b.bonusSeq.length - 1] !== key) b.bonusSeq.push(key);
  }
  if (b.opts.passive) return;
  setTimeout(() => act(b, d), rnd(60));
}

function act(b, s) {
  if (b.state !== s) return; // stale
  if (s.phase === 'ROUND_SCORING' || s.phase === 'BONUS_RESULTS' || s.phase === 'STANDINGS') {
    // Non-controllers also press "next" — the server must ignore them.
    if (s.controllerId !== s.me) b.send('next');
    else setTimeout(() => b.state === s && b.send('next'), 80);
    return;
  }
  if (s.phase === 'TURN_SELECTION' && s.turn.activeId === s.me && Math.random() < 0.85) {
    // Two steps: a category, then a level (by its hint).
    if (!s.turn.category) b.send('select_category', { category: s.turn.categories[rnd(s.turn.categories.length)] });
    else if (s.turn.levels) {
      const avail = s.turn.levels.filter((l) => l.available);
      if (avail.length) b.send('select_level', { level: avail[rnd(avail.length)].level });
    }
  }
  if (s.phase === 'QUESTION_ACTIVE' && s.question.participant) {
    const q = s.question;
    if (q.myAnswer === null && Math.random() < 0.95) b.send('submit_answer', { option: rnd(q.options.length) });
    else if (q.myAnswer !== null && !q.wartaDone) {
      // "Gang" bots always go after the same victim when the list allows it.
      const victim = b.opts.victim && q.wartaTargets.find((id) => s.players.find((p) => p.id === id)?.name === b.opts.victim);
      const pick = victim || (Math.random() < 0.6 ? q.wartaTargets[rnd(q.wartaTargets.length)] : null);
      b.send('submit_warta', { targetId: pick ?? null });
      if (q.wartaTargets.some((id) => !s.players.find((p) => p.id === id))) b.leaks++; // sanity: unknown id
    }
  }
  if (s.phase === 'BONUS_ROUND' && s.bonus.clockStarted && s.bonus.eligible.includes(s.me)) {
    const bn = s.bonus;
    if (bn.type === 'auction') {
      if (!bn.myLocked && Math.random() < 0.7) {
        const picks = bn.options.map((_, i) => i).filter(() => Math.random() < 0.4);
        b.send('auction_select', { options: picks });
        setTimeout(() => b.send('auction_lock'), 40);
      }
    } else if (bn.type === 'coordinates') {
      if (!bn.myPin && Math.random() < 0.8) {
        // Some bots "know" the answer so both the exact-hit and closest-pin paths get exercised.
        const known = coords.find((c) => c.text === bn.text);
        if (known && Math.random() < 0.25) b.send('place_pin', { lat: known.target.lat + 0.3, lng: known.target.lng - 0.3 });
        else b.send('place_pin', { lat: 5 + Math.random() * 30, lng: -10 + Math.random() * 65 });
      }
    } else if (!bn.myAttempt && !bn.lockedOut.includes(s.me) && Math.random() < 0.6) {
      const open = bn.options.map((_, i) => i).filter((i) => !bn.disabled.includes(i));
      b.send('submit_bonus_answer', { option: open[rnd(open.length)] });
    }
  }
}

async function waitFor(fn, ms = 60000, label = 'condition') {
  const t0 = Date.now();
  while (!fn()) {
    if (Date.now() - t0 > ms) throw new Error(`timeout waiting for ${label}`);
    await sleep(20);
  }
}

async function fullGame(port, { players = 4, rounds = 8, extra = {}, botOpts = {} } = {}) {
  const host = bot(port, 'المضيف');
  await host.connect();
  host.send('create_room', { name: 'المضيف', avatar: '🦊' });
  await waitFor(() => host.state, 5000, 'room');
  host.send('update_settings', { rounds, questionTime: 20, maxPlayers: 20, ...extra });
  const others = [];
  for (let i = 1; i < players; i++) {
    const b = bot(port, `بوت${i}`, botOpts);
    await b.connect();
    b.send('join_room', { code: host.code, name: `بوت${i}` });
    others.push(b);
  }
  const all = [host, ...others];
  await waitFor(() => host.state.players.filter((p) => p.ready).length === players, 5000, 'joins');
  host.send('start_game');
  await waitFor(() => host.state.phase === 'GAME_OVER', 120000, 'game over');
  return { all, host };
}

(async () => {
  await new Promise((r) => (server.listening ? r() : server.once('listening', r)));
  const port = server.address().port;
  let checks = 0;
  const ok = (msg) => {
    checks++;
    console.log('  ✓', msg);
  };

  // 1) Several full games, checking invariants.
  for (const [players, rounds] of [
    [2, 4],
    [4, 8],
    [7, 9],
    [20, 6],
  ]) {
    const { all, host } = await fullGame(port, { players, rounds });
    const f = host.state.final;
    assert.strictEqual(host.state.round, rounds);
    assert.ok(all.every((b) => b.leaks === 0), 'answer leaked to a client');
    const top = Math.max(...host.state.players.map((p) => p.score));
    const leaders = host.state.players.filter((p) => p.score === top);
    assert.ok(leaders.length === 1 || f.tiebreaks === 10, 'game ended with a tie without tie-breaks');
    assert.deepStrictEqual(f.winners.sort(), leaders.map((p) => p.id).sort());
    for (const ph of ['TURN_SELECTION', 'QUESTION_ACTIVE', 'ROUND_SCORING', 'GAME_OVER']) assert.ok(host.phases.has(ph), ph);
    if (rounds >= 2) assert.ok(host.phases.has('BONUS_ROUND') && host.phases.has('BONUS_RESULTS'));
    ok(`${players} players × ${rounds} rounds → winner ${f.winners.length === 1 ? 'unique' : 'shared'}, tiebreaks=${f.tiebreaks}, bonus types seen: ${[...host.bonusTypes].join(',')}, badges=${f.badges.length}`);
    all.forEach((b) => b.ws.close());
  }

  // 2) All four bonus types appear in rotation within 8 rounds.
  {
    const { all, host } = await fullGame(port, { players: 3, rounds: 8 });
    assert.deepStrictEqual([...host.bonusTypes].sort(), ['auction', 'censored', 'coordinates', 'link', 'pixel'].filter((t) => host.bonusTypes.has(t)));
    for (const t of ['censored', 'coordinates', 'link', 'pixel']) assert.ok(host.bonusTypes.has(t), t);
    ok('all four speed mini-games rotate in');
    all.forEach((b) => b.ws.close());
  }

  // 2a) مزاد التعويض + 8 answer options
  {
    const { all, host } = await fullGame(port, { players: 4, rounds: 4, extra: { bonusTypes: ['link'], auctionEnabled: true, optionCount: 8 } });
    const seq = host.bonusSeq.filter((k) => !k.endsWith('t'));
    assert.deepStrictEqual(seq.map((k) => k.split('|')[0]), ['link', 'link', 'auction'], `order was ${host.bonusSeq}`);
    assert.ok(host.bonusSeq.slice(seq.length).every((k) => !k.startsWith('auction')), 'auction repeated in tie-breaks');
    assert.deepStrictEqual([...host.optionCounts], [8]);
    assert.ok(all.every((b) => b.leaks === 0), 'auction answers leaked');
    ok(`auction is the very last question, once (sequence: ${host.bonusSeq.join(' → ')}); 8-option questions`);
    all.forEach((b) => b.ws.close());
    const g = await fullGame(port, { players: 2, rounds: 2, extra: { optionCount: 2, auctionEnabled: false } });
    assert.deepStrictEqual([...g.host.optionCounts], [2]);
    assert.ok(!g.host.bonusTypes.has('auction'));
    ok('2-option questions work and the auction can be switched off');
    g.all.forEach((b) => b.ws.close());
  }

  // 2c) اقنصه balance: every bot tries to target the same player whenever it can
  {
    const { all, host } = await fullGame(port, { players: 8, rounds: 16, extra: { bonusTypes: [], auctionEnabled: false, questionTime: 20 }, botOpts: { victim: 'المضيف' } });
    // The room tracks how often each player was picked; read it from the server object.
    const room = [...rooms.values()].find((r) => r.code === host.code);
    const counts = [...room.players.values()].map((p) => ({ name: p.name, n: p.timesTargeted }));
    const victim = counts.find((c) => c.name === 'المضيف').n;
    const others = counts.filter((c) => c.name !== 'المضيف').map((c) => c.n);
    const avg = others.reduce((a, b) => a + b, 0) / others.length;
    assert.ok(victim <= Math.max(...others) + 3, `victim targeted ${victim} times vs others ${others}`);
    ok(`اقنصه stays spread out even when 7 players gang up on one: target ${victim}× vs others avg ${avg.toFixed(1)} (max ${Math.max(...others)})`);
    all.forEach((b) => b.ws.close());
  }

  // 2b) Host settings: bluffing off, chosen bonus types only, or none at all
  {
    const { all, host } = await fullGame(port, { players: 3, rounds: 8, extra: { wartaEnabled: false, bonusTypes: ['link', 'censored'], auctionEnabled: false } });
    assert.deepStrictEqual([...host.bonusTypes].sort(), ['censored', 'link']);
    assert.ok(all.every((b) => !b.state.final.badges.some((x) => x.key === 'warta_master' || x.key === 'failed_gambler' || x.key === 'survivor')), 'اقنصه points appeared while disabled');
    ok('اقنصه can be switched off and only the chosen bonus types appear');
    all.forEach((b) => b.ws.close());
    const g2 = await fullGame(port, { players: 3, rounds: 6, extra: { bonusTypes: [], auctionEnabled: false } });
    assert.ok(!g2.host.phases.has('BONUS_ROUND') || g2.host.state.final.tiebreaks > 0, 'bonus round ran with none selected');
    ok('no bonus rounds when the host selects none');
    g2.all.forEach((b) => b.ws.close());
  }

  // 3) Reconnect keeps seat & score; permanent drop gets removed; host leaving transfers host.
  {
    const host = bot(port, 'المضيف');
    await host.connect();
    host.send('create_room', { name: 'المضيف' });
    await waitFor(() => host.state, 5000);
    host.send('update_settings', { rounds: 30, questionTime: 20 });
    const a = bot(port, 'أ');
    const c = bot(port, 'ج');
    const d = bot(port, 'د');
    for (const b of [a, c, d]) {
      await b.connect();
      b.send('join_room', { code: host.code, name: b.name });
    }
    await waitFor(() => host.state.players.filter((p) => p.ready).length === 4, 5000);
    host.send('start_game');
    await waitFor(() => host.state.round >= 3, 30000, 'round 3');

    // a drops and comes back within the grace period
    const scoreBefore = host.state.players.find((p) => p.id === a.id).score;
    a.ws.terminate();
    await waitFor(() => host.state.players.find((p) => p.id === a.id).connected === false, 5000, 'a offline');
    await a.connect();
    a.send('rejoin', { code: a.code, token: a.token });
    await waitFor(() => a.state && a.state.me === a.id && host.state.players.find((p) => p.id === a.id).connected, 5000, 'a back');
    const after = host.state.players.find((p) => p.id === a.id);
    assert.ok(!after.removed && after.score >= scoreBefore - 3);
    ok('player reconnects to the same seat with their score');

    // c drops for good → removed after grace (60s × 0.05 = 3s), game keeps going
    c.ws.terminate();
    await waitFor(() => host.state.players.find((p) => p.id === c.id).removed, 10000, 'c removed');
    const r0 = host.state.round;
    await waitFor(() => host.state.round > r0 + 1 || host.state.phase === 'GAME_OVER', 30000, 'game continues');
    ok('dropped player is removed after the grace period and the game continues');

    // c tries to come back after removal → rejected
    await c.connect();
    c.send('rejoin', { code: c.code, token: c.token });
    await waitFor(() => c.rejoinFailed, 5000, 'rejoin rejected');
    ok('rejoin after the grace period is refused');

    // host leaves → oldest remaining player becomes host
    host.send('leave');
    await waitFor(() => a.state.hostId !== host.id, 5000, 'host transfer');
    assert.strictEqual(a.state.hostId, a.id);
    ok('host leaving hands the room to the oldest player');

    // d leaves too → fewer than 2 players → game ends
    d.send('leave');
    await waitFor(() => a.state.phase === 'GAME_OVER', 5000, 'end with 1 player');
    ok('game ends when fewer than two players remain');
    [host, a, c, d].forEach((b) => b.ws.close());
  }

  // 4) Only the host advances the results screen
  {
    const h = bot(port, 'h');
    const g = bot(port, 'g', { passive: true });
    await h.connect();
    h.opts.passive = true;
    h.send('create_room', { name: 'h' });
    await waitFor(() => h.state, 5000);
    h.send('update_settings', { rounds: 3, questionTime: 5, selectionTime: 60 });
    await g.connect();
    g.send('join_room', { code: h.code, name: 'g' });
    await waitFor(() => h.state.players.filter((p) => p.ready).length === 2, 5000);
    assert.strictEqual(h.state.settings.selectionTime, 60);
    h.send('start_game');
    await waitFor(() => h.state.phase === 'ROUND_SCORING', 20000, 'results');
    await sleep(1500);
    g.send('next');
    await sleep(300);
    assert.strictEqual(h.state.phase, 'ROUND_SCORING', 'results advanced without the host');
    assert.ok(h.state.results.before, 'results carry previous scores');
    h.send('next');
    await waitFor(() => h.state.phase === 'STANDINGS', 3000, 'standings page');
    assert.ok(h.state.standings && h.state.standings.from === 'round');
    assert.ok(h.state.endsAt, 'standings should have a countdown');
    // Standings move on by themselves (5 s × test speed-up)
    await waitFor(() => h.state.phase === 'TURN_SELECTION', 3000, 'standings auto-advance');
    const asker = h.state.turn.activeId === h.id ? h : g;
    const other = asker === h ? g : h;
    assert.strictEqual(other.state.turn.categories.length, 3, 'everyone sees the 3 categories on offer');
    assert.strictEqual(other.state.turn.category, null);
    assert.strictEqual(other.state.turn.levels, null);
    const cat = asker.state.turn.categories[1];
    asker.send('select_category', { category: cat });
    await waitFor(() => other.state.turn && other.state.turn.category === cat, 3000, 'category shown to everyone');
    assert.strictEqual(other.state.turn.levels.length, 3);
    assert.ok(other.state.turn.levels.every((l) => l.hint === null), 'hints must stay with the asker');
    await waitFor(() => asker.state.turn && asker.state.turn.levels, 3000);
    const lv = asker.state.turn.levels;
    assert.ok(lv.filter((l) => l.available).every((l) => typeof l.hint === 'string' && l.hint.length > 0), 'asker sees a hint per level');
    assert.ok(!JSON.stringify(other.state.turn).includes('"text"') && !JSON.stringify(asker.state.turn).includes('"text"'), 'no question text before the pick');
    asker.send('select_category', { category: asker.state.turn.categories[0] }); // a second pick must be ignored
    await sleep(100);
    assert.strictEqual(asker.state.turn.category, cat, 'category can only be picked once');
    const want = lv.find((l) => l.available).level;
    asker.send('select_level', { level: want });
    await waitFor(() => other.state.phase === 'QUESTION_ACTIVE', 3000, 'question after the level pick');
    assert.strictEqual(other.state.question.category, cat);
    assert.strictEqual(other.state.question.difficulty, want);
    ok('details wait for the host; standings auto-advance; category → level with hints for the asker only');
    h.ws.close();
    g.ws.close();
  }

  // 4a) Device memory: a question the players have already seen is avoided while unseen ones remain
  {
    const { Bank, seenKey } = require('../server/game/bank');
    const bank = new Bank();
    const pool = bank.questions.filter((q) => q.category === 'history' && q.difficulty === 1);
    const target = pool[Math.floor(pool.length / 2)];
    const keys = pool.filter((q) => q !== target).map((q) => seenKey(q.id));
    const h = bot(port, 'h', { passive: true });
    const g = bot(port, 'g', { passive: true });
    await h.connect();
    h.send('create_room', { name: 'h' });
    await waitFor(() => h.state, 5000);
    h.send('update_settings', { categories: ['history'], rounds: 2, questionTime: 5, selectionTime: 60 });
    await g.connect();
    g.send('join_room', { code: h.code, name: 'g' });
    await waitFor(() => h.state.players.filter((p) => p.ready).length === 2, 5000);
    for (const b of [h, g]) for (let i = 0; i < keys.length; i += 1200) b.send('seen', { keys: keys.slice(i, i + 1200), first: i === 0 });
    const seenFx = [];
    h.ws.on('message', (raw) => {
      const m = JSON.parse(raw);
      if (m.e === 'fx' && m.d.type === 'seen') seenFx.push(m.d.key);
    });
    await sleep(200);
    h.send('start_game');
    await waitFor(() => h.state.phase === 'TURN_SELECTION' && h.state.turn.levels, 5000, 'levels (single category)');
    const asker = h.state.turn.activeId === h.id ? h : g;
    await waitFor(() => asker.state.turn && asker.state.turn.levels, 3000);
    asker.send('select_level', { level: 1 });
    await waitFor(() => h.state.phase === 'QUESTION_ACTIVE', 3000, 'question');
    assert.strictEqual(h.state.question.text, target.text, 'the only unseen سالكة question should be picked');
    await sleep(100);
    assert.ok(seenFx.includes(seenKey(target.id)), 'devices are told to remember the question');
    ok('device memory: unseen questions come first, and shown questions are remembered on every device');
    h.ws.close();
    g.ws.close();
  }

  // 4b) Names and characters are unique inside a room; unfinished seats miss the start
  {
    const h = bot(port, 'أحمد');
    await h.connect();
    h.send('create_room', {});
    await waitFor(() => h.state && h.state.players.some((p) => p.ready), 5000, 'host ready');
    const hostAvatar = h.state.players.find((p) => p.id === h.id).avatar;
    const g = bot(port, 'x', { noProfile: true, passive: true });
    await g.connect();
    g.send('join_room', { code: h.code });
    await waitFor(() => g.state, 5000);
    assert.ok(!g.state.players.find((p) => p.id === g.id).ready, 'should start unready');
    g.send('set_profile', { name: '  احمـد ' });
    await waitFor(() => (g.profileErrors || []).length === 1, 3000, 'name clash');
    assert.strictEqual(g.profileErrors[0].field, 'name');
    g.send('set_profile', { name: 'سعيد', avatar: hostAvatar });
    await waitFor(() => (g.profileErrors || []).length === 2, 3000, 'avatar clash');
    assert.strictEqual(g.profileErrors[1].field, 'avatar');
    g.send('set_profile', { name: 'سعيد', avatar: hostAvatar === '🦊' ? '🐫' : '🦊' });
    await waitFor(() => g.state.players.find((p) => p.id === g.id).ready, 3000, 'g ready');
    ok('duplicate names (أحمد / احمـد) and taken characters are refused inside the room');
    const late = bot(port, 'late', { noProfile: true, passive: true });
    await late.connect();
    late.send('join_room', { code: h.code });
    await waitFor(() => late.state, 5000);
    h.send('start_game');
    await waitFor(() => late.leftReason === 'started', 5000, 'pending removed');
    await waitFor(() => h.state.phase !== 'LOBBY', 5000);
    assert.strictEqual(h.state.players.length, 2);
    ok('a player still choosing when the host starts is left out with a clear message');
    [h, g, late].forEach((b) => b.ws.close());
  }

  // 4c) Auto rounds: 2 turns per ready player until the host picks a number
  {
    const h = bot(port, 'h1', { passive: true });
    await h.connect();
    h.send('create_room', {});
    await waitFor(() => h.state && h.state.players.some((p) => p.ready), 5000);
    assert.strictEqual(h.state.settings.selectionTime, 20);
    assert.strictEqual(h.state.settings.questionTime, 30);
    assert.strictEqual(h.state.settings.maxPlayers, 8);
    assert.ok(h.state.settings.roundsAuto && h.state.settings.rounds === 2);
    const gs = [];
    for (const n of ['g1', 'g2']) {
      const g = bot(port, n, { passive: true });
      await g.connect();
      g.send('join_room', { code: h.code });
      gs.push(g);
    }
    await waitFor(() => h.state.settings.rounds === 6, 5000, 'auto = 2 × 3');
    h.send('update_settings', { rounds: 7 });
    await waitFor(() => h.state.settings.rounds === 7 && !h.state.settings.roundsAuto, 3000);
    const g3 = bot(port, 'g3', { passive: true });
    await g3.connect();
    g3.send('join_room', { code: h.code });
    await waitFor(() => h.state.players.filter((p) => p.ready).length === 4, 5000);
    assert.strictEqual(h.state.settings.rounds, 7, 'manual rounds must not change');
    h.send('update_settings', { roundsAuto: true });
    await waitFor(() => h.state.settings.rounds === 8, 3000, 'back to auto');
    ok('defaults (choose 20s, question 30s, 8 players) and auto rounds = 2 per player; a manual number sticks');
    [h, g3, ...gs].forEach((b) => b.ws.close());
  }

  // 4d) Late arrival watches as a spectator, then joins the next game; highlights + reactions
  {
    const { all, host } = await (async () => {
      const h = bot(port, 'م1');
      await h.connect();
      h.send('create_room', {});
      await waitFor(() => h.state && h.state.players.some((p) => p.ready), 5000);
      h.send('update_settings', { rounds: 4, bonusTypes: [], auctionEnabled: false });
      const g = bot(port, 'م2');
      await g.connect();
      g.send('join_room', { code: h.code });
      await waitFor(() => h.state.players.filter((p) => p.ready).length === 2, 5000);
      h.send('start_game');
      await waitFor(() => h.state.phase !== 'LOBBY', 5000);
      return { all: [h, g], host: h };
    })();
    const late = bot(port, 'متأخر', { passive: true });
    await late.connect();
    late.send('join_room', { code: host.code });
    await waitFor(() => late.state && late.state.players.find((p) => p.id === late.id)?.ready, 5000, 'spectator profile');
    const meSeat = late.state.players.find((p) => p.id === late.id);
    assert.ok(meSeat.spectator, 'late arrival should be a spectator');
    await waitFor(() => late.state.phase === 'QUESTION_ACTIVE', 30000, 'spectator sees a question');
    assert.strictEqual(late.state.question.participant, false);
    late.send('submit_answer', { option: 0 });
    let reactions = 0;
    host.ws.on('message', (raw) => {
      const m = JSON.parse(raw);
      if (m.e === 'fx' && m.d.type === 'reaction') reactions++;
    });
    late.send('react', { emoji: '😂' });
    late.send('react', { emoji: '😂' }); // rate-limited
    await waitFor(() => host.state.phase === 'GAME_OVER', 60000, 'game over');
    await sleep(200);
    assert.strictEqual(reactions, 1, 'reactions relayed once (rate limit)');
    assert.ok(!host.state.final.ranking.some((r) => r.id === late.id), 'spectator not ranked');
    assert.ok(Array.isArray(host.state.final.highlights) && host.state.final.highlights.length <= 3);
    // Moments cards: only the host moves everyone on (no auto-advance)
    const nMoments = host.state.final.highlights.length;
    assert.strictEqual(host.state.final.moment, 0);
    await sleep(400);
    all[1].send('next');
    await sleep(200);
    assert.strictEqual(host.state.final.moment, 0, 'a guest moved the moments on');
    for (let k = 0; k < nMoments; k++) host.send('next');
    await waitFor(() => host.state.final.moment === nMoments && all[1].state.final.moment === nMoments, 3000, 'moments stepped by host');
    host.send('play_again');
    await waitFor(() => host.state.phase === 'LOBBY', 5000);
    assert.ok(!host.state.players.find((p) => p.id === late.id).spectator, 'joins the next game');
    ok(`late arrival watches as a spectator and joins the next game; reactions relay; ${host.state.final ? '' : ''}highlights built`);
    [...all, late].forEach((b) => b.ws.close());
  }

  // 5) Lobby validation
  {
    const h = bot(port, 'h');
    await h.connect();
    h.send('create_room', { name: 'h' });
    await waitFor(() => h.state, 5000);
    h.send('start_game');
    await waitFor(() => h.errors.length, 3000, 'start error');
    h.send('update_settings', { maxPlayers: 99, rounds: 0, questionTime: 1, categories: ['nope'] });
    await sleep(100);
    const s = h.state.settings;
    assert.strictEqual(s.maxPlayers, 20);
    assert.strictEqual(s.rounds, 1);
    assert.strictEqual(s.questionTime, 5);
    assert.ok(s.categories.length > 0);
    const x = bot(port, 'x');
    await x.connect();
    x.send('join_room', { code: 'ZZZZZ', name: 'x' });
    await waitFor(() => x.errors.length, 3000);
    ok('lobby rejects bad settings, solo start and unknown room codes');
    h.ws.close();
    x.ws.close();
  }

  console.log(`simulation: ${checks} checks passed`);
  server.close();
  for (const r of rooms.values()) r.clearTimers();
  process.exit(0);
})().catch((e) => {
  console.error('FAILED:', e);
  process.exit(1);
});
