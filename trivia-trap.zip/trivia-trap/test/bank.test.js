// Question bank: file format, hint rules, Excel round trip, and the category → level picker.
const assert = require('assert');
const { rowToQuestion, validateRows, containsPhrase, HEADER } = require('../tools/bank-format');
const { readXlsx, writeXlsx } = require('../tools/xlsx');
const { Bank } = require('../server/game/bank');

let n = 0;
function t(name, fn) {
  fn();
  n++;
  console.log('  ✓', name);
}
const row = (over = {}) => {
  const r = ['تاريخ', 'ورطة', 'عن تأسيس مدينة عباسية شهيرة', 'من الخليفة العباسي الذي بنى بغداد؟', 'أبو جعفر المنصور', 'هارون الرشيد', 'المأمون', 'المعتصم', 'السفاح', 'المهدي', 'الأمين', 'المتوكل'];
  for (const [k, v] of Object.entries(over)) r[k] = v;
  return r;
};

t('a good row becomes a question with the correct answer first', () => {
  const r = rowToQuestion(row(), 2);
  assert.deepStrictEqual(r.errors, []);
  assert.strictEqual(r.question.level, 'warta');
  assert.strictEqual(r.question.category, 'history');
  assert.strictEqual(r.question.options[r.question.answer], 'أبو جعفر المنصور');
  assert.strictEqual(r.question.options.length, 8);
});

t('hint that reveals the answer or an option is rejected (Arabic-insensitive, whole words)', () => {
  assert.ok(rowToQuestion(row({ 2: 'عن ابو جعفر المنصور' }), 2).errors.some((e) => e.includes('يكشف الإجابة')));
  assert.ok(rowToQuestion(row({ 2: 'عن عصر هارون الرشيد' }), 2).errors.some((e) => e.includes('يحتوي خياراً')));
  assert.ok(containsPhrase('عن والكذب', 'الكذب'));
  assert.ok(!containsPhrase('عن واحد من الصحابة', 'أحد'), 'must not match inside another word');
});

t('levels accept سالكة/مطب/مطبّ/ورطة and سهل/متوسط/صعب; unknown values are rejected', () => {
  for (const [v, k] of [['سالكة', 'salka'], ['مطب', 'matab'], ['مطبّ', 'matab'], ['ورطة', 'warta'], ['صعب', 'warta'], ['سهل', 'salka']])
    assert.strictEqual(rowToQuestion(row({ 1: v }), 2).question.level, k, v);
  assert.ok(rowToQuestion(row({ 1: 'فخ' }), 2).errors.length);
  assert.ok(rowToQuestion(row({ 0: 'رياضيات' }), 2).errors.length);
});

t('too few wrong options, duplicates and long hints are rejected; fewer than 7 wrong is a warning', () => {
  assert.ok(rowToQuestion(row({ 7: '', 8: '', 9: '', 10: '', 11: '', 6: '' }), 2).errors.length);
  assert.ok(rowToQuestion(row({ 6: 'هارون الرشيد' }), 2).errors.some((e) => e.includes('مكرر')));
  assert.ok(rowToQuestion(row({ 6: 'أبو جعفر المنصور' }), 2).errors.some((e) => e.includes('مطابق للإجابة')));
  assert.ok(rowToQuestion(row({ 2: 'عن '.repeat(25) }), 2).errors.some((e) => e.includes('طويل')));
  const few = rowToQuestion(row({ 9: '', 10: '', 11: '' }), 2);
  assert.deepStrictEqual(few.errors, []);
  assert.ok(few.warnings.length);
});

t('duplicate questions in one file are rejected', () => {
  const v = validateRows([HEADER, row(), row({ 2: 'عن مدينة عباسية' })]);
  assert.strictEqual(v.questions.length, 1);
  assert.ok(v.results[1].errors.some((e) => e.includes('مكرر')));
});

t('Excel round trip keeps Arabic text exactly', () => {
  const buf = writeXlsx([{ name: 'الأسئلة', rows: [HEADER, row()], header: true }]);
  const back = readXlsx(buf)['الأسئلة'];
  assert.deepStrictEqual(back[1], row());
});

t('the shipped bank: every question has a level and a valid hint', () => {
  const bank = new Bank();
  assert.ok(bank.questions.length > 0);
  for (const q of bank.questions) {
    assert.ok([1, 2, 3].includes(q.difficulty), q.id);
    assert.ok(q.hint && !containsPhrase(q.hint, q.options[q.answer]), `${q.id} hint`);
  }
});

t('picker: ≤3 categories from the host selection, then one question per level of that category', () => {
  const bank = new Bank();
  const used = new Set();
  for (let i = 0; i < 50; i++) {
    const cats = bank.pickCategories(['history', 'quran', 'science', 'sports', 'general'], used);
    assert.strictEqual(cats.length, 3);
    assert.strictEqual(new Set(cats).size, 3);
    const lv = bank.levelCards(cats[0], used);
    assert.strictEqual(lv.length, 3);
    lv.forEach((q, k) => {
      assert.strictEqual(q.category, cats[0]);
      assert.strictEqual(q.difficulty, k + 1);
    });
  }
  assert.deepStrictEqual(bank.pickCategories(['history'], used), ['history']);
  assert.strictEqual(bank.pickCategories(['history', 'quran'], used).length, 2);
});

t('picker: a category whose questions are all used comes last and its levels are recycled', () => {
  const bank = new Bank();
  const used = new Set(bank.questions.filter((q) => q.category === 'history').map((q) => q.id));
  for (let i = 0; i < 20; i++) assert.notStrictEqual(bank.pickCategories(['history', 'quran', 'science', 'sports'], used)[0], 'history');
  assert.ok(bank.levelCards('history', used).every(Boolean), 'used-up levels recycle');
});

t('least-seen picking: unseen first, then the one seen longest ago', () => {
  const { leastSeen, seenKey } = require('../server/game/bank');
  const items = [{ id: 'a' }, { id: 'b' }, { id: 'c' }];
  const score = { a: 1.9, b: 1.2, c: 0 };
  for (let i = 0; i < 20; i++) assert.strictEqual(leastSeen(items, (id) => score[id]).id, 'c');
  score.c = 1.5;
  for (let i = 0; i < 20; i++) assert.strictEqual(leastSeen(items, (id) => score[id]).id, 'b');
  assert.strictEqual(seenKey('q_history_1234abcd'), seenKey('q_history_1234abcd'));
  assert.ok(seenKey('x').length <= 12);
});

console.log(`bank: ${n} tests passed`);
