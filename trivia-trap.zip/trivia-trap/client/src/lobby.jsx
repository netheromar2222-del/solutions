import WORDMARK from '../../public/brand/wordmark-for-dark-bg.svg';
import { ActionBar } from './actionbar';
import { useEffect, useRef, useState } from 'react';
import { net, profile } from './net';
import { play, unlockAudio } from './sound';
import { BONUS_INFO, CAT_LABEL } from './ui';

const BONUS_ORDER = ['coordinates', 'pixel', 'link', 'censored'];

const AVATARS = ['🦊', '🐫', '🦅', '🐢', '🦁', '🐙', '🦉', '🐬', '🦜', '🐝', '🦔', '🐼', '🦩', '🐸', '🐯', '🐧', '🦓', '🐳', '🦚', '🐞'];

// ---- host settings memory (per browser) ----
const HOST_KEY = 'tt_host_settings';
let applySavedOnce = false;
function loadHostSettings() {
  try {
    return JSON.parse(localStorage.getItem(HOST_KEY));
  } catch {
    return null;
  }
}
function saveHostSettings(s) {
  try {
    const { categories, rounds, roundsAuto, maxPlayers, questionTime, selectionTime, optionCount, bonusTypes, wartaEnabled, auctionEnabled } = s;
    localStorage.setItem(
      HOST_KEY,
      JSON.stringify({ categories, rounds, roundsAuto, maxPlayers, questionTime, selectionTime, optionCount, bonusTypes, wartaEnabled, auctionEnabled }),
    );
  } catch {}
}

export function Home({ error, initialCode }) {
  const [code, setCode] = useState(initialCode || '');
  const [mode, setMode] = useState(initialCode ? 'join' : 'start');
  const [busy, setBusy] = useState(false);
  const autoJoined = useRef(false);

  useEffect(() => {
    if (error) setBusy(false);
  }, [error]);

  const go = (event, extra = {}) => {
    unlockAudio();
    play('tap');
    setBusy(true);
    net.send(event, extra);
  };

  // Opening a room link goes straight in; the name/character step happens inside the room.
  useEffect(() => {
    if (initialCode && initialCode.length === 5 && !autoJoined.current && !error) {
      autoJoined.current = true;
      setBusy(true);
      net.send('join_room', { code: initialCode });
    }
  }, [initialCode]);

  return (
    <main className="home">
      <header className="hero">
        <h1 className="logo" aria-label="ورطة" dangerouslySetInnerHTML={{ __html: WORDMARK }} />
        <p className="slogan">إذا وقعت… اسحبهم معك</p>
        <p className="tagline">اختر سؤالك بذكاء: الصعب يربحك أكثر إن عرفته، وإن أخطأت فاسحب الآخرين معك.</p>
      </header>

      <section className="card form" aria-label="ابدأ">
        {mode === 'start' ? (
          <div className="actions">
            <button
              className="btn btn-primary btn-big"
              disabled={busy}
              onClick={() => {
                applySavedOnce = true;
                go('create_room');
              }}
            >
              إنشاء غرفة
            </button>
            <button className="btn btn-ghost" onClick={() => setMode('join')}>
              عندي رمز غرفة
            </button>
          </div>
        ) : (
          <form
            className="actions"
            onSubmit={(e) => {
              e.preventDefault();
              if (code.trim().length === 5) go('join_room', { code: code.trim().toUpperCase() });
            }}
          >
            <label className="field">
              <span>رمز الغرفة</span>
              <input
                className="code-input"
                value={code}
                maxLength={5}
                dir="ltr"
                inputMode="text"
                autoCapitalize="characters"
                autoFocus
                onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))}
                placeholder="ABCDE"
              />
            </label>
            <button className="btn btn-primary btn-big" disabled={code.length !== 5 || busy}>
              انضمام
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => setMode('start')}>
              إنشاء غرفة جديدة بدلاً من ذلك
            </button>
          </form>
        )}
        {error && <p className="error" role="alert">{error}</p>}
        <p className="hint">ستختار اسمك وشخصيتك داخل الغرفة، حتى لا يتكرر اسم أو شخصية.</p>
      </section>
    </main>
  );
}

/** Name + character, chosen inside the room so duplicates are visible and blocked. */
export function ProfilePicker({ state }) {
  const avatars = state.avatars || AVATARS;
  const others = state.players.filter((p) => !p.removed && p.ready && p.id !== state.me);
  const takenBy = Object.fromEntries(others.map((p) => [p.avatar, p.name]));
  const saved = profile.get();
  const [name, setName] = useState(saved.name || '');
  const [avatar, setAvatar] = useState(() => {
    if (saved.avatar && avatars.includes(saved.avatar) && !takenBy[saved.avatar]) return saved.avatar;
    const free = avatars.filter((a) => !takenBy[a]);
    return free[Math.floor(Math.random() * free.length)] || null;
  });
  const [err, setErr] = useState({});
  const [busy, setBusy] = useState(false);

  // If someone grabs my character while I'm still choosing, move me to a free one.
  useEffect(() => {
    if (avatar && takenBy[avatar]) {
      setAvatar(avatars.find((a) => !takenBy[a]) || null);
      setErr((e) => ({ ...e, avatar: `أخذ ${takenBy[avatar]} هذه الشخصية للتو، اخترنا لك غيرها.` }));
    }
  }, [state.players]);

  useEffect(
    () =>
      net.on((e, d) => {
        if (e === 'profile_error') {
          setBusy(false);
          setErr({ [d.field]: d.message });
        }
      }),
    [],
  );

  const key = (n) =>
    String(n || '')
      .normalize('NFKC')
      .replace(/[ً-ٰٟـ]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/\s+/g, '')
      .toLowerCase();
  const clash = name.trim() && others.find((p) => key(p.name) === key(name));
  const nameErr = clash ? `«${clash.name}» موجود في الغرفة، اختر اسماً آخر.` : err.name;
  const canGo = name.trim() && avatar && !clash && !busy;

  const submit = (e) => {
    e.preventDefault();
    if (!canGo) return;
    unlockAudio();
    play('join');
    setBusy(true);
    setErr({});
    profile.set({ name: name.trim(), avatar });
    net.send('set_profile', { name: name.trim(), avatar });
  };

  return (
    <main className="lobby">
      <section className="room-code card">
        <span className="muted">رمز الغرفة</span>
        <strong dir="ltr">{state.code}</strong>
      </section>
      <form className="card form" onSubmit={submit} aria-label="اسمك وشخصيتك">
        <h2>اختر اسمك وشخصيتك</h2>
        {state.phase !== 'LOBBY' && <p className="hint">👀 اللعبة جارية الآن: ستشاهدها، ثم تدخل اللعبة القادمة تلقائياً.</p>}
        <label className="field">
          <span>اسمك في اللعبة</span>
          <input
            value={name}
            maxLength={18}
            autoFocus={!name}
            onChange={(e) => {
              setName(e.target.value);
              setErr((x) => ({ ...x, name: undefined }));
            }}
            placeholder="مثلاً: أبو فهد"
            autoComplete="nickname"
            aria-invalid={!!nameErr}
          />
          {nameErr && <small className="field-error">{nameErr}</small>}
        </label>
        <div className="field">
          <span>شخصيتك {others.length > 0 && <small className="muted">(الباهتة مأخوذة)</small>}</span>
          <div className="avatar-grid" role="radiogroup" aria-label="الشخصية">
            {avatars.map((a) => {
              const owner = takenBy[a];
              return (
                <button
                  key={a}
                  type="button"
                  role="radio"
                  aria-checked={a === avatar}
                  aria-label={owner ? `${a} مأخوذة: ${owner}` : a}
                  disabled={!!owner}
                  className={`${a === avatar ? 'sel' : ''} ${owner ? 'taken' : ''}`}
                  onClick={() => {
                    setAvatar(a);
                    setErr((x) => ({ ...x, avatar: undefined }));
                  }}
                >
                  <span className="av-emoji">{a}</span>
                  {owner && <small className="av-owner">{owner}</small>}
                </button>
              );
            })}
          </div>
          {err.avatar && <small className="field-error">{err.avatar}</small>}
        </div>
        <ActionBar>
          <button className="btn btn-primary btn-big" disabled={!canGo} onClick={submit}>
            {avatar ? `${avatar} ` : ''}
            {state.phase !== 'LOBBY' ? 'دخول كمشاهد' : 'دخول الغرفة'}
          </button>
          <button type="button" className="btn btn-ghost btn-small" onClick={() => net.send('leave')}>
            مغادرة
          </button>
        </ActionBar>
      </form>
    </main>
  );
}

function Stepper({ value, min, max, step = 1, onChange, disabled, suffix }) {
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value]);
  const commit = (v) => {
    const n = Math.max(min, Math.min(max, parseInt(v, 10) || min));
    setDraft(String(n));
    if (n !== value) onChange(n);
  };
  return (
    <div className="stepper">
      <button type="button" disabled={disabled || value <= min} onClick={() => commit(value - step)} aria-label="إنقاص">
        −
      </button>
      <input
        type="number"
        inputMode="numeric"
        value={draft}
        min={min}
        max={max}
        disabled={disabled}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={(e) => commit(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && commit(e.currentTarget.value)}
      />
      {suffix && <small>{suffix}</small>}
      <button type="button" disabled={disabled || value >= max} onClick={() => commit(value + step)} aria-label="زيادة">
        +
      </button>
    </div>
  );
}

export function HowTo({ settings }) {
  const cards = [
    { icon: '🔍', title: 'اختر سؤالك', text: 'في دورك تختار فئة، ثم مستوى (سالكة، مطبّ، ورطة) بتلميح عن السؤال فقط. إن أصبت: +2 و+1 عن كل من يخطئ. وإن أخطأت تربح نقطة عن كل من اختار نفس خطئك.' },
    settings.wartaEnabled && { icon: '🎯', title: 'اقنصه', text: 'بعد إجابتك اقنص من تتوقع أنه سيُخطئ: إن أخطأ +1 لك و−1 له، وإن أصاب العكس. ومن يصيب وحده يأخذ ⭐ +1.' },
    { icon: '⚡', title: 'الجولات الإضافية', text: 'كل جولتين: أسرع إجابة صحيحة +2 والخاطئة −1.' + (settings.auctionEnabled ? ' وفي النهاية مزاد التعويض: كل صحيحة +1 وكل خاطئة −1.' : '') },
  ].filter(Boolean);
  return (
    <section className="howto" aria-label="كيف تلعب">
      <h2>كيف تلعب</h2>
      <div className="howto-cards">
        {cards.map((c) => (
          <article key={c.title} className="howto-card">
            <span className="howto-icon">{c.icon}</span>
            <h3>{c.title}</h3>
            <p>{c.text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function OnOff({ value, onChange, disabled, onLabel = 'مفعّلة', offLabel = 'معطّلة' }) {
  return (
    <div className="cat-grid">
      {[
        [true, onLabel],
        [false, offLabel],
      ].map(([v, label]) => (
        <button key={String(v)} type="button" disabled={disabled} aria-pressed={value === v} className={`cat ${value === v ? 'on' : ''}`} onClick={() => onChange(v)}>
          {value === v && <span className="cat-check" aria-hidden="true">✓</span>}
          {label}
        </button>
      ))}
    </div>
  );
}

async function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {}
  // Legacy path that also works on iOS Safari over plain http.
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;font-size:16px';
  document.body.appendChild(ta);
  const range = document.createRange();
  range.selectNodeContents(ta);
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);
  ta.setSelectionRange(0, text.length);
  let ok = false;
  try {
    ok = document.execCommand('copy');
  } catch {}
  sel.removeAllRanges();
  ta.remove();
  return ok;
}

export function Lobby({ state }) {
  const count = state.players.filter((p) => !p.removed).length;
  const prevCount = useRef(count);
  useEffect(() => {
    if (count > prevCount.current) play('join');
    prevCount.current = count;
  }, [count]);
  const isHost = state.me === state.hostId;
  const s = state.settings;
  const players = state.players.filter((p) => !p.removed);
  const [copied, setCopied] = useState(false);
  const link = `${location.origin}/${state.code}`;
  const set = (patch) => net.send('update_settings', patch);
  const toggleBonus = (key) => {
    const has = s.bonusTypes.includes(key);
    set({ bonusTypes: has ? s.bonusTypes.filter((t) => t !== key) : [...s.bonusTypes, key] });
  };
  const toggleCat = (key) => {
    const has = s.categories.includes(key);
    const next = has ? s.categories.filter((c) => c !== key) : [...s.categories, key];
    if (next.length) set({ categories: next });
  };
  const flash = (msg) => {
    setCopied(msg);
    setTimeout(() => setCopied(false), 1800);
  };
  // navigator.share / clipboard only exist on https; on a local http address fall back to a manual copy.
  const share = async () => {
    const text = `انضم لغرفتي في لعبة ورطة — الرمز ${state.code}`;
    if (navigator.share && window.isSecureContext) {
      try {
        await navigator.share({ title: 'ورطة', text, url: link });
        return;
      } catch (e) {
        if (e && e.name === 'AbortError') return;
      }
    }
    if (await copyText(link)) flash('تم نسخ الرابط');
    else flash('انسخ الرابط من الحقل يدوياً');
  };
  const whatsapp = `https://wa.me/?text=${encodeURIComponent(`انضم لغرفتي في لعبة ورطة — الرمز ${state.code}\n${link}`)}`;
  const connectedCount = players.filter((p) => p.connected && p.ready).length;
  const readyCount = players.filter((p) => p.ready).length;
  const summary = [
    s.categories.length === state.categories.filter((c) => c.count).length ? 'كل الفئات' : `${s.categories.length} فئات`,
    s.bonusTypes.length ? `${s.bonusTypes.length} جولات إضافية` : 'بدون جولات إضافية',
    s.wartaEnabled ? 'اقنصه' : null,
    s.auctionEnabled ? 'مزاد التعويض' : null,
    `${s.questionTime} ث للسؤال`,
    `${s.optionCount} خيارات`,
  ]
    .filter(Boolean)
    .join(' · ');

  // Remember the host's settings for next time, and re-apply them to a room they just created.
  useEffect(() => {
    if (!isHost) return;
    if (applySavedOnce) {
      applySavedOnce = false;
      const saved = loadHostSettings();
      if (saved) {
        const { rounds, roundsAuto, ...rest } = saved;
        net.send('update_settings', roundsAuto === false ? { ...rest, rounds } : { ...rest, roundsAuto: true });
        return;
      }
    }
    saveHostSettings(s);
  }, [isHost, JSON.stringify(s)]);

  return (
    <main className="lobby">
      <section className="room-code card">
        <span className="muted">رمز الغرفة</span>
        <strong dir="ltr">{state.code}</strong>
        <input className="link-field" dir="ltr" readOnly value={link} onFocus={(e) => e.target.select()} onClick={(e) => e.target.select()} aria-label="رابط الغرفة" />
        <div className="share-row">
          <button className="btn btn-small" onClick={share}>
            {copied || 'مشاركة الرابط'}
          </button>
          <a className="btn btn-small btn-wa" href={whatsapp} target="_blank" rel="noopener noreferrer">
            واتساب
          </a>
        </div>
      </section>

      <section className="card">
        <h2>
          اللاعبون <small className="muted">{players.length} / {s.maxPlayers}</small>
        </h2>
        <ul className="player-list">
          {players.map((p) => (
            <li key={p.id} className={`${!p.connected ? 'is-off' : ''} ${!p.ready ? 'is-pending' : ''}`}>
              <span className="avatar avatar-md">{p.ready ? p.avatar : '⏳'}</span>
              <span className="pl-name">
                {p.ready ? p.name : <span className="muted">لاعب جديد يختار شخصيته…</span>}
                {p.id === state.me && <small className="muted"> (أنت)</small>}
              </span>
              {p.id === state.hostId && <span className="badge-host">المضيف</span>}
              {!p.connected && <span className="muted">يعيد الاتصال…</span>}
              {isHost && p.id !== state.me && (
                <button className="btn-x" onClick={() => net.send('kick', { playerId: p.id })} aria-label={`إخراج ${p.name}`}>
                  ✕
                </button>
              )}
            </li>
          ))}
        </ul>
      </section>

      <HowTo settings={s} />

      <section className="card settings">
        <h2>إعدادات الغرفة {!isHost && <small className="muted">يحددها المضيف</small>}</h2>
        <div className="settings-row">
          <div className="field field-wide">
            <span>عدد الجولات</span>
            <Stepper value={s.rounds} min={1} max={200} disabled={!isHost} onChange={(v) => set({ rounds: v })} />
            {s.roundsAuto ? (
              <small className="muted">تلقائي: دوران لكل لاعب</small>
            ) : (
              <>
                {readyCount > 1 && s.rounds % readyCount !== 0 && <small className="field-warn">بعض اللاعبين سيحصلون على دور أقل</small>}
                {isHost && (
                  <button type="button" className="link-btn" onClick={() => set({ roundsAuto: true })}>
                    اجعله تلقائياً
                  </button>
                )}
              </>
            )}
          </div>
        </div>
        <p className="settings-summary">{summary}</p>
        <details className="advanced">
          <summary>إعدادات متقدمة</summary>
        <div className="field">
          <span>فئات الأسئلة</span>
          <div className="cat-grid">
            {state.categories.filter((c) => c.count > 0).map((c) => (
              <button
                key={c.key}
                type="button"
                disabled={!isHost || c.count === 0}
                aria-pressed={s.categories.includes(c.key)}
                className={`cat ${s.categories.includes(c.key) ? 'on' : ''}`}
                onClick={() => toggleCat(c.key)}
              >
                {s.categories.includes(c.key) && <span className="cat-check" aria-hidden="true">✓</span>}
                {c.label || CAT_LABEL[c.key]}
                <small>{c.count}</small>
              </button>
            ))}
          </div>
        </div>
        <div className="field">
          <span>الجولات الإضافية (كل جولتين)</span>
          <div className="cat-grid">
            {BONUS_ORDER.map((key) => {
              const on = s.bonusTypes.includes(key);
              return (
                <button key={key} type="button" disabled={!isHost} aria-pressed={on} className={`cat ${on ? 'on' : ''}`} onClick={() => toggleBonus(key)}>
                  {on && <span className="cat-check" aria-hidden="true">✓</span>}
                  {BONUS_INFO[key].icon} {BONUS_INFO[key].name}
                </button>
              );
            })}
          </div>
          {s.bonusTypes.length === 0 && <p className="hint small">لن تكون هناك جولات إضافية في هذه اللعبة.</p>}
        </div>
        <div className="field">
          <span>اقنصه</span>
          <OnOff value={s.wartaEnabled} disabled={!isHost} onLabel="🎯 مفعّل" offLabel="معطّل" onChange={(v) => set({ wartaEnabled: v })} />
          <p className="hint small">بعد الإجابة يختار كل لاعب من يتوقع أنه سيُخطئ (من قائمة صغيرة متوازنة). إن أخطأ: +1 لك و−1 له، وإن أصاب: العكس.</p>
        </div>

          <div className="field">
            <span>🔨 مزاد التعويض (السؤال الأخير)</span>
        <OnOff value={s.auctionEnabled} disabled={!isHost} onLabel="مفعّل" offLabel="معطّل" onChange={(v) => set({ auctionEnabled: v })} />
        <p className="hint">
          السؤال الأخير في اللعبة دائماً: 10 خيارات (5 صحيحة و5 خاطئة) ويختار كل لاعب كل ما يراه صحيحاً. كل صحيحة +1 وكل خاطئة −1، فيمكن به
          تعويض فرق كبير في النقاط. إن بقي تعادل على المركز الأول بعده تُلعب جولات حسم سريعة حتى يتصدّر لاعب واحد.
        </p>
          </div>
          <div className="settings-row">
          <label className="field">
            <span>مدة السؤال</span>
            <Stepper value={s.questionTime} min={5} max={120} step={5} suffix="ث" disabled={!isHost} onChange={(v) => set({ questionTime: v })} />
          </label>
          <label className="field">
            <span>عدد خيارات السؤال</span>
            <Stepper value={s.optionCount} min={2} max={8} disabled={!isHost} onChange={(v) => set({ optionCount: v })} />
          </label>
          <label className="field">
            <span>مدة اختيار السؤال</span>
            <Stepper value={s.selectionTime} min={5} max={60} suffix="ث" disabled={!isHost} onChange={(v) => set({ selectionTime: v })} />
          </label>
          <label className="field">
            <span>أقصى عدد للاعبين</span>
            <Stepper value={s.maxPlayers} min={2} max={20} disabled={!isHost} onChange={(v) => set({ maxPlayers: v })} />
          </label>
          </div>
          <p className="hint">كل جولة هي دور لاعب واحد، وبعد كل جولتين جولة إضافية (إن اخترت أنواعاً لها). مدة السؤال تنطبق على الجولات الإضافية والمزاد أيضاً.</p>
        </details>
      </section>

      <ActionBar>
        {isHost ? (
          <button
            className="btn btn-primary btn-big"
            disabled={connectedCount < 2}
            onClick={() => {
              unlockAudio();
              net.send('start_game');
            }}
          >
            {connectedCount < 2 ? 'بانتظار لاعب آخر على الأقل' : 'ابدأ اللعبة'}
          </button>
        ) : (
          <p className="waiting">بانتظار المضيف ليبدأ اللعبة…</p>
        )}
        <button className="btn btn-ghost btn-small" onClick={() => net.send('leave')}>
          مغادرة الغرفة
        </button>
      </ActionBar>
    </main>
  );
}
