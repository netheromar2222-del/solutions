import { createContext, useContext } from 'react';
import { createPortal } from 'react-dom';

// The app shell reserves a footer strip below the scrolling content. Screens put their
// main buttons there through this portal, so buttons never sit on top of text.
export const ActionBarContext = createContext(null);

export function ActionBar({ children }) {
  const el = useContext(ActionBarContext);
  if (!el) return null;
  return createPortal(<div className="bar-inner">{children}</div>, el);
}
