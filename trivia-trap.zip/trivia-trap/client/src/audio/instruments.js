// Synthesized instruments. Every function schedules sound at absolute time `t` on engine `E`
// and routes it to `out` (a bus gain node). Nothing here touches the clock, so the same code
// runs live and in an OfflineAudioContext for previews.

export const midiHz = (m) => 440 * Math.pow(2, (m - 69) / 12);

function env(g, t, a, peak, d, sustain = 0.0001) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + a);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0001, sustain), t + a + d);
}

function osc(E, type, freq, t, dur) {
  const o = E.ctx.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  o.start(t);
  o.stop(t + dur + 0.05);
  return o;
}

let noiseBuf = null;
function noise(E, t, dur) {
  if (!noiseBuf || noiseBuf.sampleRate !== E.ctx.sampleRate) {
    const len = E.ctx.sampleRate * 2;
    noiseBuf = E.ctx.createBuffer(1, len, E.ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }
  const s = E.ctx.createBufferSource();
  s.buffer = noiseBuf;
  s.start(t, Math.random() * 1.5);
  s.stop(t + dur + 0.05);
  return s;
}

function filter(E, type, freq, q = 0.7) {
  const f = E.ctx.createBiquadFilter();
  f.type = type;
  f.frequency.value = freq;
  f.Q.value = q;
  return f;
}

function gain(E, v = 1) {
  const g = E.ctx.createGain();
  g.gain.value = v;
  return g;
}

/** Connect to bus, plus an optional reverb send. */
function route(E, node, out, wet = 0) {
  node.connect(out);
  if (wet > 0) {
    const s = gain(E, wet);
    node.connect(s);
    s.connect(E.reverbIn);
  }
}

// ---------------- drums ----------------

export function kick(E, t, out, vol = 1) {
  const o = osc(E, 'sine', 150, t, 0.5);
  o.frequency.exponentialRampToValueAtTime(42, t + 0.18);
  const g = gain(E);
  env(g, t, 0.002, 0.9 * vol, 0.42);
  o.connect(g);
  // click for punch on small speakers
  const c = osc(E, 'triangle', 1800, t, 0.02);
  const cg = gain(E);
  env(cg, t, 0.001, 0.18 * vol, 0.018);
  c.connect(cg);
  route(E, g, out);
  route(E, cg, out);
}

export function snare(E, t, out, vol = 1, wet = 0.18) {
  const n = noise(E, t, 0.25);
  const hp = filter(E, 'highpass', 1500);
  const g = gain(E);
  env(g, t, 0.001, 0.5 * vol, 0.2);
  n.connect(hp).connect(g);
  const o = osc(E, 'triangle', 190, t, 0.15);
  o.frequency.exponentialRampToValueAtTime(140, t + 0.1);
  const og = gain(E);
  env(og, t, 0.001, 0.35 * vol, 0.1);
  o.connect(og);
  route(E, g, out, wet);
  route(E, og, out);
}

export function clap(E, t, out, vol = 1) {
  for (let i = 0; i < 3; i++) {
    const tt = t + i * 0.011;
    const n = noise(E, tt, 0.2);
    const bp = filter(E, 'bandpass', 1300, 1.2);
    const g = gain(E);
    env(g, tt, 0.001, (i === 2 ? 0.55 : 0.3) * vol, i === 2 ? 0.18 : 0.03);
    n.connect(bp).connect(g);
    route(E, g, out, 0.25);
  }
}

export function hat(E, t, out, vol = 1, open = false) {
  const n = noise(E, t, open ? 0.35 : 0.06);
  const hp = filter(E, 'highpass', 7500);
  const g = gain(E);
  env(g, t, 0.001, 0.22 * vol, open ? 0.3 : 0.045);
  n.connect(hp).connect(g);
  route(E, g, out);
}

/** Darbuka "doum": deep centre stroke. */
export function doum(E, t, out, vol = 1) {
  const o = osc(E, 'sine', 120, t, 0.45);
  o.frequency.exponentialRampToValueAtTime(68, t + 0.12);
  const g = gain(E);
  env(g, t, 0.003, 0.75 * vol, 0.38);
  o.connect(g);
  const n = noise(E, t, 0.08);
  const lp = filter(E, 'lowpass', 900);
  const ng = gain(E);
  env(ng, t, 0.001, 0.18 * vol, 0.06);
  n.connect(lp).connect(ng);
  route(E, g, out, 0.12);
  route(E, ng, out);
}

/** Darbuka "tek": sharp rim stroke. */
export function tek(E, t, out, vol = 1) {
  const n = noise(E, t, 0.07);
  const bp = filter(E, 'bandpass', 3800, 1.8);
  const g = gain(E);
  env(g, t, 0.001, 0.5 * vol, 0.055);
  n.connect(bp).connect(g);
  const o = osc(E, 'sine', 1150, t, 0.05);
  const og = gain(E);
  env(og, t, 0.001, 0.22 * vol, 0.035);
  o.connect(og);
  route(E, g, out, 0.15);
  route(E, og, out);
}

export function crash(E, t, out, vol = 1) {
  const n = noise(E, t, 2);
  const hp = filter(E, 'highpass', 5000);
  const g = gain(E);
  env(g, t, 0.002, 0.3 * vol, 1.6);
  n.connect(hp).connect(g);
  route(E, g, out, 0.35);
}

// ---------------- tonal ----------------

export function bass(E, t, midi, dur, out, vol = 1) {
  const f = midiHz(midi);
  const o = osc(E, 'sawtooth', f, t, dur);
  const s = osc(E, 'sine', f / 2, t, dur);
  const lp = filter(E, 'lowpass', 300, 6);
  lp.frequency.setValueAtTime(1300, t);
  lp.frequency.exponentialRampToValueAtTime(220, t + Math.min(0.25, dur));
  const g = gain(E);
  env(g, t, 0.005, 0.42 * vol, dur * 0.9, 0.02);
  const sg = gain(E, 0.5);
  o.connect(lp).connect(g);
  s.connect(sg).connect(g);
  route(E, g, out);
}

export function pluck(E, t, midi, dur, out, vol = 1, wet = 0.3) {
  const f = midiHz(midi);
  const a = osc(E, 'square', f, t, dur);
  const b = osc(E, 'triangle', f * 2.001, t, dur);
  const lp = filter(E, 'lowpass', 1000, 3);
  lp.frequency.setValueAtTime(4200, t);
  lp.frequency.exponentialRampToValueAtTime(600, t + 0.18);
  const g = gain(E);
  env(g, t, 0.003, 0.16 * vol, Math.max(0.12, dur));
  const bg = gain(E, 0.5);
  a.connect(lp);
  b.connect(bg).connect(lp);
  lp.connect(g);
  route(E, g, out, wet);
}

/** Nasal, slightly bent reed-like lead (mizmar flavour). */
export function lead(E, t, midi, dur, out, vol = 1, wet = 0.28) {
  const f = midiHz(midi);
  const o1 = osc(E, 'sawtooth', f, t, dur);
  const o2 = osc(E, 'sawtooth', f * 1.006, t, dur);
  // scoop into the note + vibrato
  o1.frequency.setValueAtTime(f * 0.97, t);
  o1.frequency.exponentialRampToValueAtTime(f, t + 0.05);
  const lfo = osc(E, 'sine', 5.5, t, dur);
  const lg = gain(E, f * 0.008);
  lfo.connect(lg);
  lg.connect(o1.frequency);
  lg.connect(o2.frequency);
  const bp = filter(E, 'bandpass', Math.min(3200, f * 3), 1.4);
  const lp = filter(E, 'lowpass', 4200);
  const g = gain(E);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.2 * vol, t + 0.02);
  g.gain.setValueAtTime(0.2 * vol, t + Math.max(0.03, dur - 0.06));
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o1.connect(bp);
  o2.connect(bp);
  bp.connect(lp).connect(g);
  route(E, g, out, wet);
}

export function pad(E, t, midis, dur, out, vol = 1) {
  const g = gain(E);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.07 * vol, t + Math.min(0.6, dur * 0.4));
  g.gain.setValueAtTime(0.07 * vol, t + dur * 0.8);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  const lp = filter(E, 'lowpass', 1400, 0.5);
  for (const m of midis) {
    for (const det of [-7, 7]) {
      const o = osc(E, 'sawtooth', midiHz(m), t, dur);
      o.detune.value = det;
      o.connect(lp);
    }
  }
  lp.connect(g);
  route(E, g, out, 0.45);
}

/** Brass-like stab/chord for fanfares and hits. */
export function brass(E, t, midis, dur, out, vol = 1) {
  const lp = filter(E, 'lowpass', 600, 2);
  lp.frequency.setValueAtTime(600, t);
  lp.frequency.exponentialRampToValueAtTime(3800, t + 0.08);
  lp.frequency.exponentialRampToValueAtTime(1800, t + dur);
  const g = gain(E);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.16 * vol, t + 0.03);
  g.gain.setValueAtTime(0.13 * vol, t + Math.max(0.05, dur - 0.08));
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.25);
  for (const m of midis) {
    for (const det of [-6, 6]) {
      const o = osc(E, 'sawtooth', midiHz(m), t, dur + 0.3);
      o.detune.value = det;
      o.connect(lp);
    }
  }
  lp.connect(g);
  route(E, g, out, 0.35);
}

export function bell(E, t, midi, out, vol = 1, dur = 1.2) {
  const f = midiHz(midi);
  [1, 2.76, 5.4].forEach((r, i) => {
    const o = osc(E, 'sine', f * r, t, dur);
    const g = gain(E);
    env(g, t, 0.002, (0.18 / (i + 1)) * vol, dur / (i + 1));
    o.connect(g);
    route(E, g, out, 0.4);
  });
}

// ---------------- fx building blocks ----------------

export function whoosh(E, t, dur, out, vol = 1, up = true) {
  const n = noise(E, t, dur);
  const bp = filter(E, 'bandpass', up ? 400 : 4000, 1.2);
  bp.frequency.exponentialRampToValueAtTime(up ? 5000 : 300, t + dur);
  const g = gain(E);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.35 * vol, t + dur * 0.75);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  n.connect(bp).connect(g);
  route(E, g, out, 0.3);
}

export function riser(E, t, dur, out, vol = 1) {
  whoosh(E, t, dur, out, vol, true);
  const o = osc(E, 'sawtooth', 110, t, dur);
  o.frequency.exponentialRampToValueAtTime(880, t + dur);
  const lp = filter(E, 'lowpass', 800);
  lp.frequency.exponentialRampToValueAtTime(5000, t + dur);
  const g = gain(E);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.08 * vol, t + dur);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.05);
  o.connect(lp).connect(g);
  route(E, g, out, 0.2);
}

export function impact(E, t, out, vol = 1) {
  const o = osc(E, 'sine', 90, t, 1.2);
  o.frequency.exponentialRampToValueAtTime(32, t + 0.8);
  const g = gain(E);
  env(g, t, 0.003, 0.9 * vol, 1.1);
  o.connect(g);
  route(E, g, out, 0.25);
  const n = noise(E, t, 0.9);
  const lp = filter(E, 'lowpass', 2500);
  lp.frequency.exponentialRampToValueAtTime(200, t + 0.8);
  const ng = gain(E);
  env(ng, t, 0.002, 0.35 * vol, 0.8);
  n.connect(lp).connect(ng);
  route(E, ng, out, 0.5);
}

export function buzz(E, t, midi, dur, out, vol = 1) {
  const f = midiHz(midi);
  const o = osc(E, 'square', f, t, dur);
  const o2 = osc(E, 'sawtooth', f * 1.02, t, dur);
  const trem = osc(E, 'square', 18, t, dur);
  const tg = gain(E, 0.07 * vol);
  const g = gain(E);
  env(g, t, 0.005, 0.16 * vol, dur);
  trem.connect(tg).connect(g.gain);
  const lp = filter(E, 'lowpass', 1600);
  o.connect(lp);
  o2.connect(lp);
  lp.connect(g);
  route(E, g, out);
}

export function crackle(E, t, out, vol = 1, count = 14) {
  for (let i = 0; i < count; i++) {
    const tt = t + 0.15 + Math.random() * 0.7;
    const n = noise(E, tt, 0.02);
    const hp = filter(E, 'highpass', 3000 + Math.random() * 4000);
    const g = gain(E);
    env(g, tt, 0.001, (0.08 + Math.random() * 0.12) * vol, 0.015);
    n.connect(hp).connect(g);
    route(E, g, out, 0.3);
  }
}
