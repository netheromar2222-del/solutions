// Music: one looping track per game phase, built on maqam Hijaz (D) with darbuka rhythms
// so the game sounds like a Gulf/Levant game show rather than generic chiptune.
import * as I from './instruments';

const HIJAZ = [0, 1, 4, 5, 7, 8, 10]; // D Eb F# G A Bb C
const MAJOR = [0, 2, 4, 5, 7, 9, 11];
const ROOT = 62; // D4

const deg = (scale, d, base = ROOT) => {
  const o = Math.floor(d / 7);
  const i = ((d % 7) + 7) % 7;
  return base + o * 12 + scale[i];
};
const hj = (d, base) => deg(HIJAZ, d, base);
const mj = (d, base) => deg(MAJOR, d, base);

// 4-bar progression in Hijaz: D – Eb – D – Cm
const HJ_CHORDS = [
  { root: 38, tones: [62, 66, 69] },
  { root: 39, tones: [63, 67, 70] },
  { root: 38, tones: [62, 66, 69] },
  { root: 36, tones: [60, 63, 67] },
];
// Victory progression in D major: D – G – A – D
const MJ_CHORDS = [
  { root: 38, tones: [62, 66, 69] },
  { root: 43, tones: [59, 62, 67] },
  { root: 45, tones: [61, 64, 69] },
  { root: 38, tones: [62, 66, 69] },
];

// Lead phrases: [step, scaleDegree, lengthInSteps]
const RIFF_A = [[0, 7, 2], [2, 8, 1], [3, 7, 1], [4, 6, 1], [5, 5, 1], [6, 4, 2], [8, 5, 1], [9, 4, 1], [10, 2, 2], [12, 1, 2], [14, 0, 2]];
const RIFF_B = [[0, 4, 1], [1, 5, 1], [2, 4, 1], [3, 2, 1], [4, 4, 2], [6, 5, 1], [7, 6, 1], [8, 7, 3], [11, 8, 1], [12, 7, 4]];
const RIFF_C = [[0, 2, 1], [1, 4, 1], [2, 5, 1], [3, 4, 1], [4, 2, 1], [5, 1, 1], [6, 0, 2], [8, 1, 1], [9, 2, 1], [10, 4, 2], [12, 1, 1], [13, 2, 1], [14, 1, 1], [15, 0, 1]];
const FANFARE = [[0, 4, 2], [2, 4, 1], [3, 4, 1], [4, 7, 4], [8, 6, 2], [10, 7, 2], [12, 9, 4]];
const JOY = [[0, 7, 1], [1, 9, 1], [2, 11, 2], [4, 9, 1], [5, 7, 1], [6, 9, 2], [8, 7, 1], [9, 6, 1], [10, 4, 2], [12, 6, 1], [13, 7, 1], [14, 9, 2]];

function maqsum(E, s, t, out, vol = 1) {
  // Maqsum: DUM tek - tek DUM - tek -   (16ths: 0,2,6,8,12)
  const b = s % 16;
  if (b === 0 || b === 8) I.doum(E, t, out, 0.8 * vol);
  if (b === 2 || b === 6 || b === 12) I.tek(E, t, out, 0.7 * vol);
  if (b === 14 || b === 15) I.tek(E, t, out, 0.25 * vol);
}

function playRiff(E, riff, s, t, step, out, toMidi, vol = 1) {
  const b = s % 16;
  for (const [at, d, len] of riff) if (at === b) I.lead(E, t, toMidi(d), len * step * 0.95, out, vol);
}

export const TRACKS = {
  lobby: {
    bpm: () => 98,
    step(E, s, t, step) {
      const out = E.music;
      const bar = Math.floor(s / 16) % 4;
      const b = s % 16;
      const ch = HJ_CHORDS[bar];
      maqsum(E, s, t, out, 0.75);
      if (b === 0) I.pad(E, t, ch.tones.map((m) => m - 12), step * 16, out, 0.8);
      if (b === 0 || b === 10) I.bass(E, t, ch.root, step * 2.5, out, 0.8);
      if (b === 3 || b === 13) I.bass(E, t, ch.root + 12, step, out, 0.5);
      if ([0, 3, 6, 8, 11, 14].includes(b)) {
        const i = [0, 3, 6, 8, 11, 14].indexOf(b);
        I.pluck(E, t, ch.tones[i % 3] + (i > 2 ? 12 : 0), step * 2, out, 0.55);
      }
      if (b === 4 || b === 12) I.hat(E, t, out, 0.35);
      if (Math.floor(s / 64) % 2 === 1) playRiff(E, bar % 2 ? RIFF_B : RIFF_A, s, t, step, out, (d) => hj(d), 0.45);
    },
  },

  select: {
    bpm: () => 112,
    step(E, s, t, step) {
      const out = E.music;
      const bar = Math.floor(s / 16) % 2;
      const b = s % 16;
      const ch = HJ_CHORDS[bar];
      if (b === 0) I.pad(E, t, ch.tones, step * 16, out, 1);
      if (b % 2 === 0) I.bass(E, t, ch.root, step * 0.9, out, b === 0 ? 0.9 : 0.55);
      if (b === 0 || b === 3) I.kick(E, t, out, b === 0 ? 0.7 : 0.4); // heartbeat
      if (b === 4 || b === 12) I.tek(E, t, out, 0.5);
      if (b % 4 === 2) I.hat(E, t, out, 0.25);
      if (b === 8) I.pluck(E, t, hj(7 + (Math.floor(s / 16) % 4)), step * 3, out, 0.5, 0.5);
    },
  },

  question: {
    bpm: (E) => 120 + E.intensity * 10,
    step(E, s, t, step) {
      const out = E.music;
      const bar = Math.floor(s / 16) % 4;
      const b = s % 16;
      const ch = HJ_CHORDS[bar];
      const lvl = E.intensity;
      if (b % 4 === 0) I.kick(E, t, out, 0.85);
      maqsum(E, s, t, out, 0.55);
      if (b % 2 === 0) I.bass(E, t, ch.root + (b % 8 === 6 ? 12 : 0), step * 1.6, out, 0.75);
      // 16th-note arpeggio, filter brighter as time runs out
      const arp = [0, 1, 2, 1, 2, 0, 1, 2];
      I.pluck(E, t, ch.tones[arp[b % 8]] + (b >= 8 ? 12 : 0), step * 0.9, out, 0.35 + lvl * 0.1, 0.2);
      if (b === 0) I.pad(E, t, ch.tones.map((m) => m - 12), step * 16, out, 0.6);
      if (lvl >= 1) {
        if (b === 4 || b === 12) I.clap(E, t, out, 0.7);
        playRiff(E, [RIFF_A, RIFF_B, RIFF_A, RIFF_C][bar], s, t, step, out, (d) => hj(d), 0.5);
      }
      if (lvl >= 2) {
        I.hat(E, t, out, b % 2 ? 0.3 : 0.45);
        if (bar === 3 && b >= 12) I.snare(E, t, out, 0.35 + (b - 12) * 0.12);
      } else if (b % 4 === 2) I.hat(E, t, out, 0.35);
    },
  },

  bonus: {
    bpm: (E) => 138 + E.intensity * 6,
    step(E, s, t, step) {
      const out = E.music;
      const bar = Math.floor(s / 16) % 4;
      const b = s % 16;
      const ch = HJ_CHORDS[bar];
      if (s % 64 === 0) I.crash(E, t, out, 0.7);
      if (b % 4 === 0) I.kick(E, t, out, 0.95);
      if (b === 4 || b === 12) I.clap(E, t, out, 0.85);
      I.hat(E, t, out, b % 4 === 2 ? 0.45 : 0.25, b % 4 === 2);
      if (b === 0 || b === 10) I.doum(E, t, out, 0.6);
      if (b % 4 === 3 || (bar === 3 && b >= 12)) I.tek(E, t, out, 0.6);
      if (b % 2 === 0) I.bass(E, t, ch.root + (b % 4 === 2 ? 12 : 0), step * 1.5, out, 0.8);
      playRiff(E, [RIFF_A, RIFF_C, RIFF_B, RIFF_C][bar], s, t, step, out, (d) => hj(d), 0.6);
      if (b === 0 && bar % 2 === 0) I.brass(E, t, ch.tones, step * 2, out, 0.5);
    },
  },

  results: {
    bpm: () => 104,
    step(E, s, t, step) {
      const out = E.music;
      const bar = Math.floor(s / 16) % 4;
      const b = s % 16;
      const ch = HJ_CHORDS[bar];
      if (b === 0 || b === 7 || b === 10) I.kick(E, t, out, 0.75);
      if (b === 4 || b === 12) I.clap(E, t, out, 0.6);
      maqsum(E, s, t, out, 0.6);
      if (b % 4 === 2) I.hat(E, t, out, 0.3);
      if (b === 0 || b === 6 || b === 10) ch.tones.forEach((m) => I.pluck(E, t, m + 12, step * 1.5, out, 0.3));
      if (b === 0 || b === 6 || b === 8 || b === 14) I.bass(E, t, ch.root, step * 1.5, out, 0.75);
    },
  },

  victory: {
    bpm: () => 124,
    step(E, s, t, step) {
      const out = E.music;
      const loop = Math.floor(s / 64);
      const bar = Math.floor(s / 16) % 4;
      const b = s % 16;
      const ch = MJ_CHORDS[bar];
      if (s % 64 === 0) I.crash(E, t, out, 0.8);
      if (loop === 0) {
        // opening fanfare
        if (b === 0 || b === 6 || b === 12) I.brass(E, t, ch.tones, step * (b === 12 ? 4 : 2), out, 0.9);
        if (b === 0 && bar === 0) I.impact(E, t, out, 0.6);
        if (b % 4 === 0) I.kick(E, t, out, 0.7);
        if (bar === 3 && b >= 8) I.snare(E, t, out, 0.3 + (b - 8) * 0.08);
        playRiff(E, FANFARE, s, t, step, out, (d) => mj(d), 0.55);
        if (b === 0) I.bass(E, t, ch.root, step * 6, out, 0.9);
        return;
      }
      if (b % 4 === 0) I.kick(E, t, out, 0.9);
      if (b === 4 || b === 12) I.clap(E, t, out, 0.8);
      I.hat(E, t, out, b % 4 === 2 ? 0.4 : 0.22, b % 4 === 2);
      maqsum(E, s, t, out, 0.5);
      if (b % 2 === 0) I.bass(E, t, ch.root + (b % 4 === 2 ? 12 : 0), step * 1.5, out, 0.8);
      if (b === 2 || b === 6 || b === 10 || b === 14) I.brass(E, t, ch.tones, step * 0.8, out, 0.45);
      playRiff(E, JOY, s, t, step, out, (d) => mj(d), 0.5);
    },
  },
};
