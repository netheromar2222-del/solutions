// Sound effects. Each takes (E, t, out) and may return a duck amount (0..1) for the music.
import * as I from './instruments';

const D = 62; // D4

export const SFX = {
  tap: (E, t, o) => {
    I.tek(E, t, o, 0.35);
  },
  join: (E, t, o) => {
    I.pluck(E, t, 74, 0.12, o, 0.7);
    I.pluck(E, t + 0.07, 81, 0.2, o, 0.7);
  },
  tick: (E, t, o) => {
    I.bell(E, t, 96, o, 0.35, 0.12);
    I.tek(E, t, o, 0.25);
  },
  tickUrgent: (E, t, o) => {
    I.kick(E, t, o, 0.55);
    I.kick(E, t + 0.16, o, 0.4);
    I.bell(E, t, 100, o, 0.4, 0.1);
  },
  timeUp: (E, t, o) => {
    I.bell(E, t, 50, o, 1.2, 2.2);
    I.impact(E, t, o, 0.5);
    return 0.5;
  },
  yourTurn: (E, t, o) => {
    I.whoosh(E, t, 0.35, o, 0.6);
    [D + 12, D + 16, D + 19, D + 24].forEach((m, i) => I.bell(E, t + 0.25 + i * 0.07, m, o, 0.7, 1));
    return 0.4;
  },
  question: (E, t, o) => {
    I.whoosh(E, t, 0.3, o, 0.6);
    I.impact(E, t + 0.28, o, 0.55);
    I.brass(E, t + 0.28, [D - 12, D - 11, D - 5], 0.35, o, 0.6);
    return 0.5;
  },
  correct: (E, t, o) => {
    [D + 12, D + 16, D + 19, D + 24].forEach((m, i) => I.pluck(E, t + i * 0.06, m, 0.4, o, 1.1, 0.4));
    I.bell(E, t + 0.24, D + 31, o, 0.5, 1);
    return 0.4;
  },
  wrong: (E, t, o) => {
    I.buzz(E, t, 47, 0.22, o, 0.9);
    I.buzz(E, t + 0.25, 43, 0.45, o, 0.9);
    return 0.4;
  },
  trap: (E, t, o) => {
    // Dramatic stab: low hit + dissonant Hijaz cluster + darbuka roll
    I.impact(E, t, o, 1);
    I.brass(E, t, [D - 12, D - 11, D - 3, D + 1], 0.7, o, 1);
    for (let i = 0; i < 8; i++) I.tek(E, t + 0.45 + i * 0.045, o, 0.3 + i * 0.06);
    I.doum(E, t + 0.85, o, 1);
    I.brass(E, t + 0.85, [D - 12, D - 8, D - 5], 0.6, o, 0.9);
    return 0.8;
  },
  bluffWin: (E, t, o) => {
    [D + 19, D + 24, D + 28].forEach((m, i) => I.bell(E, t + i * 0.08, m, o, 0.7, 0.9));
    I.crackle(E, t, o, 0.5, 6);
    return 0.3;
  },
  bluffLose: (E, t, o) => {
    I.lead(E, t, D - 2, 0.25, o, 1.5, 0.2);
    I.lead(E, t + 0.25, D - 7, 0.5, o, 1.5, 0.2);
    I.doum(E, t + 0.25, o, 0.6);
    return 0.3;
  },
  pin: (E, t, o) => {
    I.whoosh(E, t, 0.18, o, 0.4, false);
    I.kick(E, t + 0.16, o, 0.5);
    I.bell(E, t + 0.17, D + 26, o, 0.4, 0.4);
  },
  pinOther: (E, t, o) => {
    I.tek(E, t, o, 0.4);
    I.bell(E, t, D + 21, o, 0.25, 0.25);
  },
  eliminated: (E, t, o) => {
    I.buzz(E, t, 38, 0.45, o, 1);
    return 0.4;
  },
  bonus: (E, t, o) => {
    I.riser(E, t, 1.3, o, 0.9);
    for (let i = 0; i < 12; i++) I.tek(E, t + 0.5 + i * 0.065, o, 0.25 + i * 0.05);
    I.impact(E, t + 1.3, o, 0.9);
    I.crash(E, t + 1.3, o, 0.8);
    I.brass(E, t + 1.3, [D - 12, D - 8, D - 5, D], 0.8, o, 1);
    return 0.9;
  },
  reveal: (E, t, o) => {
    I.bell(E, t, D + 24 + Math.floor(Math.random() * 3) * 4, o, 0.2, 0.3);
  },
  shuffle: (E, t, o) => {
    I.whoosh(E, t, 0.45, o, 0.5);
    [D + 12, D + 14, D + 16, D + 19].forEach((m, i) => I.pluck(E, t + 0.3 + i * 0.05, m, 0.15, o, 0.5));
  },
  gameStart: (E, t, o) => {
    I.riser(E, t, 0.9, o, 0.8);
    I.impact(E, t + 0.9, o, 1);
    I.crash(E, t + 0.9, o, 0.8);
    I.brass(E, t + 0.9, [D - 12, D - 8, D - 5, D], 1, o, 1);
    return 0.9;
  },
  drumroll: (E, t, o) => {
    for (let i = 0; i < 26; i++) I.snare(E, t + i * 0.038, o, 0.15 + (i / 26) * 0.5, 0.05);
    I.crash(E, t + 1, o, 1);
    I.impact(E, t + 1, o, 0.9);
    return 0.9;
  },
  boom: (E, t, o) => {
    I.impact(E, t, o, 0.45);
    I.crackle(E, t, o, 0.8, 16);
  },
  win: (E, t, o) => {
    I.brass(E, t, [D, D + 4, D + 7], 0.2, o, 1);
    I.brass(E, t + 0.22, [D, D + 4, D + 7], 0.12, o, 1);
    I.brass(E, t + 0.36, [D + 5, D + 9, D + 12], 0.25, o, 1);
    I.brass(E, t + 0.62, [D + 7, D + 12, D + 16], 1, o, 1.1);
    I.crash(E, t + 0.62, o, 0.8);
    return 0.9;
  },
};
