// Audio engine: mixer (music + sfx buses, reverb, master compressor), a look-ahead
// step sequencer for the music, ducking under big sound effects, and mobile unlock.
import { TRACKS } from './tracks';
import { SFX } from './sfx';

const MUSIC_VOL = 0.3;
const SFX_VOL = 0.9;
const LOOKAHEAD = 0.12;

function readFlag(key, dflt) {
  try {
    const v = localStorage.getItem(key);
    return v === null ? dflt : v === '1';
  } catch {
    return dflt;
  }
}
function writeFlag(key, v) {
  try {
    localStorage.setItem(key, v ? '1' : '0');
  } catch {}
}

function impulse(ctx, seconds = 2.2, decay = 3) {
  const len = Math.floor(ctx.sampleRate * seconds);
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
  }
  return buf;
}

function silentWavUrl() {
  // 0.1 s of silence, 8 kHz mono 8-bit
  const n = 800;
  const b = new ArrayBuffer(44 + n);
  const v = new DataView(b);
  const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF');
  v.setUint32(4, 36 + n, true);
  w(8, 'WAVEfmt ');
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, 8000, true);
  v.setUint32(28, 8000, true);
  v.setUint16(32, 1, true);
  v.setUint16(34, 8, true);
  w(36, 'data');
  v.setUint32(40, n, true);
  for (let i = 0; i < n; i++) v.setUint8(44 + i, 128);
  return URL.createObjectURL(new Blob([b], { type: 'audio/wav' }));
}

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.musicOn = readFlag('tt_music', true);
    this.sfxOn = readFlag('tt_sfx', !readFlag('tt_muted', false));
    this.scene = null; // desired scene
    this.playing = null; // scene currently sequenced
    this.track = null;
    this.stepIndex = 0;
    this.nextTime = 0;
    this.intensity = 0;
    this.timer = null;
    this.listeners = new Set();
  }

  /** Build the graph on a given context (live or offline). */
  build(ctx) {
    this.ctx = ctx;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 8;
    comp.ratio.value = 4;
    comp.attack.value = 0.004;
    comp.release.value = 0.22;
    this.master = ctx.createGain();
    this.master.gain.value = 0.9;
    this.master.connect(comp).connect(ctx.destination);

    this.reverbIn = ctx.createGain();
    const conv = ctx.createConvolver();
    conv.buffer = impulse(ctx);
    const rv = ctx.createGain();
    rv.gain.value = 0.6;
    this.reverbIn.connect(conv).connect(rv).connect(this.master);

    // music: instruments → music → fade (scene changes) → duck (sfx) → master
    this.music = ctx.createGain();
    this.music.gain.value = MUSIC_VOL;
    this.fade = ctx.createGain();
    this.fade.gain.value = 0;
    this.duck = ctx.createGain();
    this.music.connect(this.fade).connect(this.duck).connect(this.master);
    if (!this.musicOn) this.music.gain.value = 0;

    this.sfx = ctx.createGain();
    this.sfx.gain.value = SFX_VOL;
    this.sfx.connect(this.master);
  }

  /** Call from any user gesture; safe to call repeatedly. */
  unlock() {
    if (!this.ctx) {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return;
      this.build(new C({ latencyHint: 'interactive' }));
      document.addEventListener('visibilitychange', () => {
        if (!this.ctx) return;
        if (document.hidden) this.ctx.suspend();
        else this.ctx.resume();
      });
      // iOS: playing an <audio> element moves the page to the "playback" audio session,
      // so Web Audio is heard even when the ring/silent switch is on.
      try {
        const a = new Audio(silentWavUrl());
        a.loop = true;
        a.setAttribute('playsinline', '');
        a.volume = 0.01;
        a.play().catch(() => {});
        this.keepAlive = a;
      } catch {}
      this.timer = setInterval(() => this.tick(), 25);
    }
    if (this.ctx.state === 'suspended' && !document.hidden) this.ctx.resume();
    if (this.scene && this.playing !== this.scene) this.switchTo(this.scene);
  }

  setScene(name) {
    this.scene = name;
    if (this.ctx && this.playing !== name) this.switchTo(name);
  }

  switchTo(name) {
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const fadeOut = this.playing ? 0.3 : 0.01;
    this.fade.gain.cancelScheduledValues(now);
    this.fade.gain.setValueAtTime(this.fade.gain.value, now);
    this.fade.gain.linearRampToValueAtTime(0, now + fadeOut);
    this.playing = name;
    this.track = TRACKS[name] || null;
    this.stepIndex = 0;
    this.nextTime = now + fadeOut + 0.02;
    if (this.track) {
      this.fade.gain.setValueAtTime(0, this.nextTime);
      this.fade.gain.linearRampToValueAtTime(1, this.nextTime + 0.08);
    }
  }

  setIntensity(level) {
    this.intensity = level;
  }

  tick() {
    if (!this.ctx || this.ctx.state !== 'running' || !this.track || !this.musicOn) {
      if (this.ctx && this.track) this.nextTime = Math.max(this.nextTime, this.ctx.currentTime);
      return;
    }
    const horizon = this.ctx.currentTime + LOOKAHEAD;
    if (this.nextTime < this.ctx.currentTime - 0.2) this.nextTime = this.ctx.currentTime + 0.02; // after a stall
    while (this.nextTime < horizon) {
      const step = 60 / this.track.bpm(this) / 4;
      try {
        this.track.step(this, this.stepIndex, this.nextTime, step);
      } catch (e) {
        console.warn('music', e);
      }
      this.nextTime += step;
      this.stepIndex += 1;
    }
  }

  play(name) {
    if (!this.ctx || !this.sfxOn || !SFX[name] || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime + 0.005;
    const duckBy = SFX[name](this, t, this.sfx);
    if (duckBy) this.duckMusic(duckBy, t);
  }

  duckMusic(amount, t) {
    const g = this.duck.gain;
    g.cancelScheduledValues(t);
    g.setValueAtTime(g.value, t);
    g.linearRampToValueAtTime(1 - amount * 0.75, t + 0.04);
    g.linearRampToValueAtTime(1, t + 0.9 + amount * 0.6);
  }

  setMusic(on) {
    this.musicOn = on;
    writeFlag('tt_music', on);
    if (this.ctx) {
      const now = this.ctx.currentTime;
      this.music.gain.cancelScheduledValues(now);
      this.music.gain.setValueAtTime(this.music.gain.value, now);
      this.music.gain.linearRampToValueAtTime(on ? MUSIC_VOL : 0, now + 0.3);
      if (on) {
        this.nextTime = now + 0.05;
      }
    }
    this.emit();
  }

  setSfx(on) {
    this.sfxOn = on;
    writeFlag('tt_sfx', on);
    this.emit();
  }

  onChange(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  emit() {
    for (const fn of this.listeners) fn();
  }
}

/**
 * Offline render for previews/tests: a scene's music for `seconds`, optionally with
 * sound effects at given offsets ([[time, name], ...]). Resolves to an AudioBuffer.
 */
export async function renderOffline({ scene, seconds, intensity = 0, sfx = [], sampleRate = 44100 }) {
  const ctx = new OfflineAudioContext(2, Math.ceil(seconds * sampleRate), sampleRate);
  const E = new AudioEngine();
  E.musicOn = true;
  E.build(ctx);
  E.fade.gain.value = scene ? 1 : 0;
  E.intensity = intensity;
  if (scene) {
    const track = TRACKS[scene];
    let t = 0.05;
    let s = 0;
    while (t < seconds - 0.3) {
      const step = 60 / track.bpm(E) / 4;
      track.step(E, s, t, step);
      t += step;
      s += 1;
    }
  }
  for (const [at, name] of sfx) {
    const d = SFX[name](E, at, E.sfx);
    if (d && scene) E.duckMusic(d, at);
  }
  return ctx.startRendering();
}
