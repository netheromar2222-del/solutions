import { useEffect, useState } from 'react';
import { net } from './net';

export const REACTIONS = ['😂', '🔥', '😱', '👏', '🤡', '💀'];

/** Row of reaction buttons (shown on result pages). */
export function Reactions() {
  const [cool, setCool] = useState(false);
  const send = (emoji) => {
    if (cool) return;
    net.send('react', { emoji });
    setCool(true);
    setTimeout(() => setCool(false), 650);
  };
  return (
    <div className="reactions" role="group" aria-label="تفاعل">
      {REACTIONS.map((e) => (
        <button key={e} type="button" className="react-btn" disabled={cool} onClick={() => send(e)} aria-label={`تفاعل ${e}`}>
          {e}
        </button>
      ))}
    </div>
  );
}

let nextId = 1;
/** Full-screen layer where everyone's reactions float up, with the sender's name. */
export function ReactionLayer({ players }) {
  const [items, setItems] = useState([]);
  useEffect(
    () =>
      net.on((e, d) => {
        if (e !== 'fx' || d.type !== 'reaction') return;
        const p = (window.__ttPlayers || []).find((x) => x.id === d.playerId);
        const id = nextId++;
        const item = { id, emoji: d.emoji, name: p ? p.name : '', x: 8 + Math.random() * 78, drift: (Math.random() - 0.5) * 60, rot: (Math.random() - 0.5) * 40 };
        setItems((list) => [...list.slice(-24), item]);
        setTimeout(() => setItems((list) => list.filter((it) => it.id !== id)), 2600);
      }),
    [],
  );
  return (
    <div className="reaction-layer" aria-hidden="true">
      {items.map((it) => (
        <span key={it.id} className="floater" style={{ left: `${it.x}%`, '--drift': `${it.drift}px`, '--rot': `${it.rot}deg` }}>
          <b>{it.emoji}</b>
          {it.name && <small>{it.name}</small>}
        </span>
      ))}
    </div>
  );
}
