// WebSocket client: auto-reconnect, session restore, clock sync and latency reporting.
const SESSION_KEY = 'tt_session';
const PROFILE_KEY = 'tt_profile';

function safeGet(key) {
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch {
    return null;
  }
}
function safeSet(key, val) {
  try {
    if (val === null) localStorage.removeItem(key);
    else localStorage.setItem(key, JSON.stringify(val));
  } catch {}
}

export const session = {
  get: () => safeGet(SESSION_KEY),
  set: (v) => safeSet(SESSION_KEY, v),
  clear: () => safeSet(SESSION_KEY, null),
};
export const profile = {
  get: () => safeGet(PROFILE_KEY) || { name: '', avatar: '' },
  set: (v) => safeSet(PROFILE_KEY, v),
};

// Questions this device has already seen (short keys from the server, oldest first), so new
// rooms prefer questions nobody at the table has seen yet.
const SEEN_KEY = 'tt_seen';
const SEEN_MAX = 20000;
const SEEN_CHUNK = 1200; // keeps each message under the server's size limit
export const seen = {
  list() {
    try {
      const v = localStorage.getItem(SEEN_KEY);
      return v ? v.split(',') : [];
    } catch {
      return [];
    }
  },
  add(key) {
    if (!key) return;
    try {
      const l = this.list().filter((k) => k !== key);
      l.push(key);
      localStorage.setItem(SEEN_KEY, l.slice(-SEEN_MAX).join(','));
    } catch {}
  },
};

class Net {
  constructor() {
    this.ws = null;
    this.listeners = new Set();
    this.status = 'connecting'; // connecting | open | closed
    this.offset = 0; // serverTime - localTime
    this.rtt = 0;
    this.retry = 0;
    this.queue = [];
    this.pingTimer = null;
  }

  url() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    return `${proto}://${location.host}/ws`;
  }

  connect() {
    if (this.ws && (this.ws.readyState === 0 || this.ws.readyState === 1)) return;
    this.setStatus('connecting');
    const ws = new WebSocket(this.url());
    this.ws = ws;
    ws.onopen = () => {
      this.retry = 0;
      this.setStatus('open');
      const s = session.get();
      if (s && s.code && s.token) this.send('rejoin', s);
      else this.emit('ready', {});
      for (const m of this.queue.splice(0)) ws.send(m);
      this.ping();
      clearInterval(this.pingTimer);
      this.pingTimer = setInterval(() => this.ping(), 5000);
    };
    ws.onmessage = (ev) => {
      let msg;
      try {
        msg = JSON.parse(ev.data);
      } catch {
        return;
      }
      if (msg.e === 'pong') {
        const now = Date.now();
        const rtt = now - msg.d.t;
        this.rtt = this.rtt ? this.rtt * 0.7 + rtt * 0.3 : rtt;
        this.offset = msg.d.serverNow + rtt / 2 - now;
        this.send('rtt', { rtt: Math.round(this.rtt) });
        return;
      }
      if (msg.e === 'joined') {
        session.set({ code: msg.d.code, token: msg.d.token });
        this.sendSeen();
      }
      if (msg.e === 'fx' && msg.d && msg.d.type === 'seen') seen.add(msg.d.key);
      if (msg.e === 'rejoin_failed' || msg.e === 'left') session.clear();
      this.emit(msg.e, msg.d);
    };
    ws.onclose = () => {
      clearInterval(this.pingTimer);
      this.setStatus('closed');
      const wait = Math.min(8000, 500 * 2 ** this.retry++);
      setTimeout(() => this.connect(), wait);
    };
    ws.onerror = () => {};
  }

  sendSeen() {
    const l = seen.list();
    if (!l.length) return;
    for (let i = 0; i < l.length; i += SEEN_CHUNK) this.send('seen', { keys: l.slice(i, i + SEEN_CHUNK), first: i === 0 });
  }

  ping() {
    this.send('ping', { t: Date.now() });
  }

  now() {
    return Date.now() + this.offset;
  }

  send(e, d = {}) {
    const m = JSON.stringify({ e, d });
    if (this.ws && this.ws.readyState === 1) this.ws.send(m);
    else if (e !== 'ping' && e !== 'rtt') this.queue.push(m);
  }

  on(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  emit(e, d) {
    for (const fn of this.listeners) fn(e, d);
  }

  setStatus(s) {
    this.status = s;
    this.emit('status', s);
  }
}

export const net = new Net();
