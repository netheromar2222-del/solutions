import { useEffect, useRef, useState } from 'react';
import { net } from './net';
import { play } from './sound';

export const LETTERS = ['أ', 'ب', 'ج', 'د', 'هـ', 'و', 'ز', 'ح'];
export const CAT_LABEL = {
  sports: 'رياضة',
  quran: 'قرآن',
  sunnah: 'سنة نبوية',
  history: 'تاريخ',
  geography: 'جغرافيا',
  science: 'علوم',
  literature: 'أدب ولغة',
  general: 'ثقافة عامة',
  seerah: 'سيرة وصحابة',
  football: 'كرة القدم',
  flags: 'أعلام ودول',
  proverbs: 'أمثال وتراث',
  media: 'فن وإعلام',
  tech: 'تقنية وإنترنت',
  brands: 'شركات وماركات',
  nature: 'طبيعة وحيوانات',
  space: 'فضاء وفلك',
  logic: 'ألغاز ومنطق',
  food: 'أكلات ومطابخ',
};
export const BONUS_INFO = {
  coordinates: { icon: '📍', name: 'حرب الإحداثيات', rule: 'ضع دبوساً واحداً داخل المنطقة الصحيحة. الأول يأخذ +2، ومن يضعه خارجها −1.' },
  pixel: { icon: '🧩', name: 'البكسل الثقافي', rule: 'الصورة تتضح تدريجياً. أول إجابة صحيحة +2، والخاطئة −1 وتُستبعد.' },
  link: { icon: '🔗', name: 'الكلمة المفقودة', rule: 'ما الذي يربط الكلمات الثلاث؟ أول إجابة صحيحة +2، والخاطئة −1.' },
  censored: { icon: '🕶️', name: 'النص الممسوح', rule: 'الكلمات تظهر تباعاً. أول إجابة صحيحة +2، والخاطئة −1 وتُستبعد.' },
  auction: { icon: '🔨', name: 'مزاد التعويض', rule: 'اختر كل الإجابات الصحيحة من 10 خيارات. كل صحيحة +1 وكل خاطئة −1، فلا تخاطر بما لا تعرفه.' },
};

/** Seconds left until a server timestamp, updating ~10×/s. */
export function useCountdown(endsAt) {
  const [left, setLeft] = useState(() => (endsAt ? Math.max(0, endsAt - net.now()) : 0));
  useEffect(() => {
    if (!endsAt) return;
    let raf;
    const id = setInterval(() => setLeft(Math.max(0, endsAt - net.now())), 100);
    return () => {
      clearInterval(id);
      cancelAnimationFrame(raf);
    };
  }, [endsAt]);
  return left;
}

export function TimerRing({ endsAt, startedAt, size = 64, tick = true }) {
  const left = useCountdown(endsAt);
  const total = Math.max(1, (endsAt || 0) - (startedAt || 0));
  const frac = Math.max(0, Math.min(1, left / total));
  const secs = Math.ceil(left / 1000);
  const lastTick = useRef(null);
  useEffect(() => {
    if (tick && lastTick.current !== null && lastTick.current !== secs) {
      if (secs > 0 && secs <= 3) play('tickUrgent');
      else if (secs > 0 && secs <= 5) play('tick');
      else if (secs === 0 && lastTick.current === 1) play('timeUp');
    }
    lastTick.current = secs;
  }, [secs, tick]);
  // Hex, not CSS variables: Safari ignores var() in SVG attributes.
  const color = frac > 0.5 ? '#2FD8A0' : frac > 0.2 ? '#FFB627' : '#FF5D73';
  const r = size / 2 - 5;
  const C = 2 * Math.PI * r;
  return (
    <div className={`timer ${frac <= 0.2 ? 'timer-urgent' : ''}`} style={{ width: size, height: size }} aria-label={`${secs} ثانية متبقية`}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,.12)" strokeWidth="6" fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth="6"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - frac)}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          style={{ transition: 'stroke-dashoffset .1s linear, stroke .3s' }}
        />
      </svg>
      <span style={{ color }}>{secs}</span>
    </div>
  );
}

export function Avatar({ p, size = 'md', ring }) {
  if (!p) return null;
  return (
    <span className={`avatar avatar-${size} ${ring ? 'avatar-ring' : ''} ${p.connected === false ? 'avatar-off' : ''}`} title={p.name}>
      {p.avatar}
    </span>
  );
}

export function usePlayers(state) {
  const map = {};
  for (const p of state.players) map[p.id] = p;
  return map;
}

export function ScoreStrip({ state, activeId }) {
  const sorted = state.players.filter((p) => !p.removed && !p.spectator).sort((a, b) => b.score - a.score);
  const prev = useRef({});
  const [flash, setFlash] = useState({});
  useEffect(() => {
    const f = {};
    for (const p of state.players) {
      const before = prev.current[p.id];
      if (before !== undefined && before !== p.score) f[p.id] = p.score - before;
      prev.current[p.id] = p.score;
    }
    if (Object.keys(f).length) {
      setFlash(f);
      const id = setTimeout(() => setFlash({}), 1800);
      return () => clearTimeout(id);
    }
  }, [state.players]);
  return (
    <div className="scorestrip" role="list" aria-label="النقاط">
      {sorted.map((p) => (
        <div
          key={p.id}
          role="listitem"
          className={`chip-score ${p.id === state.me ? 'is-me' : ''} ${p.id === activeId ? 'is-active' : ''} ${!p.connected ? 'is-off' : ''}`}
        >
          <span className="cs-avatar">{p.avatar}</span>
          <span className="cs-name">{p.name}</span>
          <b className="cs-score">{fmtNum(p.score)}</b>
          {p.done && <span className="cs-done" aria-label="أجاب">✓</span>}
          {!p.connected && <span className="cs-off" aria-label="غير متصل">⚡</span>}
          {flash[p.id] !== undefined && (
            <span className={`cs-delta ${flash[p.id] > 0 ? 'up' : 'down'}`}>
              {fmtDelta(flash[p.id])}
            </span>
          )}
        </div>
      ))}
    </div>
  );
}

export const CAT_ICON = {
  sports: '🏅',
  quran: '📖',
  sunnah: '🕌',
  history: '🏛️',
  geography: '🌍',
  science: '🔬',
  literature: '✒️',
  general: '💡',
  seerah: '🌙',
  football: '⚽',
  flags: '🚩',
  proverbs: '📜',
  media: '🎬',
  tech: '💻',
  brands: '🏷️',
  nature: '🐾',
  space: '🪐',
  logic: '🤔',
  food: '🍲',
};
// Question levels: 1 سالكة, 2 مطبّ, 3 ورطة.
export const LEVEL_LABEL = ['', 'سالكة', 'مطبّ', 'ورطة'];
export const LEVEL_ICON = ['', '🟢', '🟡', '🔴'];

/** Level pill (name on its colour). Kept the old name so every screen picks it up. */
export function Difficulty({ level, big }) {
  return <span className={`lvl lvl-${level} ${big ? 'lvl-big' : ''}`}>{LEVEL_LABEL[level] || ''}</span>;
}

// Signed numbers wrapped in a left-to-right isolate so "+2" / "−1" don't flip inside Arabic text.
export function fmtDelta(n) {
  if (!n) return '0';
  return `\u2066${n > 0 ? '+' : '−'}${Math.abs(n)}\u2069`;
}
export function fmtNum(n) {
  return n < 0 ? `\u2066−${Math.abs(n)}\u2069` : String(n);
}
