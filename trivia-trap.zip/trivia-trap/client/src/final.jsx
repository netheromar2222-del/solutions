import { ActionBar } from './actionbar';
import { useEffect, useRef, useState } from 'react';
import { net } from './net';
import { play, setScene } from './sound';
import { fmtNum, usePlayers } from './ui';
import { Fireworks } from './fireworks';
import { Reactions } from './reactions';
import { shareResult } from './share';

/** "Moments of the game": cards shown before the podium; the host moves everyone on. */
function Highlights({ state, items, index }) {
  const h = items[index];
  const canGo = state.controllerId === state.me;
  const ctrl = state.players.find((p) => p.id === state.controllerId);
  useEffect(() => play('reveal'), [index]);
  return (
    <section className="moments">
      <p className="kicker">
        لحظات اللعبة · {index + 1} من {items.length}
      </p>
      <article key={index} className={`moment moment-${h.kind}`}>
        <span className="moment-icon">{h.icon}</span>
        <h2>{h.title}</h2>
        <p className="moment-text">{h.text}</p>
        {h.question && <p className="moment-q">«{h.question}»</p>}
        {h.answer && <p className="moment-a">الإجابة: {h.answer}</p>}
      </article>
      <div className="moment-dots" aria-hidden="true">
        {items.map((_, k) => (
          <i key={k} className={k === index ? 'on' : k < index ? 'done' : ''} />
        ))}
      </div>
      <Reactions />
      <ActionBar>
        {canGo ? (
          <button
            className="btn btn-primary btn-big"
            onClick={() => {
              play('tap');
              net.send('next');
            }}
          >
            {index + 1 < items.length ? 'اللحظة التالية' : 'عرض النتائج النهائية'}
          </button>
        ) : (
          <p className="waiting">بانتظار {ctrl ? ctrl.name : 'المضيف'} للمتابعة…</p>
        )}
      </ActionBar>
    </section>
  );
}

export function GameOver({ state }) {
  const f = state.final;
  const pl = usePlayers(state);
  const isHost = state.me === state.hostId;
  const iWon = f.winners.includes(state.me);
  const highlights = f.highlights || [];
  const stage = (f.moment || 0) < highlights.length ? 'moments' : 'podium';
  const [shareMsg, setShareMsg] = useState('');
  const once = useRef(false);

  useEffect(() => {
    setScene(stage === 'moments' ? 'results' : null);
    if (stage !== 'podium' || once.current) return;
    once.current = true;
    play('drumroll');
    const a = setTimeout(() => play('win'), 1000);
    const b = setTimeout(() => setScene('victory'), 1900);
    return () => {
      clearTimeout(a);
      clearTimeout(b);
    };
  }, [stage]);

  const ranking = f.ranking.map((r) => ({ ...r, p: pl[r.id] })).filter((r) => r.p && !r.p.spectator);
  let lastScore = null;
  let lastRank = 0;
  const ranked = ranking.map((r, i) => {
    if (r.score !== lastScore) {
      lastRank = i + 1;
      lastScore = r.score;
    }
    return { ...r, rank: lastRank };
  });
  const podium = ranked.slice(0, 3);
  const order = [podium[1], podium[0], podium[2]].filter(Boolean);
  const spectator = pl[state.me]?.spectator;

  const share = async () => {
    setShareMsg('جارٍ تجهيز الصورة…');
    const res = await shareResult({ final: f, ranked, pl, code: state.code });
    setShareMsg(res === 'shared' ? '' : res === 'downloaded' ? 'حُفظت الصورة في جهازك' : res === 'cancel' ? '' : 'تعذّر إنشاء الصورة');
    if (res === 'downloaded') setTimeout(() => setShareMsg(''), 2500);
  };

  if (stage === 'moments') return <Highlights state={state} items={highlights} index={f.moment || 0} />;

  return (
    <main className="gameover">
      <Fireworks />
      <header className="go-head">
        <p className="kicker">انتهت اللعبة{f.tiebreaks ? ` بعد ${f.tiebreaks} جولة حسم` : ''}</p>
        <h1 className="go-title">
          {f.winners.length > 1 ? 'تعادل في الصدارة!' : iWon ? 'أنت الفائز!' : `الفائز: ${pl[f.winners[0]]?.name}`}
        </h1>
      </header>

      <div className="podium" aria-label="المراكز الأولى">
        {order.map((r) => (
          <div key={r.id} className={`pod pod-${r.rank} ${f.winners.includes(r.id) ? 'pod-winner' : ''}`}>
            {f.winners.includes(r.id) && (
              <span className="crown" aria-hidden="true">
                👑
              </span>
            )}
            <span className="pod-av">{r.p.avatar}</span>
            <span className="pod-name">{r.p.name}</span>
            <div className="pod-block">
              <b>{fmtNum(r.score)}</b>
              <small>المركز {r.rank}</small>
            </div>
          </div>
        ))}
      </div>

      <Reactions />

      {f.badges.length > 0 && (
        <section className="badges">
          <h2>الأوسمة</h2>
          <div className="badge-grid">
            {f.badges.map((b, i) => (
              <article key={b.key} className="badge-card" style={{ animationDelay: `${300 + i * 140}ms` }}>
                <span className="badge-icon">{b.icon}</span>
                <div>
                  <h3>{b.title}</h3>
                  <p className="muted small">{b.desc}</p>
                  <p className="badge-who">
                    {b.playerIds.map((id) => (
                      <span key={id}>
                        {pl[id]?.avatar} {pl[id]?.name}
                      </span>
                    ))}
                    <em>
                      {b.value}
                      {b.unit}
                    </em>
                  </p>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      <section className="card">
        <h2>الترتيب الكامل</h2>
        <ol className="rank-list">
          {ranked.map((r) => (
            <li key={r.id} className={`${r.id === state.me ? 'is-me' : ''} ${r.removed ? 'is-off' : ''}`}>
              <span className="rk">{r.rank}</span>
              <span className="avatar avatar-sm">{r.p.avatar}</span>
              <span className="bd-name">
                {r.p.name}
                {r.removed && <small className="muted"> (غادر)</small>}
              </span>
              <b>{fmtNum(r.score)}</b>
            </li>
          ))}
        </ol>
      </section>

      <ActionBar>
        <button className="btn btn-share" onClick={share}>
          📤 شارك النتيجة
        </button>
        {shareMsg && <p className="waiting">{shareMsg}</p>}
        {isHost ? (
          <button className="btn btn-primary btn-big" onClick={() => net.send('play_again')}>
            العب مرة أخرى بنفس الغرفة
          </button>
        ) : (
          <p className="waiting">{spectator ? 'ستدخل اللعبة القادمة عندما يبدأها المضيف.' : 'بانتظار المضيف لبدء جولة جديدة…'}</p>
        )}
        <button className="btn btn-ghost btn-small" onClick={() => net.send('leave')}>
          خروج
        </button>
      </ActionBar>
    </main>
  );
}
