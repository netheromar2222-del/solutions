// Builds a 1080×1920 "story" image of the final result and shares or downloads it.
const W = 1080;
const H = 1920;
const C = { night: '#1E1A4D', night2: '#2A2569', night3: '#373181', paper: '#FFF4DE', saffron: '#FFB627', coral: '#FF5D73', mint: '#2FD8A0', muted: '#B2ACDF' };
const DISPLAY = "'Lalezar', 'IBM Plex Sans Arabic', 'Segoe UI', Tahoma, sans-serif";
const BODY = "'IBM Plex Sans Arabic', 'Segoe UI', Tahoma, sans-serif";

function loadImage(src) {
  return new Promise((resolve) => {
    const im = new Image();
    im.onload = () => resolve(im);
    im.onerror = () => resolve(null);
    im.src = src;
  });
}

function roundRect(ctx, x, y, w, h, r, fill) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
}

function text(ctx, str, x, y, { size = 40, color = C.paper, font = BODY, weight = 400, align = 'center', max } = {}) {
  ctx.font = `${weight} ${size}px ${font}`;
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.direction = 'rtl';
  ctx.fillText(str, x, y, max);
}

export async function drawResult({ final, ranked, pl }) {
  try {
    await document.fonts.ready;
  } catch {}
  const cv = document.createElement('canvas');
  cv.width = W;
  cv.height = H;
  const ctx = cv.getContext('2d');

  // background
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, '#26206a');
  g.addColorStop(1, C.night);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  // confetti specks
  const colors = [C.saffron, C.coral, C.mint, C.paper];
  for (let i = 0; i < 70; i++) {
    ctx.save();
    ctx.translate(Math.random() * W, Math.random() * 520);
    ctx.rotate(Math.random() * Math.PI);
    ctx.fillStyle = colors[i % colors.length];
    ctx.globalAlpha = 0.55;
    ctx.fillRect(-7, -3, 14, 6);
    ctx.restore();
  }

  // logo + slogan
  const logo = await loadImage('/brand/wordmark-for-dark-bg.svg');
  if (logo) {
    const lw = 420;
    const lh = (logo.height / logo.width) * lw || 220;
    ctx.drawImage(logo, (W - lw) / 2, 90, lw, lh);
  } else {
    text(ctx, 'ورطة', W / 2, 260, { size: 180, font: DISPLAY });
  }
  text(ctx, 'إذا وقعت… اسحبهم معك', W / 2, 400, { size: 48, color: C.saffron, font: DISPLAY });

  // winner
  const winners = final.winners.map((id) => pl[id]).filter(Boolean);
  const top = ranked[0];
  roundRect(ctx, 90, 470, W - 180, 390, 48, C.saffron);
  roundRect(ctx, 90, 470, W - 180, 370, 48, '#FFC24A');
  text(ctx, winners.length > 1 ? 'تعادل في الصدارة' : '👑 الفائز', W / 2, 560, { size: 52, color: C.night, font: DISPLAY });
  text(ctx, winners.map((p) => p.avatar).join(' '), W / 2, 690, { size: 120 });
  text(ctx, winners.map((p) => p.name).join(' و'), W / 2, 770, { size: 60, color: C.night, weight: 700, max: W - 260 });
  if (top) text(ctx, `النقاط: ${top.score}`, W / 2, 822, { size: 34, color: C.night3, weight: 700 });

  // top 3 + rest count
  let y = 960;
  ranked.slice(0, 5).forEach((r) => {
    roundRect(ctx, 120, y - 62, W - 240, 92, 26, r.rank === 1 ? 'rgba(255,182,39,.18)' : C.night2);
    text(ctx, String(r.rank), W - 170, y, { size: 44, font: DISPLAY, color: C.muted });
    text(ctx, `${r.p.avatar}  ${r.p.name}`, W - 230, y, { size: 42, align: 'right', weight: 700, max: 560 });
    text(ctx, String(r.score), 190, y, { size: 48, font: DISPLAY, align: 'left', color: r.score < 0 ? C.coral : C.paper });
    y += 112;
  });

  // badges (up to 4)
  const badges = (final.badges || []).slice(0, 4);
  if (badges.length) {
    y += 20;
    text(ctx, 'الأوسمة', W / 2, y, { size: 44, color: C.saffron, font: DISPLAY });
    y += 70;
    for (const b of badges) {
      const names = b.playerIds.map((id) => pl[id] && pl[id].name).filter(Boolean).join('، ');
      text(ctx, `${b.icon} ${b.title}: ${names}`, W / 2, y, { size: 38, max: W - 160 });
      y += 66;
    }
  }

  // footer
  text(ctx, 'لعبة أسئلة جماعية بالعربي — العب مع أصدقائك', W / 2, H - 110, { size: 34, color: C.muted });
  return cv;
}

/** Returns 'shared' | 'downloaded' | 'cancel' | 'error'. */
export async function shareResult(args) {
  try {
    const cv = await drawResult(args);
    const blob = await new Promise((r) => cv.toBlob(r, 'image/png'));
    if (!blob) return 'error';
    const file = new File([blob], 'warta-result.png', { type: 'image/png' });
    if (navigator.canShare && window.isSecureContext && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: 'ورطة', text: 'نتيجة لعبة ورطة 🎉' });
        return 'shared';
      } catch (e) {
        if (e && e.name === 'AbortError') return 'cancel';
      }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'warta-result.png';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return 'downloaded';
  } catch (e) {
    console.warn('share', e);
    return 'error';
  }
}
