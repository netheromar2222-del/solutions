import { ActionBar } from './actionbar';
import { useEffect, useMemo, useState } from 'react';
import { net } from './net';
import { play } from './sound';
import { fmtDelta, fmtNum, useCountdown } from './ui';
import { Reactions } from './reactions';

const ROW_H = 66;

function rankMap(list) {
  // Equal scores share a rank.
  const out = {};
  let last = null;
  let rank = 0;
  list.forEach((r, i) => {
    if (r.score !== last) {
      rank = i + 1;
      last = r.score;
    }
    out[r.id] = rank;
  });
  return out;
}

/** Counts from `from` to `to` once `go` turns true. */
function useCount(from, to, go, ms = 900) {
  const [v, setV] = useState(from);
  useEffect(() => {
    if (!go || from === to) {
      setV(go ? to : from);
      return;
    }
    let raf;
    const t0 = performance.now();
    const step = (t) => {
      const k = Math.min(1, (t - t0) / ms);
      const e = 1 - Math.pow(1 - k, 3);
      setV(Math.round(from + (to - from) * e));
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [from, to, go, ms]);
  return v;
}

function Row({ p, from, to, delta, top, rank, move, me, moved, details, highlight }) {
  const score = useCount(from, to, moved);
  return (
    <li
      className={`st-row ${me ? 'is-me' : ''} ${highlight ? 'is-hl' : ''} ${!p.connected ? 'is-off' : ''}`}
      style={{ transform: `translateY(${top}px)` }}
    >
      <span className="st-rank">
        <b>{rank}</b>
        {moved && move !== 0 && <i className={move > 0 ? 'mv-up' : 'mv-down'}>{move > 0 ? `\u2066▲${move}\u2069` : `\u2066▼${-move}\u2069`}</i>}
      </span>
      <span className="st-av">{p.avatar}</span>
      <span className="st-main">
        <span className="st-name">{p.name}</span>
        {details && <span className="st-details">{details}</span>}
      </span>
      <span className={`st-delta ${delta > 0 ? 'up' : delta < 0 ? 'down' : 'zero'}`}>{fmtDelta(delta)}</span>
      <b className="st-total">{fmtNum(score)}</b>
    </li>
  );
}

/**
 * Animated leaderboard: rows start in the previous order with previous totals,
 * then slide to their new places while the totals count up.
 */
export function Standings({ state, before = {}, deltas = {}, details = {}, highlight = {} }) {
  const players = state.players.filter((p) => !p.removed && !p.spectator);
  const [moved, setMoved] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => {
      setMoved(true);
      play('shuffle');
    }, 900);
    return () => clearTimeout(id);
  }, []);

  const { prevOrder, newOrder, prevRank, newRank } = useMemo(() => {
    const prev = players
      .map((p) => ({ id: p.id, score: before[p.id] ?? p.score - (deltas[p.id] || 0) }))
      .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
    const next = players.map((p) => ({ id: p.id, score: p.score })).sort((a, b) => b.score - a.score || prev.findIndex((x) => x.id === a.id) - prev.findIndex((x) => x.id === b.id));
    return {
      prevOrder: prev.map((r) => r.id),
      newOrder: next.map((r) => r.id),
      prevRank: rankMap(prev),
      newRank: rankMap(next),
    };
  }, [state.players]);

  const byId = Object.fromEntries(players.map((p) => [p.id, p]));
  return (
    <ol className="standings" style={{ height: players.length * (ROW_H + 8) }} aria-label="الترتيب">
      {players.map((p) => {
        const idx = (moved ? newOrder : prevOrder).indexOf(p.id);
        const fromScore = before[p.id] ?? p.score - (deltas[p.id] || 0);
        return (
          <Row
            key={p.id}
            p={byId[p.id]}
            from={fromScore}
            to={p.score}
            delta={deltas[p.id] || 0}
            top={idx * (ROW_H + 8)}
            rank={moved ? newRank[p.id] : prevRank[p.id]}
            move={prevRank[p.id] - newRank[p.id]}
            me={p.id === state.me}
            moved={moved}
            details={details[p.id]}
            highlight={highlight[p.id]}
          />
        );
      })}
    </ol>
  );
}

/** Sticky footer on result screens: only the host (or acting host) can move on. */
export function NextBar({ state, label, auto = false }) {
  const canGo = state.controllerId === state.me;
  const ctrl = state.players.find((p) => p.id === state.controllerId);
  const left = useCountdown(auto ? state.endsAt : null);
  const secs = Math.ceil(left / 1000);
  const total = auto && state.endsAt ? Math.max(1, state.endsAt - state.startedAt) : 1;
  return (
    <ActionBar>
      {auto && <div className="auto-progress" style={{ transform: `scaleX(${Math.max(0, left / total)})` }} aria-hidden="true" />}
      {canGo ? (
        <button
          className="btn btn-primary btn-big"
          onClick={() => {
            play('tap');
            net.send('next');
          }}
        >
          {label}
          {auto && secs > 0 ? ` (${secs})` : ''}
        </button>
      ) : auto ? (
        <p className="waiting">
          {label} خلال {secs} {secs <= 2 ? 'ثانية' : 'ثوانٍ'}…
        </p>
      ) : (
        <p className="waiting">بانتظار {ctrl ? ctrl.name : 'المضيف'} للمتابعة…</p>
      )}
    </ActionBar>
  );
}

/** What the "next" button leads to after the current screen. */
export function nextLabel(state) {
  const { round, settings, phase, inTiebreak, standings } = state;
  if (phase === 'ROUND_SCORING' || phase === 'BONUS_RESULTS') return 'عرض الترتيب العام';
  const from = standings ? standings.from : 'round';
  if (from === 'round' && round % 2 === 0 && (settings.bonusTypes.length || settings.auctionEnabled) && !inTiebreak) return 'إلى الجولة الإضافية';
  if (inTiebreak || from === 'auction') return 'النتائج النهائية';
  if (round >= settings.rounds) return settings.auctionEnabled && !state.auctionDone ? 'إلى مزاد التعويض' : 'النتائج النهائية';
  return 'السؤال التالي';
}

/** Full-page overall standings, shown after every round's details page. */
export function StandingsPage({ state }) {
  const st = state.standings;
  const title = state.inTiebreak
    ? 'الترتيب بعد جولة الحسم'
    : st.from === 'auction'
      ? 'الترتيب بعد مزاد التعويض'
      : st.from === 'bonus'
        ? `الترتيب بعد الجولة الإضافية`
      : `الترتيب بعد الجولة ${state.round} من ${state.settings.rounds}`;
  const left = state.settings.rounds - state.round;
  return (
    <section className="stage standings-page">
      <p className="kicker">الترتيب العام</p>
      <h2 className="st-title">{title}</h2>
      {!state.inTiebreak && st.from !== 'auction' && (
        <p className="muted small">{left > 0 ? `باقي ${left} ${left === 1 ? 'جولة' : left === 2 ? 'جولتان' : left <= 10 ? 'جولات' : 'جولة'}` : 'كانت هذه الجولة الأخيرة'}</p>
      )}
      <Standings state={state} before={st.before} deltas={st.deltas} />
      <Reactions />
      <NextBar state={state} label={nextLabel(state)} auto />
    </section>
  );
}
