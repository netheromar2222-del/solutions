import { useEffect, useRef } from 'react';
import { net } from './net';
import { play } from './sound';
import { Avatar, CAT_ICON, CAT_LABEL, Difficulty, LETTERS, TimerRing, fmtDelta, usePlayers } from './ui';
import { NextBar, Standings, nextLabel } from './standings';
import { Reactions } from './reactions';

export function Selection({ state }) {
  const pl = usePlayers(state);
  const t = state.turn;
  const active = pl[t.activeId];
  const mine = t.activeId === state.me;
  const step = t.category ? 'level' : 'category';
  const kicker = mine
    ? step === 'category'
      ? 'دورك! اختر الفئة'
      : 'اختر المستوى'
    : step === 'category'
      ? 'يختار الفئة الآن'
      : 'يختار المستوى الآن';
  return (
    <section className="stage">
      <div className="stage-head">
        <div>
          <p className="kicker">{kicker}</p>
          <h2 className="who">
            <Avatar p={active} size="lg" /> {mine ? 'أنت' : active?.name}
          </h2>
        </div>
        <TimerRing endsAt={state.endsAt} startedAt={state.startedAt} />
      </div>

      {mine && step === 'category' && (
        <>
          <div className="pick-cats">
            {t.categories.map((c) => (
              <button
                key={c}
                className="pick-cat"
                onClick={() => {
                  play('tap');
                  net.send('select_category', { category: c });
                }}
              >
                <span className="ci" aria-hidden="true">
                  {CAT_ICON[c]}
                </span>
                {CAT_LABEL[c]}
              </button>
            ))}
          </div>
          <p className="hint small">بعدها تختار المستوى بتلميح عن كل سؤال. إن لم تختر خلال الوقت يُختار عشوائياً.</p>
        </>
      )}

      {mine && step === 'level' && (
        <>
          <p className="pick-head">
            <span aria-hidden="true">{CAT_ICON[t.category]}</span> {CAT_LABEL[t.category]}
          </p>
          <p className="pick-hint-line">لا ترى السؤال، فقط تلميحاً عنه. الأصعب يُوقع الآخرين أكثر… وقد يُوقعك أنت.</p>
          <div className="pick-levels">
            {t.levels.map((l) => (
              <button
                key={l.level}
                className={`pick-level l${l.level}`}
                disabled={!l.available}
                onClick={() => {
                  play('tap');
                  net.send('select_level', { level: l.level });
                }}
              >
                <Difficulty level={l.level} big />
                <span className="hint-text">{l.available ? l.hint || 'بدون تلميح' : 'غير متوفر في هذه الفئة'}</span>
              </button>
            ))}
          </div>
        </>
      )}

      {!mine && (
        <div className="teaser">
          <p className="teaser-title">{step === 'category' ? `${active?.name || ''} يختار بين:` : `${active?.name || ''} اختار:`}</p>
          <div className="watch-cats">
            {t.categories.map((c, i) => (
              <span
                key={c}
                className={`watch-cat ${t.category ? (t.category === c ? 'on' : 'dim') : ''}`}
                style={{ animationDelay: `${i * 90}ms` }}
              >
                <span aria-hidden="true">{CAT_ICON[c]}</span> {CAT_LABEL[c]}
              </span>
            ))}
          </div>
          {step === 'level' && (
            <>
              <p className="muted small">والآن يختار المستوى…</p>
              <div className="watch-levels">
                {t.levels
                  .filter((l) => l.available)
                  .map((l) => (
                    <Difficulty key={l.level} level={l.level} big />
                  ))}
              </div>
            </>
          )}
          <p className="muted small">هل سيغامر بالورطة؟ السؤال سيظهر للجميع فور اختياره.</p>
        </div>
      )}
    </section>
  );
}

export function Question({ state }) {
  const q = state.question;
  const pl = usePlayers(state);
  const active = pl[q.activeId];
  const mine = q.activeId === state.me;
  const answered = q.myAnswer !== null;
  const needWarta = answered && !q.wartaDone;

  const answer = (i) => {
    if (answered || !q.participant) return;
    play('tap');
    net.send('submit_answer', { option: i });
  };

  return (
    <section className="stage">
      <div className="stage-head">
        <div>
          <p className="kicker">
            {mine ? 'سؤالك' : <>سؤال {active?.name}</>} · {CAT_LABEL[q.category]}
            {q.autoPicked && <span className="muted"> (اختيار تلقائي)</span>}
          </p>
          <Difficulty level={q.difficulty} />
        </div>
        <TimerRing endsAt={state.endsAt} startedAt={state.startedAt} />
      </div>
      <h2 className="q-text">{q.text}</h2>

      <div className={`options ${q.options.length > 4 ? 'many' : ''} ${answered ? 'locked' : ''} ${!q.participant ? 'watching' : ''}`}>
        {q.options.map((o, i) => (
          <button
            key={i}
            className={`opt ${q.myAnswer === i ? 'picked' : ''}`}
            disabled={!q.participant || (answered && q.myAnswer !== i)}
            onClick={() => answer(i)}
          >
            <span className="opt-letter">{LETTERS[i]}</span>
            <span className="opt-text">{o}</span>
          </button>
        ))}
      </div>

      {needWarta && (
        <div className="warta-panel" role="group" aria-label="اقنصه">
          <p className="warta-title">
            <b>🎯 اقنصه:</b> من تتوقع أنه سيُخطئ؟
          </p>
          <p className="muted small">إن أخطأ: +1 لك و−1 له. إن أصاب: −1 لك و+1 له.</p>
          <div className="warta-row">
            {q.wartaTargets.map((id) => (
              <button
                key={id}
                className="warta-btn"
                onClick={() => {
                  play('tap');
                  net.send('submit_warta', { targetId: id });
                }}
              >
                <span aria-hidden="true">{pl[id]?.avatar}</span> {pl[id]?.name}
                {id === q.activeId && <small> (صاحب السؤال)</small>}
              </button>
            ))}
          </div>
          <button className="btn btn-ghost btn-small" onClick={() => net.send('submit_warta', { targetId: null })}>
            بدون قنص
          </button>
        </div>
      )}
      {answered && !needWarta && (
        <p className="waiting">
          {q.myWarta ? <>قنصت {pl[q.myWarta]?.name}. </> : null}تم تسجيل إجابتك. بانتظار البقية…
        </p>
      )}
      {!answered && mine && <p className="hint">أجب أنت أيضاً. إن أصبت: +2 ونقطة عن كل من يخطئ.</p>}
    </section>
  );
}

/** Joins Arabic names: "أ" / "أ وب" / "أ، ب وج". */
export function joinNames(names) {
  if (names.length <= 1) return names.join('');
  return `${names.slice(0, -1).join('، ')} و${names[names.length - 1]}`;
}

export function Results({ state }) {
  const r = state.results;
  const pl = usePlayers(state);
  const active = pl[r.activeId];
  const me = state.me;
  const played = useRef(false);
  const opts = r.question.options;

  useEffect(() => {
    if (played.current) return;
    played.current = true;
    // Sequenced so sounds never pile up: trap sting → my answer → my bet.
    let at = 150;
    if (r.victims.length) {
      play('trap');
      at = 1300;
    }
    const mine = r.answers[me];
    if (mine !== undefined) {
      setTimeout(() => play(mine === r.correct ? 'correct' : 'wrong'), at);
      at += 700;
    }
    const b = r.wartaResults[me];
    if (b === 'caught') setTimeout(() => play('bluffWin'), at);
    if (b === 'escaped') setTimeout(() => play('bluffLose'), at);
  }, []);

  const byOption = opts.map((_, i) =>
    Object.entries(r.answers)
      .filter(([, a]) => a === i)
      .map(([id]) => pl[id])
      .filter(Boolean),
  );
  const victimNames = r.victims.map((id) => pl[id]?.name).filter(Boolean);
  const wartaList = Object.entries(r.wartas || {})
    .map(([bettor, target]) => ({ bettor: pl[bettor], target: pl[target], res: r.wartaResults[bettor] }))
    .filter((w) => w.bettor && w.target);
  const activeAns = r.activeAnswer;

  // Plain-language reasons for every player's points this round
  const rows = Object.keys(r.deltas)
    .map((id) => {
      const p = pl[id];
      if (!p) return null;
      const a = r.answers[id];
      const reasons = [];
      const bd = r.breakdown[id] || {};
      if (a === undefined) reasons.push({ t: 'لم يُجب', v: 0 });
      else if (a === r.correct) reasons.push({ t: `أجاب «${opts[a]}» صحيحاً`, v: 2, ok: true });
      else if (r.victims.includes(id)) reasons.push({ t: `اختار «${opts[a]}» نفس إجابة ${active?.name} الخاطئة`, v: 0, bad: true });
      else reasons.push({ t: `أجاب «${opts[a]}» خطأ`, v: 0, bad: true });
      if (id === r.activeId && bd.bonus) {
        reasons.push({
          t: r.activeCorrect ? `أخطأ ${bd.bonus} من اللاعبين في سؤاله` : `اختار ${bd.bonus} من اللاعبين نفس إجابته`,
          v: bd.bonus,
          ok: true,
        });
      }
      if (id === r.loneId) reasons.push({ t: '⭐ الوحيد الذي أصاب', v: 1, ok: true });
      const mine2 = r.wartas[id];
      const wr = r.wartaResults[id];
      if (mine2 && wr === 'caught') reasons.push({ t: `قنص ${pl[mine2]?.name} فأصابه`, v: 1, ok: true });
      if (mine2 && wr === 'escaped') reasons.push({ t: `قنص ${pl[mine2]?.name} فأفلت`, v: -1, bad: true });
      if (mine2 && wr === 'void') reasons.push({ t: `قنص ${pl[mine2]?.name} لكنه لم يُجب`, v: 0 });
      for (const [bettor, target] of Object.entries(r.wartas || {})) {
        if (target !== id) continue;
        const res = r.wartaResults[bettor];
        if (res === 'caught') reasons.push({ t: `قنصه ${pl[bettor]?.name} فأصابه`, v: -1, bad: true });
        if (res === 'escaped') reasons.push({ t: `أفلت من قنص ${pl[bettor]?.name}`, v: 1, ok: true });
      }
      return { p, d: r.deltas[id], reasons, own: id === r.activeId };
    })
    .filter(Boolean)
    .sort((a, b) => (b.own ? 1 : 0) - (a.own ? 1 : 0) || b.d - a.d);

  return (
    <section className="stage details">
      <p className="kicker">
        تفاصيل الجولة {state.round} من {state.settings.rounds}
      </p>
      <h2 className="q-text small">{r.question.text}</h2>
      <p className="muted small">
        سؤال {active?.name} · {CAT_LABEL[r.question.category]} · <Difficulty level={r.question.difficulty} />
      </p>
      {r.question.hint && (
        <p className="picked-on">
          {r.autoPicked ? 'اختير تلقائياً، وتلميحه:' : `اختاره ${active?.name} على تلميح:`} <b>«{r.question.hint}»</b>
        </p>
      )}

      {r.loneId && (
        <p className="lone-banner" role="status">
          ⭐ <b>{pl[r.loneId]?.name}</b> الوحيد الذي عرف الإجابة! +1 إضافية
        </p>
      )}
      {r.victims.length > 0 && (
        <div className="trap-stamp" role="status">
          <span className="stamp">وقعوا في الفخ!</span>
          <p>
            <b>{joinNames(victimNames)}</b> {victimNames.length > 1 ? 'اختاروا' : 'اختار'} نفس إجابة <b>{active?.name}</b> الخاطئة
          </p>
        </div>
      )}

      <div className="key-cards">
        <div className="key-card ok">
          <small>الإجابة الصحيحة</small>
          <b>{opts[r.correct]}</b>
        </div>
        <div className={`key-card ${activeAns === null ? '' : r.activeCorrect ? 'ok' : 'bad'}`}>
          <small>إجابة {active?.name} (صاحب السؤال)</small>
          <b>{activeAns === null ? 'لم يُجب' : `${opts[activeAns]} ${r.activeCorrect ? '✓' : '✗'}`}</b>
        </div>
      </div>

      <h3 className="section-title">من اختار ماذا</h3>
      <div className="answer-sheet">
        {/* Only the correct answer, the asker's pick, and options someone actually chose */}
        {opts
          .map((o, i) => ({ o, i }))
          .filter(({ i }) => i === r.correct || i === activeAns || byOption[i].length > 0)
          .map(({ o, i }, k) => (
          <div
            key={i}
            className={`as-row ${i === r.correct ? 'is-correct' : ''} ${i === activeAns && i !== r.correct ? 'is-trap' : ''}`}
            style={{ animationDelay: `${k * 70}ms` }}
          >
            <span className="opt-letter">{LETTERS[i]}</span>
            <span className="as-text">
              <span>
                {o}
                {i === r.correct && <small className="as-tag"> · الصحيحة</small>}
                {i === activeAns && <small className="as-tag"> · اختيار {active?.name}</small>}
              </span>
              <span className="as-names">
                {byOption[i].length ? (
                  byOption[i].map((p) => (
                    <span key={p.id} className={`name-chip ${p.id === r.loneId ? 'lone' : ''}`}>
                      {p.name}
                      {p.id === r.loneId && ' ⭐'}
                    </span>
                  ))
                ) : (
                  <span className="as-none">لم يخترها أحد</span>
                )}
              </span>

            </span>
          </div>
        ))}
        {Object.keys(r.answers).length < Object.keys(r.deltas).length && (
          <p className="as-summary">
            لم يُجب:{' '}
            {joinNames(
              Object.keys(r.deltas)
                .filter((id) => r.answers[id] === undefined)
                .map((id) => pl[id]?.name)
                .filter(Boolean),
            )}
          </p>
        )}
      </div>

      {wartaList.length > 0 && (
        <>
          <h3 className="section-title">🎯 القنص</h3>
          <ul className="warta-list">
            {wartaList.map(({ bettor, target, res }) => (
              <li key={bettor.id} className={res}>
                <span>
                  <b>{bettor.name}</b> قنص <b>{target.name}</b>
                </span>
                <em>{res === 'caught' ? 'أصابه' : res === 'escaped' ? 'أفلت' : 'لم يُجب'}</em>
              </li>
            ))}
          </ul>
        </>
      )}

      <h3 className="section-title">نقاط هذه الجولة</h3>
      <ul className="points-list">
        {rows.map(({ p, d, reasons, own }) => (
          <li key={p.id} className={`${p.id === me ? 'is-me' : ''} ${own ? 'is-own' : ''}`}>
            <div className="pt-head">
              <span className="pt-name">
                <span className="pt-av" aria-hidden="true">{p.avatar}</span>
                {p.name}
                {own && <span className="own-tag">صاحب السؤال</span>}
                {p.id === r.loneId && <span className="lone-tag">⭐ الوحيد</span>}
                {p.id === me && <small className="muted"> (أنت)</small>}
              </span>
              <b className={`pt-total ${d > 0 ? 'up' : d < 0 ? 'down' : ''}`}>{fmtDelta(d)}</b>
            </div>
            <ul className="pt-reasons">
              {reasons.map((x, k) => (
                <li key={k} className={x.ok ? 'ok' : x.bad ? 'bad' : ''}>
                  <span>{x.t}</span>
                  <b>{fmtDelta(x.v)}</b>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
      <Reactions />
      <NextBar state={state} label={nextLabel(state)} />
    </section>
  );
}
