import { useEffect, useRef } from 'react';
import { play } from './sound';

const COLORS = ['#FFB627', '#FF5D73', '#2FD8A0', '#FFF4DE', '#8C7CFF', '#FFD86B'];

/** Full-screen fireworks + falling confetti for the winner. Pointer-events free, respects reduced motion. */
export function Fireworks({ duration = 9000, delay = 800 }) {
  const ref = useRef(null);
  useEffect(() => {
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const cv = ref.current;
    const ctx = cv.getContext('2d');
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    let W = 0;
    let H = 0;
    const resize = () => {
      W = window.innerWidth;
      H = window.innerHeight;
      cv.width = W * dpr;
      cv.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const rockets = [];
    const sparks = [];
    const confetti = [];
    const t0 = performance.now() + delay;
    let nextLaunch = t0;
    let raf;
    let lastBoom = 0;

    const launch = () => {
      const x = W * (0.15 + Math.random() * 0.7);
      rockets.push({
        x,
        y: H + 10,
        vx: (Math.random() - 0.5) * 1.2,
        vy: -(H * 0.012 + Math.random() * 3 + 7),
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        targetY: H * (0.15 + Math.random() * 0.3),
      });
    };
    const explode = (r, now) => {
      const n = 60 + Math.floor(Math.random() * 40);
      const ring = Math.random() < 0.35;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        const sp = ring ? 4.2 : 1 + Math.random() * 4.5;
        sparks.push({
          x: r.x,
          y: r.y,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp,
          life: 1,
          decay: 0.011 + Math.random() * 0.012,
          color: Math.random() < 0.8 ? r.color : '#FFF4DE',
        });
      }
      if (now - lastBoom > 180) {
        play('boom');
        lastBoom = now;
      }
    };
    for (let i = 0; i < 140; i++) {
      confetti.push({
        x: Math.random() * W,
        y: -Math.random() * H,
        vy: 1.2 + Math.random() * 2.2,
        sway: Math.random() * Math.PI * 2,
        rot: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 0.2,
        w: 6 + Math.random() * 6,
        h: 3 + Math.random() * 4,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
      });
    }

    const frame = (now) => {
      const elapsed = now - t0;
      ctx.clearRect(0, 0, W, H);
      if (elapsed >= 0) {
        if (elapsed < duration && now >= nextLaunch) {
          const burst = elapsed < 1500 ? 3 : 1 + Math.floor(Math.random() * 2);
          for (let i = 0; i < burst; i++) launch();
          nextLaunch = now + 350 + Math.random() * 500;
        }
        // rockets
        for (let i = rockets.length - 1; i >= 0; i--) {
          const r = rockets[i];
          r.x += r.vx;
          r.y += r.vy;
          r.vy += 0.12;
          ctx.fillStyle = r.color;
          ctx.beginPath();
          ctx.arc(r.x, r.y, 2.4, 0, Math.PI * 2);
          ctx.fill();
          if (r.y <= r.targetY || r.vy >= 0) {
            explode(r, now);
            rockets.splice(i, 1);
          }
        }
        // sparks
        ctx.globalCompositeOperation = 'lighter';
        for (let i = sparks.length - 1; i >= 0; i--) {
          const s = sparks[i];
          s.x += s.vx;
          s.y += s.vy;
          s.vx *= 0.985;
          s.vy = s.vy * 0.985 + 0.05;
          s.life -= s.decay;
          if (s.life <= 0) {
            sparks.splice(i, 1);
            continue;
          }
          ctx.globalAlpha = Math.max(0, s.life);
          ctx.fillStyle = s.color;
          ctx.beginPath();
          ctx.arc(s.x, s.y, 2.2 * s.life + 0.6, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalCompositeOperation = 'source-over';
        // confetti
        const confettiAlpha = elapsed < duration ? 1 : Math.max(0, 1 - (elapsed - duration) / 1500);
        ctx.globalAlpha = confettiAlpha;
        for (const c of confetti) {
          c.y += c.vy;
          c.sway += 0.05;
          c.x += Math.sin(c.sway) * 0.8;
          c.rot += c.vr;
          if (c.y > H + 10 && elapsed < duration) {
            c.y = -10;
            c.x = Math.random() * W;
          }
          ctx.save();
          ctx.translate(c.x, c.y);
          ctx.rotate(c.rot);
          ctx.fillStyle = c.color;
          ctx.fillRect(-c.w / 2, -c.h / 2, c.w, c.h * Math.abs(Math.cos(c.sway)) + 1);
          ctx.restore();
        }
        ctx.globalAlpha = 1;
      }
      const alive = elapsed < duration + 2500 || sparks.length || rockets.length;
      if (alive) raf = requestAnimationFrame(frame);
      else ctx.clearRect(0, 0, W, H);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, [duration, delay]);
  return <canvas ref={ref} className="fireworks" aria-hidden="true" />;
}
