import { useEffect } from 'react';
import { BONUS_INFO } from './ui';

/** Keep the phone screen on while a game is running (where the browser supports it). */
export function useWakeLock(active) {
  useEffect(() => {
    if (!active || !('wakeLock' in navigator)) return;
    let lock = null;
    let stopped = false;
    const grab = async () => {
      try {
        if (document.visibilityState === 'visible' && !stopped) lock = await navigator.wakeLock.request('screen');
      } catch {}
    };
    grab();
    const onVis = () => document.visibilityState === 'visible' && grab();
    document.addEventListener('visibilitychange', onVis);
    return () => {
      stopped = true;
      document.removeEventListener('visibilitychange', onVis);
      try {
        lock && lock.release();
      } catch {}
    };
  }, [active]);
}

function mainRules(s) {
  const out = [
    ['صاحب السؤال', 'إن أصاب: +2 و+1 عن كل لاعب أخطأ. إن أخطأ: +1 عن كل لاعب اختار نفس إجابته الخاطئة.'],
    ['باقي اللاعبين', 'الإجابة الصحيحة +2، والخاطئة 0. عدم الإجابة لا يُحسب خطأ.'],
    ['⭐ الوحيد', 'مع 3 لاعبين أو أكثر: إن أصاب لاعب واحد فقط (غير صاحب السؤال) يأخذ +1 إضافية.'],
  ];
  if (s.wartaEnabled) out.push(['🎯 اقنصه', 'بعد إجابتك اقنص من تتوقع أنه سيُخطئ. إن أخطأ: +1 لك و−1 له. إن أصاب: −1 لك و+1 له.']);
  return out;
}

/** "?" sheet: only the rules that matter for what is on screen right now. */
export function HelpSheet({ state, onClose }) {
  const s = state.settings;
  let title = 'قواعد اللعبة';
  let rules = mainRules(s);
  if (state.phase === 'TURN_SELECTION') {
    title = 'اختيار السؤال';
    rules = [
      ['الفئة ثم المستوى', `صاحب الدور يختار فئة من 3، ثم مستوى: سالكة 🟢 أو مطبّ 🟡 أو ورطة 🔴، خلال ${s.selectionTime} ثانية.`],
      ['التلميح', 'لا يرى صاحب الدور السؤال، بل تلميحاً عن موضوعه فقط. والباقون لا يرون التلميح.'],
      ['اختر بذكاء', 'المستوى لا يغيّر النقاط، لكن الأصعب يُخطئ فيه الآخرون أكثر فتربح منهم، وقد تخطئ أنت أيضاً.'],
      ...mainRules(s),
    ];
  } else if ((state.phase === 'BONUS_ROUND' || state.phase === 'BONUS_RESULTS') && state.bonus) {
    const info = BONUS_INFO[state.bonus.type];
    title = `${info.icon} ${info.name}`;
    rules = [['القاعدة', info.rule]];
    if (state.bonus.type === 'coordinates')
      rules.push(['إن لم يصب أحد', 'عند انتهاء الوقت يأخذ صاحب الدبوس الأقرب +2، والباقون ممن وضعوا دبوساً خارج المنطقة −1.']);
    if (state.bonus.type !== 'auction') rules.push(['عدم الإجابة', 'لا تخسر شيئاً إن لم تُجب.']);
    if (state.bonus.tiebreak) rules.push(['حسم التعادل', 'يشارك فيها المتعادلون على المركز الأول فقط، وتتكرر حتى يتصدّر لاعب واحد.']);
  } else if (state.phase === 'STANDINGS') {
    title = 'الترتيب';
    rules = [['الترتيب', 'ينتقل تلقائياً بعد 10 ثوانٍ، ويستطيع المضيف التخطي أسرع.'], ...mainRules(s)];
  }
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head">
          <h2>{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="إغلاق" autoFocus>
            ✕
          </button>
        </div>
        <dl className="rules">
          {rules.map(([k, v]) => (
            <div key={k}>
              <dt>{k}</dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}
