import { ActionBar } from './actionbar';
import { useEffect, useMemo, useRef, useState } from 'react';
import { geoEquirectangular, geoPath } from 'd3-geo';
import { net } from './net';
import { play } from './sound';
import { Avatar, BONUS_INFO, LETTERS, TimerRing, fmtDelta, usePlayers } from './ui';
import { NextBar, nextLabel } from './standings';
import { Reactions } from './reactions';

// ---------- map ----------

const REGIONS = {
  arab: { lngMin: -18, lngMax: 60, latMin: 0, latMax: 40, k: 10 },
  world: { lngMin: -180, lngMax: 180, latMin: -58, latMax: 84, k: 2.2 },
};

let worldPromise = null;
function loadWorld() {
  if (!worldPromise) worldPromise = fetch('/map/world.json').then((r) => r.json());
  return worldPromise;
}

function useRegion(region) {
  return useMemo(() => {
    const R = REGIONS[region] || REGIONS.arab;
    const W = (R.lngMax - R.lngMin) * R.k;
    const H = (R.latMax - R.latMin) * R.k;
    const proj = geoEquirectangular()
      .scale((R.k * 180) / Math.PI)
      .translate([-R.k * R.lngMin, R.k * R.latMax])
      .clipExtent([
        [0, 0],
        [W, H],
      ]);
    return {
      R,
      W,
      H,
      path: geoPath(proj),
      xy: (lat, lng) => [(lng - R.lngMin) * R.k, (R.latMax - lat) * R.k],
      ll: (x, y) => ({ lat: R.latMax - y / R.k, lng: x / R.k + R.lngMin }),
    };
  }, [region]);
}

// Literal colours: Safari ignores CSS variables inside SVG presentation attributes.
const C = { mint: '#2FD8A0', coral: '#FF5D73', saffron: '#FFB627', night: '#1E1A4D', paper: '#FFF4DE' };

function Pin({ x, y, color, label, big }) {
  const s = big ? 2 : 1.6;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <g className="pin">
        <path d="M0 0 C -9 -14 -9 -24 0 -26 C 9 -24 9 -14 0 0 Z" fill={color} stroke={C.night} strokeWidth="1.5" />
        <circle cx="0" cy="-18" r="4" fill={C.paper} />
        {label && (
          <text y="-31" textAnchor="middle" fontSize="15" fontWeight="700" fill={C.paper} stroke={C.night} strokeWidth="4" paintOrder="stroke" strokeLinejoin="round">
            {label}
          </text>
        )}
      </g>
    </g>
  );
}

export function MapBoard({ region, pins = {}, myPin, onPick, target, players, interactive }) {
  const { W, H, path, xy, ll, R } = useRegion(region);
  const [world, setWorld] = useState(null);
  const [draft, setDraft] = useState(null);
  const svgRef = useRef(null);
  useEffect(() => {
    loadWorld().then(setWorld).catch(() => {});
  }, []);
  useEffect(() => setDraft(null), [region]);

  const click = (e) => {
    if (!interactive || myPin) return;
    const svg = svgRef.current;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;
    const p = pt.matrixTransform(svg.getScreenCTM().inverse());
    if (p.x < 0 || p.y < 0 || p.x > W || p.y > H) return;
    play('tap');
    setDraft(ll(p.x, p.y));
  };

  const pinEls = [];
  for (const [id, pin] of Object.entries(pins)) {
    const [x, y] = xy(pin.lat, pin.lng);
    const p = players[id];
    pinEls.push(<Pin key={id} x={x} y={y} color={pin.inside ? C.mint : C.coral} label={p?.name} />);
  }
  let targetEl = null;
  if (target) {
    const [tx, ty] = xy(target.lat, target.lng);
    const ry = (target.radiusKm / 111) * R.k;
    const rx = ry / Math.max(0.2, Math.cos((target.lat * Math.PI) / 180));
    targetEl = (
      <g className="target">
        <ellipse cx={tx} cy={ty} rx={rx} ry={ry} fill="rgba(47,216,160,.25)" stroke={C.mint} strokeWidth="2" strokeDasharray="6 4" />
        <circle cx={tx} cy={ty} r="4" fill={C.mint} />
      </g>
    );
  }

  return (
    <div className="mapwrap">
      <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className={`map ${interactive && !myPin ? 'can-pin' : ''}`} onClick={click} role="img" aria-label="خريطة">
        <rect width={W} height={H} className="sea" />
        {world && <path d={path(world)} className="land" />}
        {targetEl}
        {pinEls}
        {draft && !myPin && <Pin x={xy(draft.lat, draft.lng)[0]} y={xy(draft.lat, draft.lng)[1]} color={C.saffron} big />}
      </svg>
      {interactive && !myPin && (
        <div className="map-actions">
          <button
            className="btn btn-primary"
            disabled={!draft}
            onClick={() => {
              play('pin');
              onPick(draft);
            }}
          >
            {draft ? 'ثبّت الدبوس هنا' : 'اضغط على الخريطة لتضع دبوسك'}
          </button>
        </div>
      )}
    </div>
  );
}

// ---------- pixelated image ----------

function PixelImage({ src, startedAt, endsAt, clear }) {
  const canvasRef = useRef(null);
  const [img, setImg] = useState(null);
  const lastLevel = useRef(0);
  const focus = useMemo(() => {
    let h = 0;
    for (const ch of src || '') h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    return { x: 0.25 + ((h % 1000) / 1000) * 0.5, y: 0.25 + (((h >>> 10) % 1000) / 1000) * 0.5 };
  }, [src]);
  useEffect(() => {
    if (!src) return;
    const im = new Image();
    im.onload = () => setImg(im);
    im.src = src;
  }, [src]);
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv || !img) return;
    const ctx = cv.getContext('2d');
    const ratio = img.naturalWidth && img.naturalHeight ? img.naturalHeight / img.naturalWidth : 0.75;
    const W = 480;
    const H = Math.round(W * ratio);
    cv.width = W;
    cv.height = H;
    // Rasterise once at a known size: SVGs without width/height report a 0 natural size.
    const base = document.createElement('canvas');
    base.width = W;
    base.height = H;
    base.getContext('2d').drawImage(img, 0, 0, W, H);
    const small = document.createElement('canvas');
    const sctx = small.getContext('2d');
    let raf;
    const draw = () => {
      const total = Math.max(1, endsAt - startedAt);
      const f = clear ? 1 : Math.max(0, Math.min(1, (net.now() - startedAt) / (total * 0.92)));
      const cols = f >= 1 ? W : Math.round(3 + Math.pow(f, 2.2) * 70);
      if (cols !== lastLevel.current || f >= 1) {
        if (lastLevel.current && cols > lastLevel.current + 3 && !clear) play('reveal');
        lastLevel.current = cols;
        const rows = Math.max(2, Math.round(cols * ratio));
        small.width = cols;
        small.height = rows;
        sctx.clearRect(0, 0, cols, rows);
        // Start zoomed in on one spot (same for everyone, derived from the URL) and pull back over time.
        const iw = W;
        const ih = H;
        const z = f >= 1 ? 1 : 0.35 + 0.65 * f;
        const sw = iw * z;
        const sh = ih * z;
        const sx = Math.max(0, Math.min(iw - sw, focus.x * iw - sw / 2));
        const sy = Math.max(0, Math.min(ih - sh, focus.y * ih - sh / 2));
        sctx.drawImage(base, sx, sy, sw, sh, 0, 0, cols, rows);
        ctx.imageSmoothingEnabled = false;
        ctx.clearRect(0, 0, W, H);
        ctx.drawImage(small, 0, 0, cols, rows, 0, 0, W, H);
      }
      if (!clear && f < 1) raf = requestAnimationFrame(draw);
    };
    lastLevel.current = 0;
    draw();
    return () => cancelAnimationFrame(raf);
  }, [img, startedAt, endsAt, clear]);
  return (
    <div className="pixelwrap">
      <canvas ref={canvasRef} className="pixel" aria-label="صورة مشوشة" />
      {!img && <div className="pixel-loading">…</div>}
    </div>
  );
}

// ---------- shared option grid for bonus rounds ----------

function BonusOptions({ bonus, results, canPlay }) {
  const disabled = new Set(bonus.disabled);
  const my = bonus.myAttempt;
  const send = (i) => {
    if (!canPlay || my || disabled.has(i)) return;
    play('tap');
    net.send('submit_bonus_answer', { option: i });
  };
  return (
    <div className="options">
      {bonus.options.map((o, i) => {
        const isAnswer = results && results.answer === i;
        const dead = disabled.has(i);
        const tried = results && Object.values(results.attempts || {}).includes(i);
        if (results && !isAnswer && !tried && !dead) return null;
        return (
          <button
            key={i}
            className={`opt ${dead ? 'is-dead' : ''} ${my?.option === i ? 'picked' : ''} ${isAnswer ? 'is-correct' : ''}`}
            disabled={!canPlay || !!my || dead || !!results}
            onClick={() => send(i)}
          >
            <span className="opt-letter">{LETTERS[i]}</span>
            <span className="opt-text">{o}</span>
            {dead && <span className="opt-flag">استُبعد</span>}
          </button>
        );
      })}
    </div>
  );
}

// ---------- the bonus screen ----------

export function Bonus({ state }) {
  const b = state.bonus;
  const results = state.phase === 'BONUS_RESULTS' ? state.bonusResults : null;
  const pl = usePlayers(state);
  const info = BONUS_INFO[b.type];
  const eligible = b.eligible.includes(state.me);
  const live = b.clockStarted && !results;
  const canPlay = live && eligible && !b.lockedOut.includes(state.me);

  if (!b.clockStarted && !results) {
    return (
      <section className="stage bonus-intro">
        <div className="bonus-badge">{info.icon}</div>
        <p className="kicker">{b.tiebreak ? 'جولة حسم التعادل' : b.type === 'auction' ? 'السؤال الأخير' : 'جولة إضافية'}</p>
        <h2 className="bonus-name">{info.name}</h2>
        <p className="tagline">{info.rule}</p>
        {b.tiebreak && (
          <p className="hint">
            يتنافس فيها: {b.eligible.map((id) => `${pl[id]?.avatar} ${pl[id]?.name}`).join('، ')}
          </p>
        )}
      </section>
    );
  }

  return (
    <section className={`stage bonus bonus-${b.type}`}>
      <div className="stage-head">
        <div>
          <p className="kicker">
            {results && b.type !== 'auction' ? 'تفاصيل الجولة الإضافية: ' : results ? 'تفاصيل ' : ''}
            {info.icon} {info.name}
            {b.tiebreak && ' · حسم التعادل'}
          </p>
          {!eligible && <p className="muted small">أنت تشاهد هذه الجولة</p>}
        </div>
        {results ? null : <TimerRing endsAt={state.endsAt} startedAt={state.startedAt} />}
      </div>

      {b.type === 'coordinates' && (
        <>
          <h2 className="q-text">{b.text}</h2>
          <MapBoard
            region={b.region}
            pins={results ? results.pins : b.pins}
            myPin={b.myPin}
            target={results ? results.target : null}
            players={pl}
            interactive={canPlay}
            onPick={(ll) => net.send('place_pin', ll)}
          />
          {b.myPin && !results && <p className="waiting">تم تثبيت دبوسك. بانتظار البقية…</p>}
        </>
      )}

      {b.type === 'pixel' && (
        <>
          {b.prompt && <h2 className="q-text">{b.prompt}</h2>}
          <PixelImage src={b.image} startedAt={state.startedAt} endsAt={state.endsAt} clear={!!results} />
          <BonusOptions bonus={b} results={results} canPlay={canPlay} />
        </>
      )}

      {b.type === 'link' && (
        <>
          <h2 className="q-text">ما الذي يربط هذه الكلمات؟</h2>
          <div className="link-words">
            {b.words.map((w, i) => (
              <span key={i} className="link-word" style={{ animationDelay: `${i * 150}ms` }}>
                {w}
              </span>
            ))}
          </div>
          <BonusOptions bonus={b} results={results} canPlay={canPlay} />
        </>
      )}

      {b.type === 'censored' && (
        <>
          <p className="censored" aria-label="نص ممسوح جزئياً">
            {b.words.map((w, i) =>
              typeof w === 'string' ? (
                <span key={i} className="cw shown">
                  {w}{' '}
                </span>
              ) : (
                <span key={i} className="cw hidden" style={{ width: `${Math.max(1.4, w.len * 0.55)}em` }} aria-hidden="true" />
              ),
            )}
          </p>
          {b.prompt && <h2 className="q-text small">{b.prompt}</h2>}
          <BonusOptions bonus={b} results={results} canPlay={canPlay} />
        </>
      )}

      {b.type === 'auction' && <AuctionBoard state={state} results={results} canPlay={live && eligible} pl={pl} />}

      {!results && b.myAttempt && (
        <p className={`my-delta ${b.myAttempt.correct ? 'up' : 'down'}`}>
          {b.myAttempt.correct ? 'إجابة صحيحة! نتأكد أنك الأسرع…' : 'إجابة خاطئة −1، خرجت من هذه الجولة.'}
        </p>
      )}

      {results && (b.type === 'auction' ? <AuctionOutcome state={state} results={results} pl={pl} /> : <BonusOutcome state={state} results={results} pl={pl} />)}
    </section>
  );
}

function BonusOutcome({ state, results, pl }) {
  const b = state.bonus;
  const winnerId = results.winnerId || results.closestId;
  const winner = pl[winnerId];
  const done = useRef(false);
  useEffect(() => {
    if (done.current) return;
    done.current = true;
    play(winnerId === state.me ? 'correct' : 'reveal');
  }, []);

  const opts = b.options || [];
  const rows = b.eligible
    .map((id) => {
      const p = pl[id];
      if (!p || p.removed) return null;
      const d = results.deltas[id] || 0;
      const pin = results.pins && results.pins[id];
      const att = results.attempts ? results.attempts[id] : undefined;
      let text;
      let cls = '';
      if (b.type === 'coordinates') {
        if (!pin) text = 'لم يضع دبوساً';
        else if (id === results.winnerId) ((text = 'أول من وضع الدبوس داخل المنطقة الصحيحة'), (cls = 'ok'));
        else if (id === results.closestId) ((text = `الأقرب للهدف (على بعد ${pin.km.toLocaleString('en')} كم)`), (cls = 'ok'));
        else if (pin.inside) text = 'داخل المنطقة لكن بعد الفائز';
        else ((text = `وضع الدبوس خارج المنطقة (على بعد ${pin.km.toLocaleString('en')} كم)`), (cls = 'bad'));
      } else if (att === undefined) text = 'لم يُجب';
      else if (id === results.winnerId) ((text = `أول من أجاب «${opts[att]}» صحيحاً`), (cls = 'ok'));
      else if (att === results.answer) text = `أجاب «${opts[att]}» صحيحاً لكن بعد الفائز`;
      else ((text = `أجاب «${opts[att]}» خطأ`), (cls = 'bad'));
      return { p, d, text, cls };
    })
    .filter(Boolean)
    .sort((a, b2) => b2.d - a.d);

  return (
    <div className="bonus-outcome">
      {winner ? (
        <p className="winner-line">
          <Avatar p={winner} size="lg" />
          <span>
            <b>{winner.name}</b> {results.winnerId ? 'كان الأسرع!' : 'كان الأقرب للهدف!'}
          </span>
          <b className="up">{fmtDelta(2)}</b>
        </p>
      ) : (
        <p className="winner-line muted">لم يُصب أحد هذه المرة.</p>
      )}
      <h3 className="section-title">نقاط هذه الجولة</h3>
      <ul className="points-list">
        {rows.map(({ p, d, text, cls }) => (
          <li key={p.id} className={p.id === state.me ? 'is-me' : ''}>
            <div className="pt-head">
              <span className="pt-name">
                <span className="pt-av" aria-hidden="true">{p.avatar}</span>
                {p.name}
                {p.id === state.me && <small className="muted"> (أنت)</small>}
              </span>
              <b className={`pt-total ${d > 0 ? 'up' : d < 0 ? 'down' : ''}`}>{fmtDelta(d)}</b>
            </div>
            <ul className="pt-reasons">
              <li className={cls}>
                <span>{text}</span>
              </li>
            </ul>
          </li>
        ))}
      </ul>
      <Reactions />
      <NextBar state={state} label={nextLabel(state)} />
    </div>
  );
}

// ---------- مزاد التعويض ----------

function AuctionBoard({ state, results, canPlay, pl }) {
  const b = state.bonus;
  const [sel, setSel] = useState(() => new Set(b.mySelection || []));
  const locked = b.myLocked;
  const correct = results && results.auction ? new Set(results.auction.correct) : null;
  const pickers = {};
  if (results && results.auction) {
    for (const [id, arr] of Object.entries(results.auction.selections)) for (const i of arr) (pickers[i] = pickers[i] || []).push(id);
  }
  const toggle = (i) => {
    if (!canPlay || locked) return;
    const next = new Set(sel);
    if (next.has(i)) next.delete(i);
    else next.add(i);
    setSel(next);
    play('tap');
    net.send('auction_select', { options: [...next] });
  };
  const mine = results ? new Set(results.auction?.selections[state.me] || []) : sel;
  return (
    <>
      <h2 className="q-text">{b.prompt}</h2>
      {!results && <p className="hint">اختر كل ما تراه صحيحاً، ويمكنك التراجع قبل التثبيت. كل صحيحة +1 وكل خاطئة −1.</p>}
      <div className="auction-grid">
        {b.options.map((o, i) => {
          const isRight = correct && correct.has(i);
          return (
            <button
              key={i}
              type="button"
              className={`auc ${mine.has(i) ? 'picked' : ''} ${correct ? (isRight ? 'is-correct' : 'is-wrong') : ''}`}
              aria-pressed={mine.has(i)}
              disabled={!!results || !canPlay || locked}
              onClick={() => toggle(i)}
            >
              <span className="auc-box" aria-hidden="true">{mine.has(i) ? '✓' : ''}</span>
              <span className="auc-text">
                {o}
                {correct && <small className="auc-verdict">{isRight ? 'صحيحة' : 'خاطئة'}</small>}
                {correct && (
                  <span className="as-names">
                    {(pickers[i] || []).map((id) => (
                      <span key={id} className="name-chip">
                        {pl[id]?.name}
                      </span>
                    ))}
                  </span>
                )}
              </span>
            </button>
          );
        })}
      </div>
      {!results && canPlay && (
        <ActionBar>
          {locked ? (
            <p className="waiting">ثبّتَّ {sel.size} اختيارات. بانتظار البقية…</p>
          ) : (
            <button
              className="btn btn-primary btn-big"
              onClick={() => {
                play('pin');
                net.send('auction_lock');
              }}
            >
              {sel.size ? `ثبّت اختياراتي (${sel.size})` : 'لا أعرف شيئاً، ثبّت بدون اختيار'}
            </button>
          )}
        </ActionBar>
      )}
    </>
  );
}

function AuctionOutcome({ state, results, pl }) {
  const b = state.bonus;
  const a = results.auction || { detail: {}, selections: {} };
  const done = useRef(false);
  useEffect(() => {
    if (done.current) return;
    done.current = true;
    const d = results.deltas[state.me] || 0;
    play(d > 0 ? 'correct' : d < 0 ? 'wrong' : 'reveal');
  }, []);
  const rows = b.eligible
    .map((id) => {
      const p = pl[id];
      if (!p || p.removed) return null;
      const det = a.detail[id] || { hits: 0, misses: 0 };
      return { p, d: results.deltas[id] || 0, det };
    })
    .filter(Boolean)
    .sort((x, y) => y.d - x.d);
  const best = rows.length && rows[0].d > 0 ? rows.filter((r) => r.d === rows[0].d) : [];
  return (
    <div className="bonus-outcome">
      {best.length ? (
        <p className="winner-line">
          <span>
            أفضل نتيجة: <b>{best.map((r) => r.p.name).join(' و')}</b>
          </span>
          <b className="up">{fmtDelta(best[0].d)}</b>
        </p>
      ) : (
        <p className="winner-line muted">لم يربح أحد نقاطاً في هذا المزاد.</p>
      )}
      <h3 className="section-title">نقاط هذه الجولة</h3>
      <ul className="points-list">
        {rows.map(({ p, d, det }) => (
          <li key={p.id} className={p.id === state.me ? 'is-me' : ''}>
            <div className="pt-head">
              <span className="pt-name">
                <span className="pt-av" aria-hidden="true">{p.avatar}</span>
                {p.name}
                {p.id === state.me && <small className="muted"> (أنت)</small>}
              </span>
              <b className={`pt-total ${d > 0 ? 'up' : d < 0 ? 'down' : ''}`}>{fmtDelta(d)}</b>
            </div>
            <ul className="pt-reasons">
              {det.hits + det.misses === 0 ? (
                <li>
                  <span>لم يختر شيئاً</span>
                  <b>0</b>
                </li>
              ) : (
                <>
                  <li className={det.hits ? 'ok' : ''}>
                    <span>اختار {det.hits} صحيحة</span>
                    <b>{fmtDelta(det.hits)}</b>
                  </li>
                  {det.misses > 0 && (
                    <li className="bad">
                      <span>اختار {det.misses} خاطئة</span>
                      <b>{fmtDelta(-det.misses)}</b>
                    </li>
                  )}
                </>
              )}
            </ul>
          </li>
        ))}
      </ul>
      <Reactions />
      <NextBar state={state} label={nextLabel(state)} />
    </div>
  );
}
