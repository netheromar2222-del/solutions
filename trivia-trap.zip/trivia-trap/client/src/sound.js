// Thin facade over the audio engine so components can just call play('correct').
import { AudioEngine } from './audio/engine';

export const audio = new AudioEngine();
if (typeof window !== 'undefined') window.__ttAudio = audio; // handy for debugging in the console

export function play(name) {
  audio.play(name);
}
export function unlockAudio() {
  audio.unlock();
}
export function setScene(name) {
  audio.setScene(name);
}
export function setIntensity(level) {
  audio.setIntensity(level);
}
// Kept for older call sites: "muted" means sound effects off.
export function isMuted() {
  return !audio.sfxOn;
}
export function setMuted(v) {
  audio.setSfx(!v);
}

// Any first touch/click/key unlocks audio (browsers block sound before a gesture).
if (typeof window !== 'undefined') {
  const unlock = () => audio.unlock();
  for (const ev of ['pointerdown', 'touchend', 'keydown']) window.addEventListener(ev, unlock, { passive: true });
}
