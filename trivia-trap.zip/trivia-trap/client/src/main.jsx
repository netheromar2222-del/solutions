import { ActionBarContext } from './actionbar';
import { ReactionLayer } from './reactions';
import { HelpSheet, useWakeLock } from './help';
import { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { net, session } from './net';
import { audio, play, setIntensity, setScene } from './sound';
import { ScoreStrip } from './ui';
import { Home, Lobby, ProfilePicker } from './lobby';
import { Question, Results, Selection } from './play';
import { Bonus } from './bonus';
import { GameOver } from './final';
import { StandingsPage } from './standings';

function codeFromPath() {
  const m = location.pathname.match(/^\/([A-Za-z0-9]{5})\/?$/);
  return m ? m[1].toUpperCase() : '';
}

function App() {
  const [state, setState] = useState(null);
  const [status, setStatus] = useState(net.status);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [booting, setBooting] = useState(!!session.get());
  const [barEl, setBarEl] = useState(null);
  const [help, setHelp] = useState(false);
  useWakeLock(!!state && state.phase !== 'LOBBY');

  useEffect(() => {
    let toastTimer;
    const showToast = (t) => {
      setToast(t);
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => setToast(''), 2600);
    };
    const off = net.on((e, d) => {
      switch (e) {
        case 'status':
          setStatus(d);
          break;
        case 'ready':
          setBooting(false);
          break;
        case 'state':
          setBooting(false);
          setError('');
          setState(d);
          if (location.pathname !== `/${d.code}`) history.replaceState(null, '', `/${d.code}`);
          break;
        case 'error':
          setError(d.message);
          if (window.__ttMe) showToast(d.message);
          break;
        case 'rejoin_failed':
          setBooting(false);
          setState(null);
          setError(d.message);
          break;
        case 'left':
          setState(null);
          history.replaceState(null, '', '/');
          if (d.reason === 'kicked') setError('أخرجك المضيف من الغرفة.');
          if (d.reason === 'timeout') setError('انتهت مهلة العودة للغرفة.');
          if (d.reason === 'started') setError('بدأت اللعبة قبل أن تختار اسمك وشخصيتك. انتظر الجولة القادمة أو أنشئ غرفة.');
          if (d.reason === 'idle') setError('خرجت من الغرفة لأنك لم تختر اسمك وشخصيتك.');
          break;
        case 'fx':
          handleFx(d, showToast);
          break;
        default:
          break;
      }
    });
    net.connect();
    return () => {
      off();
      clearTimeout(toastTimer);
    };
  }, []);

  // fx needs the latest "me", so keep it in a ref-like closure via window
  useEffect(() => {
    window.__ttMe = state?.me;
    window.__ttPlayers = state?.players;
    window.__ttPhase = state ? `${state.phase}|${state.bonus?.type || ''}|${state.bonus?.clockStarted ? 1 : 0}` : 'HOME';
  }, [state]);


  // Music follows the game phase; urgency rises as the clock runs down.
  useEffect(() => {
    const ph = state?.phase;
    const scene = !state
      ? 'lobby'
      : {
          LOBBY: 'lobby',
          TURN_SELECTION: 'select',
          QUESTION_ACTIVE: 'question',
          ROUND_SCORING: 'results',
          BONUS_ROUND: 'bonus',
          BONUS_RESULTS: 'results',
          STANDINGS: 'results',
          GAME_OVER: undefined, // GameOver drives its own drumroll → victory
        }[ph];
    if (scene !== undefined) setScene(scene);
  }, [state?.phase]);
  useEffect(() => {
    if (!state || !state.endsAt || !['QUESTION_ACTIVE', 'BONUS_ROUND'].includes(state.phase)) {
      setIntensity(0);
      return;
    }
    const total = state.endsAt - state.startedAt;
    const id = setInterval(() => {
      const frac = (state.endsAt - net.now()) / total;
      setIntensity(frac < 0.25 ? 2 : frac < 0.55 ? 1 : 0);
    }, 250);
    return () => clearInterval(id);
  }, [state?.phase, state?.endsAt]);

  const banner =
    status !== 'open' ? <div className="conn-banner" role="status">جارٍ الاتصال بالخادم…</div> : null;

  if (!state) {
    return (
      <>
        {banner}
        <div className="home-audio"><AudioToggles /></div>
        {booting ? <div className="boot">جارٍ استعادة جلستك…</div> : <Home error={error} initialCode={codeFromPath()} />}
      </>
    );
  }

  const inGame = state.phase !== 'LOBBY' && state.phase !== 'GAME_OVER';
  const activeId = state.turn?.activeId || state.question?.activeId || state.results?.activeId;
  const meP = state.players.find((p) => p.id === state.me);
  let screen = null;
  switch (meP && !meP.ready ? 'PROFILE' : state.phase) {
    case 'PROFILE':
      // New arrivals (also mid-game spectators) pick a unique name + character first.
      screen = <ProfilePicker state={state} />;
      break;
    case 'LOBBY':
      screen = <Lobby state={state} />;
      break;
    case 'TURN_SELECTION':
      screen = <Selection key={`s${state.round}`} state={state} />;
      break;
    case 'QUESTION_ACTIVE':
      screen = <Question key={`q${state.round}`} state={state} />;
      break;
    case 'ROUND_SCORING':
      screen = <Results key={`r${state.round}`} state={state} />;
      break;
    case 'BONUS_ROUND':
    case 'BONUS_RESULTS':
      screen = <Bonus key={`b${state.round}-${state.bonus?.type}`} state={state} />;
      break;
    case 'STANDINGS':
      screen = <StandingsPage key={`st${state.round}-${state.standings?.from}`} state={state} />;
      break;
    case 'GAME_OVER':
      screen = <GameOver state={state} />;
      break;
    default:
      screen = null;
  }

  return (
    <div className="app">
      {banner}
      <header className="topbar">
        <img className="brand" src="/brand/wordmark-for-dark-bg.svg" alt="ورطة" />
        {inGame && (
          <span className="round-pill">
            {state.inTiebreak ? 'حسم التعادل' : state.bonus?.type === 'auction' || state.standings?.from === 'auction' ? 'السؤال الأخير' : `الجولة ${state.round}/${state.settings.rounds}`}
          </span>
        )}
        <span className="topbar-actions">
          {state.phase !== 'LOBBY' && (
            <button className="icon-btn" onClick={() => setHelp(true)} aria-label="قواعد هذه الجولة">
              ؟
            </button>
          )}
          <AudioToggles />
          {inGame && (
            <button
              className="icon-btn text-btn"
              onClick={() => {
                if (confirm(meP?.spectator ? 'هل تريد الخروج من الغرفة؟' : 'هل تريد مغادرة اللعبة؟ ستُجمَّد نقاطك.')) net.send('leave');
              }}
            >
              خروج
            </button>
          )}
        </span>
      </header>
      {inGame && !['ROUND_SCORING', 'BONUS_RESULTS', 'STANDINGS'].includes(state.phase) && <ScoreStrip state={state} activeId={activeId} />}
      {meP?.spectator && meP.ready && state.phase !== 'LOBBY' && (
        <div className="spectator-banner" role="status">
          👀 أنت تشاهد هذه اللعبة، وستدخل اللعبة القادمة تلقائياً.
        </div>
      )}
      <ActionBarContext.Provider value={barEl}>
        <div className="scroll">
          <div className="screen">{screen}</div>
        </div>
      </ActionBarContext.Provider>
      <footer className="action-bar" ref={setBarEl} />
      <ReactionLayer />
      {help && <HelpSheet state={state} onClose={() => setHelp(false)} />}
      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}

function AudioToggles() {
  const [, force] = useState(0);
  useEffect(() => audio.onChange(() => force((n) => n + 1)), []);
  return (
    <>
      <button
        className={`icon-btn ${audio.musicOn ? '' : 'is-off'}`}
        onClick={() => {
          audio.unlock();
          audio.setMusic(!audio.musicOn);
        }}
        aria-label={audio.musicOn ? 'إيقاف الموسيقى' : 'تشغيل الموسيقى'}
        aria-pressed={audio.musicOn}
      >
        🎵
      </button>
      <button
        className={`icon-btn ${audio.sfxOn ? '' : 'is-off'}`}
        onClick={() => {
          audio.unlock();
          audio.setSfx(!audio.sfxOn);
          if (!audio.sfxOn) return;
          play('tap');
        }}
        aria-label={audio.sfxOn ? 'كتم المؤثرات' : 'تشغيل المؤثرات'}
        aria-pressed={audio.sfxOn}
      >
        {audio.sfxOn ? '🔊' : '🔇'}
      </button>
    </>
  );
}

function handleFx(d, showToast) {
  const me = window.__ttMe;
  const players = window.__ttPlayers || [];
  const name = (id) => players.find((p) => p.id === id)?.name || '';
  switch (d.type) {
    case 'turn_started':
      if (d.activeId === me) play('yourTurn');
      else play('tap');
      break;
    case 'game_start':
      play('gameStart');
      break;
    case 'question':
      play('question');
      break;
    case 'bonus_start':
      play('bonus');
      break;
    case 'bonus_option_eliminated':
      play('eliminated');
      if (d.playerId !== me) showToast(`${name(d.playerId)} أخطأ واستُبعد خياره`);
      break;
    case 'pin_dropped':
      if (d.playerId !== me) play('pinOther');
      break;
    case 'tiebreak':
      showToast('تعادل في الصدارة! جولة حسم');
      break;
    case 'host_changed':
      if (d.hostId === me) showToast('أصبحت أنت مضيف الغرفة');
      else showToast(`${name(d.hostId)} أصبح مضيف الغرفة`);
      break;
    default:
      break;
  }
}

createRoot(document.getElementById('root')).render(<App />);
