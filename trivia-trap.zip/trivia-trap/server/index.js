// HTTP + WebSocket entry point. Serves the built web client from /public and the game socket at /ws.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');
const { Bank } = require('./game/bank');
const { Room, PHASE } = require('./game/Room');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, '..', 'public');
const bank = new Bank();
const rooms = new Map(); // code -> Room

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};

function newCode() {
  const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (;;) {
    let c = '';
    for (let i = 0; i < 5; i++) c += letters[Math.floor(Math.random() * letters.length)];
    if (!rooms.has(c)) return c;
  }
}

function serveFile(res, file, cache, req) {
  fs.stat(file, (e, st) => {
    const etag = !e && st ? `"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"` : null;
    if (etag && req && req.headers['if-none-match'] === etag) {
      res.writeHead(304, { ETag: etag, 'Cache-Control': cache ? 'public, max-age=3600' : 'no-cache' });
      res.end();
      return;
    }
    sendFile(res, file, cache, etag);
  });
}

function sendFile(res, file, cache, etag) {
  fs.readFile(file, (err, buf) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': cache ? 'public, max-age=3600' : 'no-cache',
      ...(etag ? { ETag: etag } : {}),
    });
    res.end(buf);
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = decodeURIComponent(url.pathname);

  if (p === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, rooms: rooms.size }));
    return;
  }

  // Pixelated-clue image: an opaque per-round token so the file name can't give the answer away.
  const m = p.match(/^\/bonus-img\/([A-Z0-9]{5})\/([a-f0-9]{32})$/);
  if (m) {
    const room = rooms.get(m[1]);
    const b = room && room.bonus;
    if (room && b && b.type === 'pixel' && b.clockStarted && room.imageToken === m[2]) {
      const file = bank.imagePath(b.q.image);
      if (file) return serveFile(res, file, false);
    }
    res.writeHead(404);
    res.end();
    return;
  }

  let file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC)) {
    res.writeHead(403);
    res.end();
    return;
  }
  fs.stat(file, (err, st) => {
    if (!err && st.isFile()) return serveFile(res, file, p.startsWith('/map/'), req);
    // SPA fallback (e.g. /ABCDE room links)
    serveFile(res, path.join(PUBLIC, 'index.html'), false, req);
  });
});

const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 16 * 1024 });

wss.on('connection', (ws) => {
  let room = null;
  let player = null;
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));

  const reply = (e, d) => ws.readyState === 1 && ws.send(JSON.stringify({ e, d }));

  function bind(r, p) {
    room = r;
    player = p;
    reply('joined', { code: r.code, token: p.token, playerId: p.id });
    r.attach(p, ws);
  }

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    const { e, d = {} } = msg || {};
    if (e === 'ping') return reply('pong', { t: d.t, serverNow: Date.now() });

    // After leaving / being removed, this connection is free to create or join another room.
    if (player && (player.removed || !room.players.has(player.id) || player.socket !== ws)) {
      room = null;
      player = null;
    }

    if (!player) {
      if (e === 'create_room') {
        const code = newCode();
        const r = new Room({
          code,
          bank,
          onEmpty: (rm) => rooms.delete(rm.code),
          log: (s) => console.log(`[${code}] ${s}`),
        });
        rooms.set(code, r);
        const { player: p } = r.addPlayer();
        bind(r, p);
        if (d.settings) r.handle(p, 'update_settings', d.settings);
        console.log(`[${code}] created`);
        return;
      }
      if (e === 'join_room') {
        const r = rooms.get(String(d.code || '').toUpperCase().trim());
        if (!r) return reply('error', { message: 'لا توجد غرفة بهذا الرمز.', code: 'NO_ROOM' });
        const res = r.addPlayer();
        if (res.error) return reply('error', { message: res.error });
        bind(r, res.player);
        return;
      }
      if (e === 'rejoin') {
        const r = rooms.get(String(d.code || '').toUpperCase());
        const p = r && r.findByToken(d.token);
        if (!r || !p || p.removed) return reply('rejoin_failed', { message: 'انتهت جلستك في هذه الغرفة.' });
        bind(r, p);
        return;
      }
      if (e === 'peek_room') {
        const r = rooms.get(String(d.code || '').toUpperCase().trim());
        return reply('room_info', r ? { exists: true, phase: r.phase, players: r.activePlayers().length, max: r.settings.maxPlayers } : { exists: false });
      }
      return;
    }
    room.handle(player, e, d);
  });

  ws.on('close', () => {
    if (room && player) room.detach(player, ws);
  });
});

// Drop dead sockets so reconnect grace starts promptly.
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) {
      ws.terminate();
      continue;
    }
    ws.isAlive = false;
    try {
      ws.ping();
    } catch {}
  }
}, 15_000);

// Clean up rooms nobody has touched for 2 hours.
setInterval(() => {
  const now = Date.now();
  for (const [code, r] of rooms) {
    if (now - r.lastActivity > 2 * 60 * 60 * 1000 || (r.phase === PHASE.LOBBY && r.activePlayers().length === 0)) {
      r.clearTimers();
      rooms.delete(code);
    }
  }
}, 10 * 60 * 1000);

server.listen(PORT, () => console.log(`Trivia Trap running on http://localhost:${PORT}`));

module.exports = { server, rooms };
