// End-of-game badges from gameplay stats. Ties share a badge; a badge needs a non-zero value.
const BADGES = [
  { key: 'sucker_hunter', icon: '🕵️‍♂️', title: 'صائد المغفلين', desc: 'أكثر من أوقع خصومه في إجابته الخاطئة', stat: (s) => s.trapsSprung },
  { key: 'warta_master', icon: '🎯', title: 'القنّاص', desc: 'أكثر من قنص لاعباً فأصابه', stat: (s) => s.wartaWins },
  { key: 'failed_gambler', icon: '💨', title: 'الطلقة الطائشة', desc: 'أكثر من قنص لاعباً فأفلت منه', stat: (s) => s.wartaLosses },
  { key: 'survivor', icon: '🛡️', title: 'الناجي', desc: 'أكثر من أفلت من قنص الآخرين', stat: (s) => s.wartaEscapes },
  { key: 'lone_genius', icon: '⭐', title: 'العارف الوحيد', desc: 'أكثر من كان الوحيد الذي أصاب', stat: (s) => s.loneCorrect },
  { key: 'speed_ninja', icon: '⚡', title: 'النينجا السريع', desc: 'أكثر من فاز بالجولات الإضافية', stat: (s) => s.bonusWins },
  { key: 'golden_victim', icon: '🤡', title: 'الضحية الذهبية', desc: 'أكثر من وقع في إجابات الآخرين الخاطئة', stat: (s) => s.fellInTraps },
  {
    key: 'encyclopedia',
    icon: '🧠',
    title: 'موسوعة اللعبة',
    desc: 'أعلى نسبة إجابات صحيحة في الجولات الرئيسية',
    stat: (s) => (s.answered >= 2 ? Math.round((s.correct / s.answered) * 100) : 0),
    unit: '%',
  },
];

function computeBadges(players) {
  const out = [];
  for (const b of BADGES) {
    let best = 0;
    for (const p of players) best = Math.max(best, b.stat(p.stats));
    if (best <= 0) continue;
    const winners = players.filter((p) => b.stat(p.stats) === best).map((p) => p.id);
    out.push({ key: b.key, icon: b.icon, title: b.title, desc: b.desc, value: best, unit: b.unit || '', playerIds: winners });
  }
  return out;
}

module.exports = { computeBadges, BADGES };
