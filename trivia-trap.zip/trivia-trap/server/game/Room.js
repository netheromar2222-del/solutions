// One game room: a server-authoritative finite state machine.
const crypto = require('crypto');
const { scoreMainRound, haversineKm, scoreCoordinates, scoreAuction, wartaLists } = require('./scoring');
const { BONUS_TYPES, shuffle, seenKey } = require('./bank');
const { computeBadges } = require('./badges');

const PHASE = {
  LOBBY: 'LOBBY',
  TURN_SELECTION: 'TURN_SELECTION',
  QUESTION_ACTIVE: 'QUESTION_ACTIVE',
  ROUND_SCORING: 'ROUND_SCORING',
  BONUS_ROUND: 'BONUS_ROUND',
  BONUS_RESULTS: 'BONUS_RESULTS',
  STANDINGS: 'STANDINGS',
  GAME_OVER: 'GAME_OVER',
};

// Timings (ms). Selection time is fixed by design; question/bonus time comes from the host.
const T = {
  BONUS_INTRO: 4_000, // short "get ready" before a bonus round's clock starts
  RECONNECT_GRACE: 60_000, // in the lobby
  RECONNECT_GRACE_GAME: 180_000, // during a game: phone calls, locked screens, tea runs
  STANDINGS_AUTO: 10_000, // standings page moves on by itself (host can skip)
  PENDING: 180_000, // a seat held while choosing name/character
  SETTLE: 150, // window to let near-simultaneous correct answers race fairly
  MAX_LATENCY_COMP: 150,
};
const MAX_TIEBREAKS = 10;
// Test hook only: TT_TIME_SCALE=0.05 runs every clock 20x faster.
const SCALE = Number(process.env.TT_TIME_SCALE) > 0 ? Number(process.env.TT_TIME_SCALE) : 1;

const AVATARS = ['🦊', '🐫', '🦅', '🐢', '🦁', '🐙', '🦉', '🐬', '🦜', '🐝', '🦔', '🐼', '🦩', '🐸', '🐯', '🐧', '🦓', '🐳', '🦚', '🐞'];

function token() {
  return crypto.randomBytes(16).toString('hex');
}

function clampInt(v, min, max, dflt) {
  const n = parseInt(v, 10);
  if (Number.isNaN(n)) return dflt;
  return Math.max(min, Math.min(max, n));
}

class Room {
  constructor({ code, bank, onEmpty, log = () => {} }) {
    this.code = code;
    this.bank = bank;
    this.onEmpty = onEmpty;
    this.log = log;
    this.players = new Map(); // id -> player
    this.hostId = null;
    this.phase = PHASE.LOBBY;
    this.settings = {
      categories: bank.categoryList().filter((c) => c.count > 0).map((c) => c.key),
      rounds: 2,
      roundsAuto: true, // rounds = 2 turns per player, until the host sets a number
      maxPlayers: 8,
      questionTime: 30,
      selectionTime: 20,
      wartaEnabled: true,
      bonusTypes: BONUS_TYPES.slice(),
      auctionEnabled: true,
      optionCount: 4,
    };
    this.timer = null;
    this.ticker = null;
    this.settleTimer = null;
    this.endsAt = null;
    this.startedAt = null;
    this.usedQuestions = new Set();
    this.usedBonus = new Set();
    this.resetGame();
    this.lastActivity = Date.now();
  }

  resetGame() {
    this.round = 0;
    this.turnOrder = [];
    this.turnIndex = -1;
    this.bonusCounter = 0;
    this.tiebreaks = 0;
    this.inTiebreak = false;
    this.auctionDone = false;
    this.turn = null;
    this.current = null;
    this.results = null;
    this.bonus = null;
    this.bonusResults = null;
    this.final = null;
    this.standings = null;
    this.history = []; // per-question summary for the end-of-game highlights
    this.imageToken = null;
    for (const p of this.players.values()) {
      p.score = 0;
      p.stats = Room.emptyStats();
      p.timesTargeted = 0;
    }
  }

  static emptyStats() {
    return {
      trapsSprung: 0, // opponents who fell into this player's wrong answer
      fellInTraps: 0,
      wartaWins: 0, // ورّطه: my target fell
      wartaLosses: 0, // ورّطه: my target escaped
      wartaEscapes: 0, // I escaped someone's ورطة
      loneCorrect: 0, // الوحيد: only one who got it right
      bonusWins: 0,
      answered: 0,
      correct: 0,
    };
  }

  // ---------- players & connections ----------

  /** Players taking part in the game (spectators who joined mid-game are not included). */
  activePlayers() {
    return [...this.players.values()].filter((p) => !p.removed && !p.spectator);
  }

  /** Everyone in the room, spectators included. */
  members() {
    return [...this.players.values()].filter((p) => !p.removed);
  }

  /** Reserve a seat. The player picks a name and character next (setProfile), inside the room. */
  addPlayer() {
    if (this.members().length >= this.settings.maxPlayers) return { error: 'الغرفة ممتلئة.' };
    // Arriving mid-game: watch as a spectator and join automatically when the next game starts.
    const spectator = this.phase !== PHASE.LOBBY;
    const p = {
      id: token().slice(0, 10),
      token: token(),
      name: '',
      avatar: null,
      ready: false, // true once a unique name + character are confirmed
      spectator,
      score: 0,
      stats: Room.emptyStats(),
      timesTargeted: 0,
      connected: false,
      removed: false,
      joinedAt: Date.now() + Math.random(), // tiny jitter keeps order strict
      socket: null,
      rtt: 0,
      graceTimer: null,
    };
    this.players.set(p.id, p);
    if (!this.hostId) this.hostId = p.id;
    // Don't let an abandoned "choosing…" seat block the room forever.
    p.pendingTimer = setTimeout(() => {
      if (!p.ready && !p.removed && this.players.has(p.id)) this.removePlayer(p, 'idle');
    }, T.PENDING * SCALE);
    return { player: p };
  }

  /** Auto rounds: two turns for every ready player, so everyone asks the same number of questions. */
  syncAutoRounds() {
    if (!this.settings.roundsAuto || this.phase !== PHASE.LOBBY) return;
    const n = this.activePlayers().filter((x) => x.ready).length;
    this.settings.rounds = 2 * Math.max(1, n);
  }

  /** Arabic-aware name key: ignores spaces, tashkeel, tatweel, أ/إ/آ vs ا, ة vs ه, ى vs ي, and case. */
  static nameKey(name) {
    return String(name || '')
      .normalize('NFKC')
      .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/\s+/g, '')
      .toLowerCase();
  }

  setProfile(p, name, avatar) {
    if (this.phase !== PHASE.LOBBY && !p.spectator) return;
    const clean = String(name || '').replace(/\s+/g, ' ').trim().slice(0, 18);
    const others = this.members().filter((x) => x.id !== p.id && x.ready);
    const fail = (field, message) => this.send(p, 'profile_error', { field, message });
    if (!clean) return fail('name', 'اكتب اسمك أولاً.');
    if (others.some((x) => Room.nameKey(x.name) === Room.nameKey(clean))) return fail('name', 'هذا الاسم مستخدم في الغرفة، اختر اسماً آخر.');
    const taken = new Set(others.map((x) => x.avatar));
    let av = avatar;
    if (av === undefined || av === null) av = AVATARS.find((a) => !taken.has(a)); // auto-pick if none chosen
    if (!AVATARS.includes(av)) return fail('avatar', 'اختر شخصية من القائمة.');
    if (taken.has(av)) return fail('avatar', 'سبقك أحد لهذه الشخصية، اختر غيرها.');
    p.name = clean;
    p.avatar = av;
    p.ready = true;
    clearTimeout(p.pendingTimer);
    this.syncAutoRounds();
    this.broadcast();
  }

  findByToken(tok) {
    for (const p of this.players.values()) if (p.token === tok) return p;
    return null;
  }

  attach(p, socket) {
    if (p.socket && p.socket !== socket) {
      try {
        p.socket.close(4000, 'replaced');
      } catch {}
    }
    p.socket = socket;
    p.connected = true;
    if (p.graceTimer) clearTimeout(p.graceTimer);
    p.graceTimer = null;
    this.lastActivity = Date.now();
    this.broadcast();
  }

  detach(p, socket) {
    if (p.socket !== socket) return; // an older socket closing after a reconnect
    p.socket = null;
    p.connected = false;
    const grace = this.phase === PHASE.LOBBY || this.phase === PHASE.GAME_OVER ? T.RECONNECT_GRACE : T.RECONNECT_GRACE_GAME;
    p.graceTimer = setTimeout(() => this.removePlayer(p, 'timeout'), grace * SCALE);
    this.broadcast();
    this.checkEarlyEnd();
    if (!this.members().some((x) => x.connected)) this.onEmptyMaybe();
  }

  onEmptyMaybe() {
    // Keep the room alive through the grace period so people can come back.
    setTimeout(() => {
      if (!this.members().some((x) => x.connected)) {
        this.clearTimers();
        this.onEmpty(this);
      }
    }, T.RECONNECT_GRACE_GAME * SCALE + 1000);
  }

  removePlayer(p, reason) {
    if (p.removed) return;
    if (p.graceTimer) clearTimeout(p.graceTimer);
    p.graceTimer = null;
    clearTimeout(p.pendingTimer);
    if (this.phase === PHASE.LOBBY || p.spectator) {
      this.players.delete(p.id);
      this.syncAutoRounds();
    } else {
      p.removed = true; // score frozen, out of turn order
    }
    if (p.socket) {
      try {
        p.socket.send(JSON.stringify({ e: 'left', d: { reason } }));
      } catch {}
    }
    p.socket = null;
    p.connected = false;
    this.log(`player ${p.name} removed (${reason})`);

    if (this.hostId === p.id) this.transferHost();

    const remaining = this.activePlayers();
    if (this.members().length === 0) {
      this.clearTimers();
      this.onEmpty(this);
      return;
    }
    if (this.phase !== PHASE.LOBBY && this.phase !== PHASE.GAME_OVER && remaining.length < 2) {
      this.finishGame(true);
      return;
    }
    this.broadcast();
    this.checkEarlyEnd();
  }

  transferHost() {
    const cands = this.members().sort((a, b) => {
      if (!!a.spectator !== !!b.spectator) return a.spectator ? 1 : -1;
      if (a.ready !== b.ready) return a.ready ? -1 : 1;
      if (a.connected !== b.connected) return a.connected ? -1 : 1;
      return a.joinedAt - b.joinedAt;
    });
    this.hostId = cands[0] ? cands[0].id : null;
    if (this.hostId) this.fx('host_changed', { hostId: this.hostId });
  }

  /** Scores of everyone still in the game, used to animate standings. */
  scoreSnapshot() {
    const out = {};
    for (const p of this.players.values()) if (!p.removed) out[p.id] = p.score;
    return out;
  }

  /** Who may advance result screens: the host, or the oldest connected player while the host is offline. */
  controllerId() {
    const host = this.players.get(this.hostId);
    if (host && host.connected && !host.removed) return host.id;
    const cand = this.activePlayers()
      .filter((x) => x.connected)
      .sort((a, b) => a.joinedAt - b.joinedAt)[0];
    return cand ? cand.id : this.hostId;
  }

  canControl(p) {
    return p.id === this.controllerId();
  }

  // ---------- messaging ----------

  send(p, e, d) {
    if (p.socket && p.socket.readyState === 1) p.socket.send(JSON.stringify({ e, d }));
  }

  broadcast() {
    for (const p of this.players.values()) if (p.connected) this.send(p, 'state', this.view(p));
  }

  // ---------- "already seen" memory (kept on each device, sent on join) ----------

  /** A device sends the keys of questions it has seen, oldest first, in chunks (first chunk resets). */
  receiveSeen(p, d) {
    if (!Array.isArray(d.keys)) return;
    if (d.first || !p.seen) {
      p.seen = new Map();
      p.seenN = 0;
    }
    for (const k of d.keys.slice(0, 3000)) {
      if (typeof k !== 'string' || k.length > 12) continue;
      p.seen.delete(k);
      p.seen.set(k, ++p.seenN);
      if (p.seen.size > 20000) p.seen.delete(p.seen.keys().next().value);
    }
  }

  /**
   * How much the players in the game have already seen a question: 0 when nobody has, otherwise
   * each player who has seen it adds between 1 (long ago) and 2 (just now).
   */
  seenScore = (id) => {
    const k = seenKey(id);
    let s = 0;
    for (const p of this.activePlayers()) {
      const at = p.seen && p.seen.get(k);
      if (at) s += 1 + at / Math.max(1, p.seenN);
    }
    return s;
  };

  /** Everyone in the room has now seen this question; their devices remember it. */
  markSeen(id) {
    const k = seenKey(id);
    for (const p of this.members()) {
      if (!p.seen) {
        p.seen = new Map();
        p.seenN = 0;
      }
      p.seen.delete(k);
      p.seen.set(k, ++p.seenN);
    }
    this.fx('seen', { key: k });
  }

  fx(type, payload = {}) {
    for (const p of this.players.values()) if (p.connected) this.send(p, 'fx', { type, ...payload });
  }

  clearTimers() {
    clearTimeout(this.timer);
    clearInterval(this.ticker);
    clearTimeout(this.settleTimer);
    this.timer = this.ticker = this.settleTimer = null;
  }

  setPhase(phase, durationMs, onEnd) {
    this.clearTimers();
    this.phase = phase;
    this.startedAt = Date.now();
    if (durationMs) durationMs = Math.round(durationMs * SCALE);
    this.endsAt = durationMs ? this.startedAt + durationMs : null;
    if (durationMs && onEnd) this.timer = setTimeout(onEnd, durationMs);
  }

  // ---------- client events ----------

  handle(p, e, d = {}) {
    this.lastActivity = Date.now();
    const isHost = p.id === this.hostId;
    switch (e) {
      case 'update_settings':
        if (isHost && this.phase === PHASE.LOBBY) this.updateSettings(d);
        break;
      case 'start_game':
        if (isHost && this.phase === PHASE.LOBBY) this.startGame(p);
        break;
      case 'next':
        if (this.canControl(p)) {
          // Round details → overall standings → next turn
          if (this.phase === PHASE.ROUND_SCORING) this.showStandings('round', this.results.before, this.results.deltas);
          else if (this.phase === PHASE.BONUS_RESULTS)
            this.showStandings(this.bonus.type === 'auction' ? 'auction' : 'bonus', this.bonusResults.before, this.bonusResults.deltas);
          else if (this.phase === PHASE.STANDINGS) this.leaveStandings();
          // Game-moments cards: the host steps through them for everyone, then the podium appears.
          else if (this.phase === PHASE.GAME_OVER && this.final && this.final.moment < this.final.highlights.length) {
            this.final.moment += 1;
            this.broadcast();
          }
        }
        break;
      case 'play_again':
        if (isHost && this.phase === PHASE.GAME_OVER) this.backToLobby();
        break;
      case 'select_category':
        this.selectCategory(p, d.category);
        break;
      case 'select_level':
        this.selectLevel(p, d.level);
        break;
      case 'submit_answer':
        this.submitAnswer(p, d.option);
        break;
      case 'submit_warta':
        this.submitWarta(p, d.targetId ?? null);
        break;
      case 'submit_bonus_answer':
        this.submitBonusAnswer(p, d.option);
        break;
      case 'auction_select':
        this.auctionSelect(p, d.options);
        break;
      case 'auction_lock':
        this.auctionLock(p);
        break;
      case 'place_pin':
        this.placePin(p, d.lat, d.lng);
        break;
      case 'leave':
        this.removePlayer(p, 'left');
        break;
      case 'react':
        this.react(p, d.emoji);
        break;
      case 'seen':
        this.receiveSeen(p, d);
        break;
      case 'set_profile':
        this.setProfile(p, d.name, d.avatar);
        break;
      case 'kick':
        if (isHost && this.phase === PHASE.LOBBY && d.playerId !== p.id) {
          const target = this.players.get(d.playerId);
          if (target) this.removePlayer(target, 'kicked');
        }
        break;
      case 'rtt':
        if (typeof d.rtt === 'number' && d.rtt >= 0 && d.rtt < 5000) p.rtt = p.rtt ? p.rtt * 0.7 + d.rtt * 0.3 : d.rtt;
        break;
      default:
        break;
    }
  }

  updateSettings(d) {
    const s = this.settings;
    if (Array.isArray(d.categories)) {
      const valid = new Set(this.bank.categoryList().map((c) => c.key));
      const cats = d.categories.filter((c) => valid.has(c));
      if (cats.length) s.categories = [...new Set(cats)];
    }
    if (d.rounds !== undefined) {
      s.rounds = clampInt(d.rounds, 1, 200, s.rounds);
      s.roundsAuto = false; // the host picked a number: stop auto-updating
    }
    if (d.roundsAuto === true) s.roundsAuto = true;
    this.syncAutoRounds();
    if (d.maxPlayers !== undefined)
      s.maxPlayers = Math.max(this.members().length, clampInt(d.maxPlayers, 2, 20, s.maxPlayers));
    if (d.questionTime !== undefined) s.questionTime = clampInt(d.questionTime, 5, 120, s.questionTime);
    if (d.selectionTime !== undefined) s.selectionTime = clampInt(d.selectionTime, 5, 60, s.selectionTime);
    if (typeof d.wartaEnabled === 'boolean') s.wartaEnabled = d.wartaEnabled;
    if (typeof d.auctionEnabled === 'boolean') s.auctionEnabled = d.auctionEnabled;
    if (d.optionCount !== undefined) s.optionCount = clampInt(d.optionCount, 2, 8, s.optionCount);
    if (Array.isArray(d.bonusTypes)) s.bonusTypes = BONUS_TYPES.filter((t) => d.bonusTypes.includes(t)); // empty = no bonus rounds
    this.broadcast();
  }

  startGame(p) {
    const ready = this.activePlayers().filter((x) => x.connected && x.ready);
    if (!p.ready || ready.length < 2) {
      this.send(p, 'error', { message: 'تحتاج لاعبَين على الأقل جاهزَين لبدء اللعبة.' });
      return;
    }
    // Anyone still choosing a name/character misses this game.
    for (const x of this.activePlayers()) if (!x.ready) this.removePlayer(x, 'started');
    this.syncAutoRounds();
    this.resetGame();
    this.turnOrder = shuffle(this.activePlayers().map((x) => x.id));
    this.fx('game_start');
    this.nextTurn();
  }

  backToLobby() {
    this.clearTimers();
    // Drop anyone who left during the game.
    for (const p of [...this.players.values()]) {
      if (p.removed) this.players.delete(p.id);
      else if (p.spectator) p.spectator = false; // late arrivals join this game
    }
    this.resetGame();
    this.phase = PHASE.LOBBY;
    this.endsAt = null;
    this.syncAutoRounds();
    this.broadcast();
  }

  // ---------- main rounds ----------

  nextTurn() {
    this.round += 1;
    if (this.round > this.settings.rounds) {
      this.round = this.settings.rounds;
      this.endOfRounds();
      return;
    }
    // Next player in order who is still in the game.
    let active = null;
    for (let i = 0; i < this.turnOrder.length; i++) {
      this.turnIndex = (this.turnIndex + 1) % this.turnOrder.length;
      const cand = this.players.get(this.turnOrder[this.turnIndex]);
      if (cand && !cand.removed) {
        active = cand;
        break;
      }
    }
    if (!active) {
      this.finishGame(true);
      return;
    }
    // Two steps inside one selection timer: pick a category (from up to 3), then a level by its hint.
    const categories = this.bank.pickCategories(this.settings.categories, this.usedQuestions, 3, this.seenScore);
    this.turn = { activeId: active.id, categories, category: null, levels: null };
    this.current = null;
    this.results = null;
    if (categories.length === 1) this.chooseCategory(categories[0]);
    this.setPhase(PHASE.TURN_SELECTION, this.settings.selectionTime * 1000, () => this.autoPickQuestion());
    this.fx('turn_started', { activeId: active.id });
    // Asker already offline when the turn starts: don't make everyone wait for the timer.
    if (!active.connected) {
      this.autoPickQuestion();
      return;
    }
    this.broadcast();
  }

  chooseCategory(cat) {
    this.turn.category = cat;
    this.turn.levels = this.bank.levelCards(cat, this.usedQuestions, this.seenScore);
  }

  /** Time ran out (or the asker is gone): finish whatever step is left at random. */
  autoPickQuestion() {
    if (!this.turn) return;
    if (!this.turn.category) {
      const cats = shuffle(this.turn.categories);
      this.chooseCategory(cats.find((c) => this.bank.levelCards(c, this.usedQuestions, this.seenScore).some(Boolean)) || cats[0]);
    }
    const avail = (this.turn.levels || []).filter(Boolean);
    if (!avail.length) {
      // Should not happen with a non-empty bank; fall back to any question.
      const any = this.bank.questions[Math.floor(Math.random() * this.bank.questions.length)];
      if (any) this.startQuestion(any, true);
      return;
    }
    this.startQuestion(avail[Math.floor(Math.random() * avail.length)], true);
  }

  selectCategory(p, cat) {
    if (this.phase !== PHASE.TURN_SELECTION || !this.turn || p.id !== this.turn.activeId) return;
    if (this.turn.category || !this.turn.categories.includes(cat)) return;
    this.chooseCategory(cat);
    this.fx('category_picked', { category: cat });
    this.broadcast();
  }

  selectLevel(p, level) {
    if (this.phase !== PHASE.TURN_SELECTION || !this.turn || p.id !== this.turn.activeId || !this.turn.levels) return;
    const q = this.turn.levels[clampInt(level, 1, 3, 0) - 1];
    if (q) this.startQuestion(q, false);
  }

  startQuestion(raw, autoPicked) {
    this.usedQuestions.add(raw.id);
    this.markSeen(raw.id);
    const q = this.bank.instantiate(raw, this.settings.optionCount);
    this.current = {
      q,
      autoPicked,
      activeId: this.turn.activeId,
      participants: this.activePlayers().map((x) => x.id),
      answers: {},
      wartas: {}, // bettorId -> targetId
      wartaDone: new Set(),
      wartaLists: {},
    };
    if (this.settings.wartaEnabled) {
      const counts = {};
      for (const id of this.current.participants) counts[id] = this.players.get(id).timesTargeted || 0;
      this.current.wartaLists = wartaLists(this.current.participants, counts);
    }
    this.setPhase(PHASE.QUESTION_ACTIVE, this.settings.questionTime * 1000, () => this.endQuestion());
    this.fx('question');
    this.broadcast();
  }

  submitAnswer(p, option) {
    const c = this.current;
    if (this.phase !== PHASE.QUESTION_ACTIVE || !c || !c.participants.includes(p.id)) return;
    if (c.answers[p.id] !== undefined) return;
    if (!Number.isInteger(option) || option < 0 || option >= c.q.options.length) return;
    c.answers[p.id] = option;
    this.broadcast();
    this.checkEarlyEnd();
  }

  /** ورّطه: the names this player may pick from in this question (fixed when the question starts). */
  wartaTargets(p) {
    const c = this.current;
    if (!c || !this.settings.wartaEnabled) return [];
    return (c.wartaLists[p.id] || []).filter((id) => {
      const t = this.players.get(id);
      return t && !t.removed;
    });
  }

  needsWarta(p) {
    const c = this.current;
    return this.settings.wartaEnabled && !c.wartaDone.has(p.id) && this.wartaTargets(p).length > 0;
  }

  submitWarta(p, targetId) {
    const c = this.current;
    if (this.phase !== PHASE.QUESTION_ACTIVE || !c || !c.participants.includes(p.id)) return;
    if (!this.settings.wartaEnabled || c.wartaDone.has(p.id)) return;
    if (targetId !== null && !this.wartaTargets(p).includes(targetId)) return;
    if (targetId !== null) c.wartas[p.id] = targetId;
    c.wartaDone.add(p.id);
    this.broadcast();
    this.checkEarlyEnd();
  }

  checkEarlyEnd() {
    if (this.phase === PHASE.QUESTION_ACTIVE && this.current) {
      const c = this.current;
      const waiting = c.participants
        .map((id) => this.players.get(id))
        .filter((x) => x && x.connected && !x.removed)
        .some((x) => c.answers[x.id] === undefined || this.needsWarta(x));
      if (!waiting) this.endQuestion();
    } else if (this.phase === PHASE.BONUS_ROUND && this.bonus && !this.bonus.pending) {
      const b = this.bonus;
      const stillPlaying = b.eligible
        .map((id) => this.players.get(id))
        .filter((x) => x && x.connected && !x.removed)
        .some((x) =>
          b.type === 'coordinates' ? !b.pins[x.id] : b.type === 'auction' ? !b.locked.has(x.id) : !b.lockedOut.has(x.id),
        );
      if (!stillPlaying) this.endBonus();
    }
  }

  endQuestion() {
    const c = this.current;
    if (!c || this.phase !== PHASE.QUESTION_ACTIVE) return;
    const before = this.scoreSnapshot();
    const r = scoreMainRound({
      activeId: c.activeId,
      correct: c.q.answer,
      answers: c.answers,
      wartas: c.wartas,
      participants: c.participants,
    });
    for (const [id, delta] of Object.entries(r.deltas)) {
      const p = this.players.get(id);
      if (!p) continue;
      p.score += delta;
      const a = c.answers[id];
      if (a !== undefined) {
        p.stats.answered += 1;
        if (a === c.q.answer) p.stats.correct += 1;
      }
      const wr = r.wartaResults[id];
      if (wr === 'caught') p.stats.wartaWins += 1;
      if (wr === 'escaped') p.stats.wartaLosses += 1;
    }
    for (const [bettor, target] of Object.entries(c.wartas)) {
      const t = this.players.get(target);
      if (t) t.timesTargeted = (t.timesTargeted || 0) + 1;
      if (t && r.wartaResults[bettor] === 'escaped') t.stats.wartaEscapes += 1;
    }
    if (r.loneId) {
      const p = this.players.get(r.loneId);
      if (p) p.stats.loneCorrect += 1;
    }
    const active = this.players.get(c.activeId);
    if (active) active.stats.trapsSprung += r.victims.length;
    for (const v of r.victims) {
      const p = this.players.get(v);
      if (p) p.stats.fellInTraps += 1;
    }
    this.history.push({
      round: this.round,
      text: c.q.text,
      answerText: c.q.options[c.q.answer],
      activeId: c.activeId,
      activeAnswerText: c.answers[c.activeId] !== undefined ? c.q.options[c.answers[c.activeId]] : null,
      victims: r.victims.slice(),
      wartas: { ...c.wartas },
      wartaResults: { ...r.wartaResults },
      loneId: r.loneId,
      answered: Object.keys(c.answers).length,
      correctCount: Object.values(c.answers).filter((a) => a === c.q.answer).length,
    });
    this.results = {
      question: { text: c.q.text, options: c.q.options, category: c.q.category, difficulty: c.q.difficulty, hint: c.q.hint },
      autoPicked: c.autoPicked,
      correct: c.q.answer,
      activeId: c.activeId,
      activeAnswer: c.answers[c.activeId] ?? null,
      activeCorrect: r.activeCorrect,
      answers: c.answers,
      wartas: c.wartas,
      wartaResults: r.wartaResults,
      loneId: r.loneId,
      victims: r.victims,
      wrongOpponents: r.wrongOpponents,
      breakdown: r.breakdown,
      deltas: r.deltas,
      before,
    };
    // Results stay up until the host moves on.
    this.setPhase(PHASE.ROUND_SCORING, 0);
    this.fx('round_results', { trap: r.victims.length > 0 });
    this.broadcast();
  }

  showStandings(from, before, deltas) {
    this.standings = { from, before: before || {}, deltas: deltas || {} };
    this.setPhase(PHASE.STANDINGS, T.STANDINGS_AUTO, () => this.leaveStandings());
    this.fx('standings');
    this.broadcast();
  }

  leaveStandings() {
    if (this.phase !== PHASE.STANDINGS) return;
    if (this.standings.from === 'round') this.afterRound();
    else this.afterBonus();
  }

  afterRound() {
    if (this.round % 2 === 0 && this.bonusRotation().length) this.startBonus(null);
    else this.nextTurn();
  }

  // ---------- bonus rounds ----------

  /** All regular rounds are done: the auction (if enabled) is always the very last question. */
  endOfRounds() {
    if (this.settings.auctionEnabled && !this.auctionDone) {
      this.auctionDone = true;
      this.startBonus(null, 'auction');
      return;
    }
    this.finishGame();
  }

  startBonus(eligibleIds, forceType = null) {
    let type = null;
    let q = null;
    if (forceType) {
      type = forceType;
      q = this.bank.pickBonus(type, this.usedBonus, this.seenScore);
    }
    // Rotate through the host's chosen mini-games (+ the auction if enabled).
    // A tie-break needs a single fastest player, so it uses the speed games only.
    const types = eligibleIds
      ? this.settings.bonusTypes.length
        ? this.settings.bonusTypes
        : BONUS_TYPES
      : this.bonusRotation();
    for (let i = 0; i < types.length && !q && !forceType; i++) {
      type = types[this.bonusCounter % types.length];
      this.bonusCounter += 1;
      q = this.bank.pickBonus(type, this.usedBonus, this.seenScore);
    }
    if (!q) {
      // No content for this mini-game — skip straight on.
      if (forceType === 'auction') this.finishGame();
      else this.afterBonus();
      return;
    }
    this.markSeen(q.id);
    const eligible = (eligibleIds || this.activePlayers().map((x) => x.id)).slice();
    const b = {
      type,
      q,
      eligible,
      disabled: new Set(),
      lockedOut: new Set(),
      attempts: {}, // pid -> { option, correct }
      pins: {},
      pending: null,
      winnerId: null,
      deltas: {},
      revealed: 0,
      revealOrder: null,
      words: null,
      clockStarted: false,
    };
    if (type === 'censored') {
      b.words = String(q.paragraph).split(/\s+/).filter(Boolean);
      b.revealOrder = shuffle(b.words.map((_, i) => i));
      b.revealed = Math.round(b.words.length * 0.2);
    }
    if (type === 'pixel') this.imageToken = token();
    if (type === 'auction') {
      b.auction = this.bank.instantiateAuction(q);
      b.selections = {}; // pid -> Set of option indexes
      b.locked = new Set();
    }
    b.before = this.scoreSnapshot();
    this.bonus = b;
    this.bonusResults = null;

    // Short intro so everyone sees which mini-game is coming, then the real clock.
    this.setPhase(PHASE.BONUS_ROUND, T.BONUS_INTRO, () => this.startBonusClock());
    b.introEndsAt = this.endsAt;
    this.fx('bonus_start', { bonusType: type });
    this.broadcast();
  }

  startBonusClock() {
    const b = this.bonus;
    if (!b || this.phase !== PHASE.BONUS_ROUND) return;
    this.setPhase(PHASE.BONUS_ROUND, this.settings.questionTime * 1000, () => this.endBonus());
    const duration = this.endsAt - this.startedAt;
    b.clockStarted = true;
    if (b.type === 'censored') {
      const total = b.words.length;
      const start = b.revealed;
      this.ticker = setInterval(() => {
        const f = Math.min(1, (Date.now() - this.startedAt) / (duration * 0.9));
        const next = Math.min(total, start + Math.round((total - start) * f));
        if (next !== b.revealed) {
          b.revealed = next;
          this.broadcast();
        }
      }, Math.max(50, 1000 * SCALE));
    }
    this.broadcast();
  }

  latencyComp(p) {
    return Math.min(T.MAX_LATENCY_COMP, (p.rtt || 0) / 2);
  }

  bonusAcceptsFrom(p) {
    const b = this.bonus;
    return this.phase === PHASE.BONUS_ROUND && b && b.clockStarted && !b.winnerId && b.eligible.includes(p.id) && !p.removed;
  }

  /** Register a correct hit; the earliest (latency-adjusted) one inside the settle window wins. */
  registerCorrect(p, at) {
    const b = this.bonus;
    if (b.pending && b.pending.at <= at) return false;
    b.pending = { pid: p.id, at };
    if (!this.settleTimer) {
      this.settleTimer = setTimeout(() => {
        this.settleTimer = null;
        if (!this.bonus || this.bonus !== b) return;
        b.winnerId = b.pending.pid;
        this.endBonus();
      }, T.SETTLE);
    }
    return true;
  }

  /** Auction: replace this player's current picks (allowed until they lock in or time runs out). */
  auctionSelect(p, options) {
    const b = this.bonus;
    if (!this.bonusAcceptsFrom(p) || b.type !== 'auction' || b.locked.has(p.id) || !Array.isArray(options)) return;
    const n = b.auction.options.length;
    b.selections[p.id] = new Set(options.filter((i) => Number.isInteger(i) && i >= 0 && i < n));
    this.send(p, 'state', this.view(p));
  }

  auctionLock(p) {
    const b = this.bonus;
    if (!this.bonusAcceptsFrom(p) || b.type !== 'auction' || b.locked.has(p.id)) return;
    b.locked.add(p.id);
    this.broadcast();
    this.checkEarlyEnd();
  }

  submitBonusAnswer(p, option) {
    const b = this.bonus;
    if (!this.bonusAcceptsFrom(p) || b.type === 'coordinates' || b.type === 'auction') return;
    if (b.lockedOut.has(p.id) || b.attempts[p.id]) return;
    if (!Number.isInteger(option) || option < 0 || option >= b.q.options.length) return;
    if (b.disabled.has(option)) return; // someone already burned it — tap ignored, no penalty
    const at = Date.now() - this.latencyComp(p);
    if (b.pending && at > b.pending.at) return; // too late: someone already got it
    const correct = option === b.q.answer;
    if (correct) {
      b.attempts[p.id] = { option, correct: true };
      this.registerCorrect(p, at);
      return;
    }
    b.attempts[p.id] = { option, correct: false };
    b.disabled.add(option);
    b.lockedOut.add(p.id);
    b.deltas[p.id] = (b.deltas[p.id] || 0) - 1;
    p.score -= 1;
    this.fx('bonus_option_eliminated', { option, playerId: p.id });
    this.broadcast();
    this.checkEarlyEnd();
  }

  placePin(p, lat, lng) {
    const b = this.bonus;
    if (!this.bonusAcceptsFrom(p) || b.type !== 'coordinates' || b.pins[p.id]) return;
    if (typeof lat !== 'number' || typeof lng !== 'number' || !Number.isFinite(lat) || !Number.isFinite(lng)) return;
    if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return;
    const at = Date.now() - this.latencyComp(p);
    if (b.pending && at > b.pending.at) return;
    const distanceKm = haversineKm({ lat, lng }, b.q.target);
    const inside = distanceKm <= b.q.radiusKm;
    b.pins[p.id] = { lat, lng, distanceKm, inside, at };
    this.fx('pin_dropped', { playerId: p.id, inside });
    if (inside) {
      this.registerCorrect(p, at);
      return;
    }
    this.broadcast();
    this.checkEarlyEnd();
  }

  endBonus() {
    const b = this.bonus;
    if (!b || this.phase !== PHASE.BONUS_ROUND) return;
    this.clearTimers();
    if (!b.winnerId && b.pending) b.winnerId = b.pending.pid;
    let closestId = null;
    if (b.type === 'coordinates') {
      const pins = {};
      for (const [id, pin] of Object.entries(b.pins)) if (!b.winnerId || pin.at <= b.pins[b.winnerId].at || id === b.winnerId) pins[id] = pin;
      const r = scoreCoordinates({ pins, radiusKm: b.q.radiusKm, winnerId: b.winnerId });
      closestId = r.closestId;
      for (const [id, d] of Object.entries(r.deltas)) {
        const p = this.players.get(id);
        if (!p) continue;
        p.score += d;
        b.deltas[id] = (b.deltas[id] || 0) + d;
      }
      if (!b.winnerId && closestId) {
        const p = this.players.get(closestId);
        if (p) p.stats.bonusWins += 1;
      }
    } else if (b.type === 'auction') {
      const selections = {};
      for (const [id, set] of Object.entries(b.selections)) if (set.size) selections[id] = [...set];
      const r = scoreAuction({ selections, correct: b.auction.correctIdx });
      for (const [id, d] of Object.entries(r.deltas)) {
        const p = this.players.get(id);
        if (!p) continue;
        p.score += d;
        b.deltas[id] = (b.deltas[id] || 0) + d;
      }
      b.auctionResult = { correct: b.auction.correctIdx, selections, detail: r.detail };
    } else if (b.winnerId) {
      const p = this.players.get(b.winnerId);
      if (p) p.score += 2;
      b.deltas[b.winnerId] = (b.deltas[b.winnerId] || 0) + 2;
    }
    if (b.winnerId) {
      const p = this.players.get(b.winnerId);
      if (p) p.stats.bonusWins += 1;
    }
    if (b.type === 'censored') b.revealed = b.words.length;

    this.bonusResults = {
      winnerId: b.winnerId,
      closestId,
      deltas: b.deltas,
      answer: b.type === 'coordinates' || b.type === 'auction' ? null : b.q.answer,
      auction: b.auctionResult || null,
      target: b.type === 'coordinates' ? { ...b.q.target, radiusKm: b.q.radiusKm } : null,
      pins: b.type === 'coordinates' ? Room.pinView(b.pins) : null,
      attempts: Object.fromEntries(Object.entries(b.attempts).map(([id, x]) => [id, x.option])),
      before: b.before,
    };
    this.setPhase(PHASE.BONUS_RESULTS, 0);
    this.fx('bonus_results', { winnerId: b.winnerId || closestId });
    this.broadcast();
  }

  bonusDone(b, id) {
    if (b.type === 'auction') return b.locked.has(id);
    if (b.type === 'coordinates') return !!b.pins[id];
    return !!b.attempts[id];
  }

  /** Speed mini-games used every two rounds, in rotation order (the auction is separate). */
  bonusRotation() {
    return this.settings.bonusTypes.slice();
  }

  afterBonus() {
    // After a tie-break or the closing auction, check the result (more tie-breaks if still tied).
    if (this.inTiebreak || (this.bonus && this.bonus.type === 'auction')) this.finishGame();
    else this.nextTurn();
  }

  static pinView(pins) {
    const out = {};
    for (const [id, pin] of Object.entries(pins)) out[id] = { lat: pin.lat, lng: pin.lng, inside: pin.inside, km: Math.round(pin.distanceKm) };
    return out;
  }

  // ---------- end of game ----------

  ranking() {
    return this.activePlayers()
      .concat([...this.players.values()].filter((p) => p.removed))
      .map((p) => ({ id: p.id, score: p.score, removed: p.removed }))
      .sort((a, b) => b.score - a.score);
  }

  finishGame(force = false) {
    this.clearTimers();
    const inGame = this.activePlayers();
    const top = Math.max(...inGame.map((p) => p.score));
    const leaders = inGame.filter((p) => p.score === top);
    const connectedLeaders = leaders.filter((p) => p.connected);
    if (!force && leaders.length > 1 && connectedLeaders.length > 1 && this.tiebreaks < MAX_TIEBREAKS) {
      this.tiebreaks += 1;
      this.inTiebreak = true;
      this.fx('tiebreak', { playerIds: leaders.map((p) => p.id) });
      this.startBonus(leaders.map((p) => p.id));
      return;
    }
    this.inTiebreak = false;
    this.final = {
      ranking: this.ranking(),
      winners: leaders.map((p) => p.id),
      badges: computeBadges([...this.players.values()].filter((p) => !p.spectator)),
      highlights: this.highlights(),
      moment: 0, // index of the moment card on screen; == highlights.length → podium
      tiebreaks: this.tiebreaks,
    };
    this.phase = PHASE.GAME_OVER;
    this.startedAt = Date.now();
    this.endsAt = null;
    this.fx('game_over');
    this.broadcast();
  }

  /** Up to 3 "moments of the game" cards for the end screen, built from the question history. */
  highlights() {
    const name = (id) => (this.players.get(id) ? this.players.get(id).name : 'لاعب');
    const join = (ids) => {
      const n = ids.map(name);
      return n.length <= 1 ? n.join('') : `${n.slice(0, -1).join('، ')} و${n[n.length - 1]}`;
    };
    const out = [];
    const h = this.history || [];
    // 1) Biggest trap: most players picked the asker's wrong answer
    const trap = h.filter((x) => x.victims.length).sort((a, b) => b.victims.length - a.victims.length || b.round - a.round)[0];
    if (trap) {
      out.push({
        kind: 'trap',
        icon: '🪤',
        title: 'أكبر فخ في اللعبة',
        text: `${name(trap.activeId)} أوقع ${join(trap.victims)} في «${trap.activeAnswerText}»`,
        question: trap.text,
        answer: trap.answerText,
      });
    }
    // 2) Sharpest snipe (اقنصه): the player hit by the most snipers in a single question
    let worst = null;
    for (const x of h) {
      const caught = {};
      for (const [bettor, target] of Object.entries(x.wartas)) {
        if (x.wartaResults[bettor] === 'caught') (caught[target] = caught[target] || []).push(bettor);
      }
      for (const [target, by] of Object.entries(caught)) {
        if (!worst || by.length > worst.by.length || (by.length === worst.by.length && x.round > worst.round)) worst = { target, by, round: x.round, text: x.text };
      }
    }
    if (worst) {
      out.push({
        kind: 'warta',
        icon: '🎯',
        title: 'أدق قنصة',
        text: worst.by.length > 1 ? `${name(worst.target)} قنصه ${join(worst.by)} معاً في سؤال واحد فأصابوه` : `${name(worst.by[0])} قنص ${name(worst.target)} فأصابه`,
        question: worst.text,
      });
    }
    // 3) The question nobody knew
    const none = h.filter((x) => x.answered >= 2 && x.correctCount === 0).sort((a, b) => b.answered - a.answered)[0];
    if (none) {
      out.push({ kind: 'none', icon: '🤯', title: 'السؤال الذي لم يعرفه أحد', text: `أجاب ${none.answered} لاعبين وأخطأوا جميعاً`, question: none.text, answer: none.answerText });
    }
    // Fallback: a lone-genius moment
    if (out.length < 3) {
      const lone = h.filter((x) => x.loneId).pop();
      if (lone) out.push({ kind: 'lone', icon: '⭐', title: 'لحظة العبقرية', text: `${name(lone.loneId)} الوحيد الذي عرف الإجابة`, question: lone.text, answer: lone.answerText });
    }
    return out.slice(0, 3);
  }

  react(p, emoji) {
    const ALLOWED = ['😂', '🔥', '😱', '👏', '🤡', '💀'];
    if (!ALLOWED.includes(emoji) || !p.ready) return;
    const now = Date.now();
    if (p.lastReact && now - p.lastReact < 600) return; // gentle rate limit
    p.lastReact = now;
    this.fx('reaction', { playerId: p.id, emoji });
  }

  // ---------- personalised snapshot ----------

  view(me) {
    const c = this.current;
    const b = this.bonus;
    const players = [...this.players.values()].map((p) => ({
      id: p.id,
      name: p.name,
      avatar: p.avatar,
      ready: p.ready,
      spectator: !!p.spectator,
      score: p.score,
      connected: p.connected,
      removed: p.removed,
      done:
        this.phase === PHASE.QUESTION_ACTIVE && c
          ? c.answers[p.id] !== undefined
          : this.phase === PHASE.BONUS_ROUND && b
            ? this.bonusDone(b, p.id)
            : false,
    }));

    const v = {
      me: me.id,
      code: this.code,
      hostId: this.hostId,
      phase: this.phase,
      settings: this.settings,
      serverNow: Date.now(),
      startedAt: this.startedAt,
      endsAt: this.endsAt,
      round: this.round,
      players,
      inTiebreak: this.inTiebreak,
      auctionDone: this.auctionDone,
      controllerId: this.controllerId(),
    };

    if (this.phase === PHASE.LOBBY) {
      v.categories = this.bank.categoryList();
      v.avatars = AVATARS;
    }

    if (this.phase === PHASE.TURN_SELECTION && this.turn) {
      const mine = me.id === this.turn.activeId;
      v.turn = {
        activeId: this.turn.activeId,
        // Everyone sees the categories on offer and which one was picked…
        categories: this.turn.categories,
        category: this.turn.category,
        // …but only the asker sees the hints, and nobody sees a question before it is picked.
        levels: this.turn.levels
          ? this.turn.levels.map((q, i) => ({ level: i + 1, available: !!q, hint: mine && q ? q.hint : null }))
          : null,
      };
    }

    if (this.phase === PHASE.QUESTION_ACTIVE && c) {
      v.question = {
        text: c.q.text,
        options: c.q.options,
        category: c.q.category,
        difficulty: c.q.difficulty,
        activeId: c.activeId,
        autoPicked: c.autoPicked,
        participant: c.participants.includes(me.id),
        myAnswer: c.answers[me.id] ?? null,
        myWarta: c.wartas[me.id] ?? null,
        wartaDone: !this.needsWarta(me),
        wartaTargets: this.wartaTargets(me),
      };
    }

    if (this.phase === PHASE.ROUND_SCORING && this.results) v.results = this.results;

    if ((this.phase === PHASE.BONUS_ROUND || this.phase === PHASE.BONUS_RESULTS) && b) {
      const q = b.q;
      v.bonus = {
        type: b.type,
        clockStarted: b.clockStarted,
        eligible: b.eligible,
        disabled: [...b.disabled],
        lockedOut: [...b.lockedOut],
        myAttempt: b.attempts[me.id] ? { option: b.attempts[me.id].option, correct: b.attempts[me.id].correct } : null,
        tiebreak: this.inTiebreak,
      };
      if (b.type === 'coordinates') {
        v.bonus.text = q.text;
        v.bonus.region = q.region === 'world' ? 'world' : 'arab';
        // Live pins: only pins already known to be outside the area, plus my own.
        const live = {};
        for (const [id, pin] of Object.entries(b.pins)) {
          if (id === me.id || !pin.inside) live[id] = { lat: pin.lat, lng: pin.lng, inside: id === me.id ? pin.inside : false };
        }
        v.bonus.pins = live;
        v.bonus.myPin = b.pins[me.id] ? { lat: b.pins[me.id].lat, lng: b.pins[me.id].lng } : null;
      } else if (b.type === 'auction') {
        v.bonus.prompt = q.prompt;
        v.bonus.options = b.auction.options;
        v.bonus.mySelection = [...(b.selections[me.id] || [])];
        v.bonus.myLocked = b.locked.has(me.id);
      } else {
        v.bonus.options = q.options;
        v.bonus.prompt = q.prompt || null;
      }
      if (b.type === 'pixel' && b.clockStarted) v.bonus.image = `/bonus-img/${this.code}/${this.imageToken}`;
      if (b.type === 'link') v.bonus.words = q.words;
      if (b.type === 'censored') {
        const shown = new Set(b.revealOrder.slice(0, b.revealed));
        v.bonus.words = b.words.map((w, i) => (b.clockStarted && shown.has(i) ? w : { len: w.length }));
      }
    }
    if (this.phase === PHASE.BONUS_RESULTS) v.bonusResults = this.bonusResults;
    if (this.phase === PHASE.STANDINGS) v.standings = this.standings;
    if (this.phase === PHASE.GAME_OVER) v.final = this.final;
    return v;
  }
}

module.exports = { Room, PHASE, T, AVATARS };
