// Pure scoring functions — no I/O, easy to unit-test.

/**
 * Score a main (turn-based) round.
 * @param {object} p
 * @param {string} p.activeId           id of the player whose turn it is
 * @param {number} p.correct            index of the correct option
 * @param {Object<string, number>} p.answers  playerId -> chosen option index (missing = no answer)
 * @param {Object<string, string>} p.wartas   ورّطه: bettorId -> targetId ("I think this player gets it wrong")
 * @param {string[]} p.participants     ids of everyone who was in the round (active included)
 */
function scoreMainRound({ activeId, correct, answers, wartas = {}, participants }) {
  const deltas = {};
  const breakdown = {};
  for (const id of participants) {
    deltas[id] = 0;
    breakdown[id] = { answer: 0, bonus: 0, lone: 0, warta: 0, targeted: 0 };
  }

  const activeAnswer = answers[activeId];
  const activeAnswered = activeAnswer !== undefined && activeAnswer !== null;
  const activeCorrect = activeAnswered && activeAnswer === correct;

  const opponents = participants.filter((id) => id !== activeId);
  const wrongOpponents = [];
  const victims = []; // opponents who picked the same wrong option as the active player

  for (const id of opponents) {
    const a = answers[id];
    if (a === undefined || a === null) continue;
    if (a === correct) {
      breakdown[id].answer += 2;
    } else {
      wrongOpponents.push(id);
      if (activeAnswered && !activeCorrect && a === activeAnswer) victims.push(id);
    }
  }

  if (activeCorrect) {
    breakdown[activeId].answer += 2;
    breakdown[activeId].bonus += wrongOpponents.length; // +1 per opponent who answered wrong
  } else if (activeAnswered) {
    breakdown[activeId].bonus += victims.length; // +1 per opponent who picked the same wrong option
  }

  // الوحيد: with 3+ players, the only player (not the asker) who got it right earns +1 extra.
  const correctIds = participants.filter((id) => answers[id] === correct);
  const loneId = participants.length >= 3 && correctIds.length === 1 && correctIds[0] !== activeId ? correctIds[0] : null;
  if (loneId) breakdown[loneId].lone += 1;

  // ورّطه: target wrong → bettor +1, target −1. Target right → bettor −1, target +1.
  // Target didn't answer → nothing.
  const wartaResults = {};
  for (const [bettor, target] of Object.entries(wartas)) {
    if (!breakdown[bettor] || !breakdown[target]) continue;
    const a = answers[target];
    if (a === undefined || a === null) {
      wartaResults[bettor] = 'void';
    } else if (a === correct) {
      breakdown[bettor].warta -= 1;
      breakdown[target].targeted += 1;
      wartaResults[bettor] = 'escaped';
    } else {
      breakdown[bettor].warta += 1;
      breakdown[target].targeted -= 1;
      wartaResults[bettor] = 'caught';
    }
  }

  for (const id of participants) {
    const b = breakdown[id];
    deltas[id] = b.answer + b.bonus + b.lone + b.warta + b.targeted;
  }

  return { deltas, breakdown, victims, wrongOpponents, wartaResults, loneId, activeAnswered, activeCorrect };
}

/** Great-circle distance in km. */
function haversineKm(a, b) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

/**
 * Resolve a Coordinates War round once it ends.
 * Pins inside the target radius count as correct. The first correct pin (winnerId) gets +2.
 * Every pin outside the radius gets -1. If nobody hit the area, the closest pin gets +2 instead of -1.
 * @param {{ pins: Object<string, {lat:number,lng:number,distanceKm:number}>, radiusKm:number, winnerId?:string }} p
 */
function scoreCoordinates({ pins, radiusKm, winnerId }) {
  const deltas = {};
  let closestId = null;
  if (!winnerId) {
    let best = Infinity;
    for (const [id, pin] of Object.entries(pins)) {
      if (pin.distanceKm < best) {
        best = pin.distanceKm;
        closestId = id;
      }
    }
  }
  for (const [id, pin] of Object.entries(pins)) {
    if (id === winnerId || id === closestId) deltas[id] = 2;
    else if (pin.distanceKm > radiusKm) deltas[id] = -1;
    else deltas[id] = 0; // inside the area but not first
  }
  return { deltas, closestId };
}

/**
 * مزاد التعويض: +1 for every correct option a player selected, −1 for every wrong one.
 * @param {{ selections: Object<string, number[]>, correct: number[] }} p
 */
function scoreAuction({ selections, correct }) {
  const right = new Set(correct);
  const deltas = {};
  const detail = {};
  for (const [id, sel] of Object.entries(selections)) {
    const uniq = [...new Set(sel)];
    const hits = uniq.filter((i) => right.has(i)).length;
    const misses = uniq.length - hits;
    deltas[id] = hits - misses;
    detail[id] = { hits, misses };
  }
  return { deltas, detail };
}

/**
 * ورّطه candidate lists, one per player, so nobody can be focused on deliberately:
 *  - at most 3 names per list, different for each player, never yourself
 *  - gap rule: anyone already targeted 2+ times more than the least-targeted player is left out
 *  - each name appears in at most 2 lists per question, so at most 2 people can hit the same
 *    player in one question (lists are filled round by round, so everyone gets at least one name)
 *  - the least-targeted / least-shown come first, with a little randomness
 * Lists therefore usually hold 2 names, sometimes 1 or 3, depending on how targeting is spread.
 * @param {string[]} ids            players in this question
 * @param {Object<string, number>} counts  times each player has been targeted so far this game
 */
function wartaLists(ids, counts, rnd = Math.random, max = 3, cap = 2) {
  const lists = {};
  if (ids.length < 2) return lists;
  const c = (id) => counts[id] || 0;
  const min = Math.min(...ids.map(c));
  const open = ids.filter((id) => c(id) - min < 2);
  const shown = {};
  const order = ids.slice().sort(() => rnd() - 0.5);
  for (const me of order) lists[me] = [];
  const poolFor = (me) => {
    let pool = open.filter((id) => id !== me);
    if (!pool.length) {
      // Only when the single "open" player is me: fall back to the least-targeted others.
      const others = ids.filter((id) => id !== me).sort((a, b) => c(a) - c(b));
      pool = others.filter((id) => c(id) === c(others[0]));
    }
    return pool;
  };
  for (let pass = 0; pass < max; pass++) {
    for (const me of order) {
      const pool = poolFor(me).filter((id) => !lists[me].includes(id));
      // First name: always give one (least-shown wins). Extra names: only under the cap.
      const usable = pass === 0 ? pool : pool.filter((id) => (shown[id] || 0) < cap);
      if (!usable.length) continue;
      const best = usable
        .map((id) => ({ id, w: (shown[id] || 0) * 2 + c(id) + rnd() * 1.2 }))
        .sort((a, b) => a.w - b.w)[0].id;
      lists[me].push(best);
      shown[best] = (shown[best] || 0) + 1;
    }
  }
  return lists;
}

module.exports = { scoreMainRound, haversineKm, scoreCoordinates, scoreAuction, wartaLists };
