// Question bank loader. Swap the JSON files in server/data to replace the questions.
const fs = require('fs');
const path = require('path');

const DATA = path.join(__dirname, '..', 'data');

const CATEGORIES = {
  sports: 'رياضة',
  quran: 'قرآن',
  sunnah: 'سنة نبوية',
  history: 'تاريخ',
  geography: 'جغرافيا',
  science: 'علوم',
  literature: 'أدب ولغة',
  general: 'ثقافة عامة',
  seerah: 'سيرة وصحابة',
  football: 'كرة القدم',
  flags: 'أعلام ودول',
  proverbs: 'أمثال وتراث',
  media: 'فن وإعلام',
  tech: 'تقنية وإنترنت',
  brands: 'شركات وماركات',
  nature: 'طبيعة وحيوانات',
  space: 'فضاء وفلك',
  logic: 'ألغاز ومنطق',
  food: 'أكلات ومطابخ',
};

// Speed mini-games the host can pick from. The auction (مزاد التعويض) has its own on/off setting.
const BONUS_TYPES = ['coordinates', 'pixel', 'link', 'censored'];
const ALL_BONUS = [...BONUS_TYPES, 'auction'];
const AUCTION_EACH = 5; // 5 correct + 5 wrong = 10 options

// Three question levels. The file stores `level` as a key; internally it is `difficulty` 1–3.
const LEVELS = ['salka', 'matab', 'warta'];
const LEVEL_LABEL = { salka: 'سالكة', matab: 'مطبّ', warta: 'ورطة' };

function normalizeQuestion(q) {
  let d = LEVELS.indexOf(q.level) + 1;
  if (!d) d = Math.max(1, Math.min(3, Number(q.difficulty) || 2)); // older files: difficulty 1–3
  return { ...q, level: LEVELS[d - 1], difficulty: d, hint: q.hint || '' };
}

function readJson(rel, fallback = []) {
  try {
    return JSON.parse(fs.readFileSync(path.join(DATA, rel), 'utf8'));
  } catch (e) {
    console.warn(`[bank] could not read ${rel}: ${e.message}`);
    return fallback;
  }
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Random pick among the items with the lowest "already seen" score. */
function leastSeen(items, seen) {
  let best = Infinity;
  let pick = [];
  for (const q of items) {
    const v = seen(q.id);
    if (v < best - 1e-9) {
      best = v;
      pick = [q];
    } else if (Math.abs(v - best) < 1e-9) pick.push(q);
  }
  return pick[Math.floor(Math.random() * pick.length)];
}

/** Short, stable key for a question id (shared with the client, which stores what it has seen). */
function seenKey(id) {
  let h = 5381;
  for (let i = 0; i < id.length; i++) h = ((h * 33) ^ id.charCodeAt(i)) >>> 0;
  return h.toString(36).padStart(7, '0');
}

class Bank {
  constructor() {
    this.reload();
  }

  reload() {
    this.questions = readJson('questions.json').map(normalizeQuestion);
    this.bonus = {};
    for (const t of ALL_BONUS) this.bonus[t] = readJson(`bonus/${t}.json`);
  }

  /** Categories that actually have questions, with counts. */
  categoryList() {
    return Object.entries(CATEGORIES).map(([key, label]) => ({
      key,
      label,
      count: this.questions.filter((q) => q.category === key).length,
    }));
  }

  /**
   * Step 1 of a turn: up to `n` random categories (from the host's selection) that have questions.
   * Categories that still have a question nobody in the room has seen come first, then categories
   * with questions not yet asked in this room, then the rest.
   * `used` is a Set of question ids already asked in this room; `seen(id)` scores how much the
   * players in the room have already seen a question (0 = nobody).
   */
  pickCategories(categories, used, n = 3, seen = () => 0) {
    let cats = categories.filter((c) => this.questions.some((q) => q.category === c));
    if (!cats.length) cats = [...new Set(this.questions.map((q) => q.category))];
    const rank = (c) => {
      const pool = this.questions.filter((q) => q.category === c && !used.has(q.id));
      if (!pool.length) return 2;
      return pool.some((q) => seen(q.id) === 0) ? 0 : 1;
    };
    const ranked = shuffle(cats).map((c) => ({ c, r: rank(c) }));
    ranked.sort((a, b) => a.r - b.r);
    return ranked.map((x) => x.c).slice(0, n);
  }

  /**
   * Step 2: one question per level (سالكة / مطبّ / ورطة) from a category, or null when the
   * category has no question of that level at all. Picks among questions not asked in this room
   * the one the players have seen least (unseen first, then the longest ago); a level whose
   * questions were all used in this room is recycled.
   */
  levelCards(category, used, seen = () => 0) {
    return LEVELS.map((_, i) => {
      const d = i + 1;
      const pool = this.questions.filter((q) => q.category === category && q.difficulty === d);
      if (!pool.length) return null;
      let fresh = pool.filter((q) => !used.has(q.id));
      if (!fresh.length) {
        for (const q of pool) used.delete(q.id);
        fresh = pool;
      }
      return leastSeen(fresh, seen);
    });
  }

  pickBonus(type, used, seen = () => 0) {
    const pool = this.bonus[type] || [];
    if (!pool.length) return null;
    let fresh = pool.filter((q) => !used.has(q.id));
    if (!fresh.length) {
      for (const q of pool) used.delete(q.id);
      fresh = pool.slice();
    }
    const q = leastSeen(fresh, seen);
    used.add(q.id);
    return q;
  }

  /**
   * A playable copy of a main question with `count` options (2–8): the correct one plus
   * randomly chosen wrong ones, shuffled. Works with banks of 4 or 8 options.
   */
  instantiate(q, count) {
    const wrong = shuffle(q.options.filter((_, i) => i !== q.answer));
    const n = Math.max(2, Math.min(count, wrong.length + 1));
    const opts = shuffle([q.options[q.answer], ...wrong.slice(0, n - 1)]);
    return { ...q, options: opts, answer: opts.indexOf(q.options[q.answer]) };
  }

  /** Auction round: 5 correct + 5 wrong options sampled from the item, shuffled. */
  instantiateAuction(q) {
    const right = shuffle(q.correct).slice(0, AUCTION_EACH);
    const wrong = shuffle(q.wrong).slice(0, AUCTION_EACH);
    const options = shuffle([...right, ...wrong]);
    return { ...q, options, correctIdx: options.map((o, i) => (right.includes(o) ? i : -1)).filter((i) => i >= 0) };
  }

  imagePath(rel) {
    const full = path.normalize(path.join(DATA, 'images', rel));
    if (!full.startsWith(path.join(DATA, 'images'))) return null;
    return full;
  }
}

module.exports = { Bank, seenKey, leastSeen, CATEGORIES, BONUS_TYPES, ALL_BONUS, LEVELS, LEVEL_LABEL, normalizeQuestion, shuffle };
