ورطة — ملفات الشعار

wordmark-for-dark-bg.svg / .png   الشعار الكتابي للخلفيات الداكنة
wordmark-for-light-bg.svg / .png  الشعار الكتابي للخلفيات الفاتحة
lockup-dark.svg / .png            الشعار مع الشعار اللفظي «إذا وقعت… اسحبهم معك» على خلفية داكنة
lockup-light.svg / .png           نفسه على خلفية فاتحة
icon.svg, icon-1024/512/192.png   أيقونة التطبيق
icon-maskable.svg / -512.png      أيقونة بخلفية كاملة (أندرويد / تثبيت التطبيق)
apple-touch-icon.png              أيقونة آيفون 180×180
favicon.svg, favicon-32.png       أيقونة تبويب المتصفح

الألوان:
  كحلي الليل   #1E1A4D
  ورقي         #FFF4DE
  زعفراني      #FFB627   (ظل: #C98500)
  مرجاني       #FF5D73   (لون النقطة الساقطة)

الخط: Changa ExtraBold (رخصة OFL المفتوحة) — الملفات مفرّغة إلى أشكال فلا تحتاج الخط لعرضها.
build-brand.py يعيد توليد الملفات.
