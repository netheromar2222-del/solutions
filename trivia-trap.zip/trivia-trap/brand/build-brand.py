# Builds the ورطة brand files as fully outlined SVG (no font needed to view them).
import math, os, sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)
NIGHT, PAPER, SAFFRON, SAFFRON_D, CORAL, MUTED = '#1E1A4D', '#FFF4DE', '#FFB627', '#C98500', '#FF5D73', '#5B54A8'

def load(path):
    f = TTFont(path)
    return f, f.getGlyphSet(), f['head'].unitsPerEm, f['hmtx'], f.getBestCmap()

BOLD = load(sys.argv[1] + '/Changa-800.ttf')
MED = load(sys.argv[1] + '/Changa-500.ttf')

def forms(font):
    gsub = font['GSUB'].table
    out = {}
    for fr in gsub.FeatureList.FeatureRecord:
        if fr.FeatureTag in ('init', 'medi', 'fina', 'isol'):
            for li in fr.Feature.LookupListIndex:
                for st in gsub.LookupList.Lookup[li].SubTable:
                    m = getattr(st, 'mapping', None)
                    if m:
                        for k, v in m.items():
                            out[(fr.FeatureTag, k)] = v
    return out

RIGHT_JOIN = set('اأإآدذرزوؤة')
def is_ar(c):
    return 'ؠ' <= c <= 'ي'
def dual(c):
    return is_ar(c) and c not in RIGHT_JOIN

def shape(text, F):
    """Tiny Arabic shaper (enough for short brand text without lam-alef)."""
    font, gs, upm, hmtx, cmap = F
    fm = forms(font)
    names = []
    for i, c in enumerate(text):
        g = cmap.get(ord(c))
        if g is None:
            continue
        prev = text[i - 1] if i > 0 else ''
        nxt = text[i + 1] if i + 1 < len(text) else ''
        jp = is_ar(c) and dual(prev)
        jn = dual(c) and is_ar(nxt)
        tag = 'medi' if jp and jn else 'fina' if jp else 'init' if jn else 'isol'
        names.append(fm.get((tag, g), g))
    return names

def run(glyphs, F, cx, base, size):
    font, gs, upm, hmtx, cmap = F
    k = size / upm
    total = sum(hmtx[g][0] for g in glyphs) * k
    x = cx + total / 2
    pen = SVGPathPen(gs, ntos=lambda v: f'{v:.1f}')
    bp = BoundsPen(gs)
    for g in glyphs:
        x -= hmtx[g][0] * k
        t = (k, 0, 0, -k, x, base)
        gs[g].draw(TransformPen(pen, t))
        gs[g].draw(TransformPen(bp, t))
    return pen.getCommands(), bp.bounds

def dot(cx, cy, d, fill, rot=45, cls=''):
    s = d / math.sqrt(2)
    c = f' class="{cls}"' if cls else ''
    return (f'<rect{c} x="{cx - s/2:.1f}" y="{cy - s/2:.1f}" width="{s:.1f}" height="{s:.1f}" rx="{s*0.3:.1f}" '
            f'fill="{fill}" transform="rotate({rot} {cx:.1f} {cy:.1f})"/>')

WORD = ['uni0648', 'uni0631', 'uniFEC3', 'uniFEEA']  # و ر ط ه(final) — the ة dots are drawn by hand

def wordmark(ink, cx=500, base=330, size=260, fall=CORAL):
    k = size / 260
    d, b = run(WORD, BOLD, cx, base, size)
    body = (f'<path d="{d}" fill="{ink}"/>'
            + dot(cx - 203*k, base - 175*k, 40*k, ink)
            # the brand idea: one dot of the ة has slipped — someone just fell into the trap
            + dot(cx - 262*k, base - 160*k, 40*k, fall, rot=73, cls='slip'))
    top = base - 195*k
    return body, (b[0], top, b[2], b[3])

def svg(w, h, body, vb=None, bg=None, title='ورطة'):
    vb = vb or (0, 0, w, h)
    bgr = f'<rect x="{vb[0]}" y="{vb[1]}" width="{vb[2]}" height="{vb[3]}" fill="{bg}"/>' if bg else ''
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.0f}" height="{h:.0f}" viewBox="{" ".join(f"{v:.1f}" for v in vb)}" role="img" aria-label="{title}">'
            f'<title>{title}</title>{bgr}{body}</svg>\n')

def save(name, s):
    open(os.path.join(OUT, name), 'w').write(s)

# --- wordmarks (tight crop + margin) ---
for name, ink in [('wordmark-for-dark-bg.svg', PAPER), ('wordmark-for-light-bg.svg', NIGHT)]:
    body, bb = wordmark(ink)
    m = 24
    vb = (bb[0] - m, bb[1] - m, bb[2] - bb[0] + 2*m, bb[3] - bb[1] + 2*m)
    save(name, svg(vb[2], vb[3], body, vb))

# --- lockups with slogan ---
SLOGAN = 'إذا وقعت… اسحبهم معك'
def lockup(ink, bg, tag_ink):
    body, bb = wordmark(ink, base=300)
    d, tb = run(shape(SLOGAN, MED), MED, 500, 432, 46)
    body += f'<path d="{d}" fill="{tag_ink}"/>'
    return svg(1000, 540, body, (0, 0, 1000, 540), bg)
save('lockup-dark.svg', lockup(PAPER, NIGHT, SAFFRON))
save('lockup-light.svg', lockup(NIGHT, PAPER, MUTED))

# --- app icon: the ة on an answer-chip tile ---
def icon(S=1024, full_bleed=False, shadow=True):
    pad = 0 if full_bleed else S * 0.06
    r = S * 0.23
    sh = S * 0.035 if shadow and not full_bleed else 0
    out = ''
    if full_bleed:
        out += f'<rect width="{S}" height="{S}" fill="{SAFFRON}"/>'
    else:
        if sh:
            out += f'<rect x="{pad}" y="{pad + sh}" width="{S - 2*pad}" height="{S - 2*pad - sh}" rx="{r}" fill="{SAFFRON_D}"/>'
        out += f'<rect x="{pad}" y="{pad}" width="{S - 2*pad}" height="{S - 2*pad - sh}" rx="{r}" fill="{SAFFRON}"/>'
    fs = S * (0.62 if full_bleed else 0.70)
    k = fs / 300
    d, b = run(['uni0647'], BOLD, 0, 0, fs)
    d1 = (30*k, -202*k); d2 = (-62*k, -158*k); dd = 44*k
    x0 = min(b[0], d2[0] - dd/2); x1 = max(b[2], d1[0] + dd/2)
    y0 = min(d1[1], d2[1]) - dd/2; y1 = b[3]
    tx = S/2 - (x0 + x1)/2; ty = (S/2 - sh/2) - (y0 + y1)/2
    out += (f'<g transform="translate({tx:.1f} {ty:.1f})"><path d="{d}" fill="{NIGHT}"/>'
            + dot(*d1, dd, NIGHT) + dot(*d2, dd, CORAL, rot=68, cls='slip') + '</g>')
    return svg(S, S, out)
save('icon.svg', icon())
save('icon-maskable.svg', icon(full_bleed=True))
save('favicon.svg', icon(64, shadow=False))
print('ok', sorted(os.listdir(OUT)))
