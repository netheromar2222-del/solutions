// Writes the Excel files for editing the question bank:
//   bank/قالب-بنك-الأسئلة.xlsx      empty template with a few examples
//   bank/بنك-الأسئلة-الحالي.xlsx     the current server/data/questions.json, ready to edit and re-import
// Usage: npm run export-bank
const fs = require('fs');
const path = require('path');
const { writeXlsx } = require('./xlsx');
const { HEADER, HINT_MAX, MIN_PER_LEVEL, questionToRow } = require('./bank-format');
const { CATEGORIES, LEVEL_LABEL, normalizeQuestion } = require('../server/game/bank');

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'bank');
const WIDTHS = [14, 10, 34, 54, 22, 18, 18, 18, 18, 18, 18, 18];
const lists = [
  { col: 0, values: Object.values(CATEGORIES) },
  { col: 1, values: Object.values(LEVEL_LABEL) },
];

const instructions = [
  ['تعليمات بنك الأسئلة — لعبة ورطة'],
  [''],
  ['العمود', 'الشرح'],
  ['الفئة', `اختر من القائمة: ${Object.values(CATEGORIES).join('، ')}`],
  ['المستوى', 'سالكة (سهل) أو مطبّ (متوسط) أو ورطة (صعب)'],
  ['التلميح', `ما يراه صاحب الدور بدل السؤال. يكشف الموضوع لا الإجابة. من 3 إلى 8 كلمات، وبحد أقصى ${HINT_MAX} حرفاً.`],
  ['السؤال', 'نص السؤال كما يظهر للجميع.'],
  ['الإجابة الصحيحة', 'الإجابة الصحيحة فقط (لا تضعها في أعمدة الخطأ).'],
  ['خطأ 1 … خطأ 7', 'خيارات خاطئة مقنعة. الأفضل 7 (لأن المضيف قد يختار حتى 8 خيارات)، والحد الأدنى 3.'],
  [''],
  ['قاعدة التلميح', 'يكشف الموضوع لا الإجابة، ولا يحتوي الإجابة ولا أي خيار، وليس نسخة مختصرة من السؤال.'],
  ['مثال جيد', 'السؤال: من الخليفة العباسي الذي بنى بغداد؟ — التلميح: عن تأسيس مدينة عباسية شهيرة'],
  ['مثال سيئ', 'التلميح: عن المنصور (كشف الإجابة) — أو: عن التاريخ (لا يفيد)'],
  [''],
  ['الحد الأدنى', `${MIN_PER_LEVEL} أسئلة لكل فئة من كل مستوى، والمريح 30 أو أكثر حتى لا تتكرر الأسئلة.`],
  [''],
  ['الاستيراد', 'احفظ الملف ثم شغّل في مجلد اللعبة:  npm run import-bank -- "مسار الملف.xlsx"'],
  ['', 'للتحقق فقط بدون حفظ:  npm run import-bank -- "مسار الملف.xlsx" --check'],
  ['', 'بعد الاستيراد أعد تشغيل الخادم (npm start).'],
];

const examples = [
  ['تاريخ', 'ورطة', 'عن تأسيس مدينة عباسية شهيرة', 'من الخليفة العباسي الذي بنى بغداد؟', 'أبو جعفر المنصور', 'هارون الرشيد', 'المأمون', 'المعتصم', 'السفاح', 'المهدي', 'الأمين', 'المتوكل'],
  ['جغرافيا', 'سالكة', 'عن أنهار القارة السمراء', 'ما أطول نهر في أفريقيا؟', 'النيل', 'الكونغو', 'النيجر', 'الزامبيزي', 'أورانج', 'ليمبوبو', 'السنغال', 'الفولتا'],
  ['علوم', 'مطبّ', 'عن رموز العناصر الكيميائية', 'ما العنصر الذي رمزه الكيميائي Fe؟', 'الحديد', 'الفلور', 'الفضة', 'الرصاص', 'الفوسفور', 'النحاس', 'الزنك', 'القصدير'],
];

fs.mkdirSync(OUT, { recursive: true });
const book = (rows) =>
  writeXlsx([
    { name: 'الأسئلة', rows: [HEADER, ...rows], widths: WIDTHS, header: true, lists },
    { name: 'تعليمات', rows: instructions, widths: [18, 110] },
  ]);

const template = path.join(OUT, 'قالب-بنك-الأسئلة.xlsx');
fs.writeFileSync(template, book(examples));

const bank = JSON.parse(fs.readFileSync(path.join(ROOT, 'server', 'data', 'questions.json'), 'utf8')).map(normalizeQuestion);
const order = Object.keys(CATEGORIES);
bank.sort((a, b) => order.indexOf(a.category) - order.indexOf(b.category) || a.difficulty - b.difficulty);
const current = path.join(OUT, 'بنك-الأسئلة-الحالي.xlsx');
fs.writeFileSync(current, book(bank.map(questionToRow)));

console.log(`✓ ${path.relative(ROOT, template)}`);
console.log(`✓ ${path.relative(ROOT, current)}  (${bank.length} سؤالاً)`);
