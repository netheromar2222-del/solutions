// Shared rules for the question bank: Excel columns, Arabic normalisation and validation.
const crypto = require('crypto');
const { CATEGORIES, LEVELS, LEVEL_LABEL } = require('../server/game/bank');

const MAX_WRONG = 7; // 7 wrong + 1 correct = up to 8 options in a game
const MIN_WRONG = 3;
const HINT_MAX = 60;
const MIN_PER_LEVEL = 10;

const HEADER = ['الفئة', 'المستوى', 'التلميح', 'السؤال', 'الإجابة الصحيحة', ...Array.from({ length: MAX_WRONG }, (_, i) => `خطأ ${i + 1}`)];

/** Arabic-insensitive key: no tashkeel/tatweel, أإآٱ→ا, ة→ه, ى→ي, digits → Latin, no punctuation. */
function norm(s) {
  return String(s ?? '')
    .replace(/[ً-ٰٟـ]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .toLowerCase()
    .replace(/[«»"'“”‘’()\[\]{}؟?!.,،:;؛\-–—_/\\]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Words without the common attached prefixes (ال، وال، بال، لل…). */
function words(s) {
  return norm(s)
    .split(' ')
    .filter(Boolean)
    .map((w) => {
      const m = /^(وال|بال|فال|كال|لل|ال)(.{2,})$/.exec(w);
      return m ? m[2] : w;
    });
}

/** Does `text` contain `phrase` as whole words (in order)? */
function containsPhrase(text, phrase) {
  const t = words(text);
  const p = words(phrase);
  if (!p.length) return false;
  for (let i = 0; i + p.length <= t.length; i++) if (p.every((w, k) => t[i + k] === w)) return true;
  return false;
}

const CAT_BY_NAME = {};
for (const [key, label] of Object.entries(CATEGORIES)) {
  CAT_BY_NAME[norm(label)] = key;
  CAT_BY_NAME[norm(key)] = key;
}
CAT_BY_NAME[norm('سنة')] = 'sunnah';
CAT_BY_NAME[norm('السنة النبوية')] = 'sunnah';
CAT_BY_NAME[norm('القرآن')] = 'quran';
CAT_BY_NAME[norm('القرآن الكريم')] = 'quran';
CAT_BY_NAME[norm('أدب')] = 'literature';
CAT_BY_NAME[norm('لغة')] = 'literature';
CAT_BY_NAME[norm('الأدب واللغة')] = 'literature';

const LEVEL_BY_NAME = {};
for (const k of LEVELS) {
  LEVEL_BY_NAME[norm(LEVEL_LABEL[k])] = k;
  LEVEL_BY_NAME[norm(k)] = k;
}
LEVEL_BY_NAME[norm('مطب')] = 'matab';
LEVEL_BY_NAME[norm('سهل')] = 'salka';
LEVEL_BY_NAME[norm('متوسط')] = 'matab';
LEVEL_BY_NAME[norm('صعب')] = 'warta';
LEVEL_BY_NAME['1'] = 'salka';
LEVEL_BY_NAME['2'] = 'matab';
LEVEL_BY_NAME['3'] = 'warta';

function stableId(category, text) {
  return `q_${category}_${crypto.createHash('sha1').update(norm(text)).digest('hex').slice(0, 8)}`;
}

/** One Excel row → { question, errors[], warnings[] }. `line` is the Excel row number for messages. */
function rowToQuestion(row, line) {
  const cell = (i) => String(row[i] ?? '').trim();
  const errors = [];
  const warnings = [];
  const catRaw = cell(0);
  const lvlRaw = cell(1);
  const hint = cell(2);
  const text = cell(3);
  const answer = cell(4);
  const wrong = row
    .slice(5, 5 + MAX_WRONG)
    .map((x) => String(x ?? '').trim())
    .filter(Boolean);

  const category = CAT_BY_NAME[norm(catRaw)];
  const level = LEVEL_BY_NAME[norm(lvlRaw)];
  if (!catRaw) errors.push('الفئة فارغة');
  else if (!category) errors.push(`فئة غير معروفة «${catRaw}» (المتاح: ${Object.values(CATEGORIES).join('، ')})`);
  if (!lvlRaw) errors.push('المستوى فارغ');
  else if (!level) errors.push(`مستوى غير معروف «${lvlRaw}» (المتاح: سالكة، مطبّ، ورطة)`);
  if (!text) errors.push('نص السؤال فارغ');
  if (!answer) errors.push('الإجابة الصحيحة فارغة');
  if (!hint) errors.push('التلميح فارغ');

  if (wrong.length < MIN_WRONG) errors.push(`الخيارات الخاطئة ${wrong.length} فقط، والحد الأدنى ${MIN_WRONG}`);
  else if (wrong.length < MAX_WRONG) warnings.push(`فيه ${wrong.length} خيارات خاطئة من 7 (إن اختار المضيف خيارات أكثر سيظهر عدد أقل)`);

  const all = [answer, ...wrong].filter(Boolean);
  const seen = new Map();
  for (const o of all) {
    const k = norm(o);
    if (seen.has(k)) errors.push(o === answer || seen.get(k) === answer ? `خيار خاطئ مطابق للإجابة الصحيحة «${o}»` : `خيار مكرر «${o}»`);
    else seen.set(k, o);
  }

  if (hint) {
    if (hint.length > HINT_MAX) errors.push(`التلميح طويل (${hint.length} حرفاً، والحد ${HINT_MAX})`);
    if (answer && containsPhrase(hint, answer)) errors.push(`التلميح يكشف الإجابة «${answer}»`);
    const leaked = wrong.filter((o) => containsPhrase(hint, o));
    if (leaked.length) errors.push(`التلميح يحتوي خياراً: «${leaked.join('»، «')}»`);
    const hw = words(hint);
    if (hw.length < 2 || hw.length > 9) warnings.push(`التلميح ${hw.length} كلمات (الأفضل من 3 إلى 8)`);
    if (text) {
      const tw = new Set(words(text));
      const same = hw.filter((w) => tw.has(w)).length;
      if (norm(hint) === norm(text)) errors.push('التلميح هو نص السؤال نفسه');
      else if (hw.length >= 3 && same / hw.length >= 0.8) warnings.push('التلميح يكاد يكون نسخة من السؤال');
    }
  }
  if (text.length > 220) warnings.push(`السؤال طويل (${text.length} حرفاً) وقد لا يتسع على شاشة الجوال`);

  const question =
    errors.length === 0
      ? { id: stableId(category, text), category, level, hint, text, options: [answer, ...wrong], answer: 0 }
      : null;
  return { question, errors, warnings, line };
}

/** Bank question → Excel row. */
function questionToRow(q) {
  const lvl = q.level || LEVELS[(q.difficulty || 2) - 1];
  const opts = q.options.slice();
  const ans = opts.splice(q.answer, 1)[0];
  return [CATEGORIES[q.category] || q.category, LEVEL_LABEL[lvl], q.hint || '', q.text, ans, ...opts.slice(0, MAX_WRONG)];
}

/** Validate a whole sheet (rows include the header). */
function validateRows(rows) {
  const results = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i] || [];
    if (!r.some((c) => String(c ?? '').trim())) continue; // blank line
    results.push(rowToQuestion(r, i + 1));
  }
  // Duplicate questions across the file
  const byText = new Map();
  for (const res of results) {
    if (!res.question) continue;
    const k = norm(res.question.text);
    if (byText.has(k)) {
      res.errors.push(`سؤال مكرر (نفس السطر ${byText.get(k)})`);
      res.question = null;
    } else byText.set(k, res.line);
  }
  const questions = results.filter((r) => r.question).map((r) => r.question);
  const counts = {};
  for (const c of Object.keys(CATEGORIES)) counts[c] = { salka: 0, matab: 0, warta: 0 };
  for (const q of questions) counts[q.category][q.level] += 1;
  return { results, questions, counts };
}

module.exports = { HEADER, MAX_WRONG, MIN_WRONG, HINT_MAX, MIN_PER_LEVEL, norm, words, containsPhrase, rowToQuestion, questionToRow, validateRows };
