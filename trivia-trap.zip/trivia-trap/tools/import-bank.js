// Imports the question bank from Excel into server/data/questions.json, after checking every row.
// Usage:
//   npm run import-bank -- "path/to/file.xlsx"            check, then save if there are no errors
//   npm run import-bank -- "path/to/file.xlsx" --check    check only, save nothing
//   npm run import-bank -- "path/to/file.xlsx" --skip-bad save the valid rows even if some rows have errors
const fs = require('fs');
const path = require('path');
const { readXlsx } = require('./xlsx');
const { MIN_PER_LEVEL, validateRows, norm } = require('./bank-format');
const { CATEGORIES } = require('../server/game/bank');

const ROOT = path.join(__dirname, '..');
const DEST = path.join(ROOT, 'server', 'data', 'questions.json');

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith('--'));
const checkOnly = args.includes('--check');
const skipBad = args.includes('--skip-bad');

if (!file) {
  console.log('الاستخدام: npm run import-bank -- "مسار ملف الإكسل.xlsx" [--check] [--skip-bad]');
  process.exit(1);
}
if (!fs.existsSync(file)) {
  console.log(`✗ لم أجد الملف: ${file}`);
  process.exit(1);
}

let sheets;
try {
  sheets = readXlsx(fs.readFileSync(file));
} catch (e) {
  console.log(`✗ تعذّرت قراءة الملف: ${e.message}`);
  process.exit(1);
}
const name = Object.keys(sheets).find((n) => norm(n) === norm('الأسئلة')) || Object.keys(sheets)[0];
const rows = sheets[name] || [];
const { results, questions, counts } = validateRows(rows);

const bad = results.filter((r) => r.errors.length);
const warned = results.filter((r) => !r.errors.length && r.warnings.length);

console.log(`\nالملف: ${path.basename(file)} · الورقة: ${name}`);
console.log(`الأسطر: ${results.length} · سليمة: ${questions.length} · مرفوضة: ${bad.length} · بتنبيهات: ${warned.length}\n`);

if (bad.length) {
  console.log('✗ أسطر مرفوضة (أصلحها في الإكسل):');
  for (const r of bad) console.log(`  السطر ${r.line}: ${r.errors.join(' · ')}`);
  console.log('');
}
if (warned.length) {
  console.log('⚠ تنبيهات (السؤال مقبول):');
  for (const r of warned) console.log(`  السطر ${r.line}: ${r.warnings.join(' · ')}`);
  console.log('');
}

console.log('عدد الأسئلة لكل فئة:');
console.log('  الفئة            سالكة  مطبّ  ورطة');
const thin = [];
for (const [key, label] of Object.entries(CATEGORIES)) {
  const c = counts[key];
  const total = c.salka + c.matab + c.warta;
  if (!total) continue;
  console.log(`  ${label.padEnd(16)} ${String(c.salka).padStart(5)} ${String(c.matab).padStart(5)} ${String(c.warta).padStart(5)}`);
  for (const [k, lbl] of [['salka', 'سالكة'], ['matab', 'مطبّ'], ['warta', 'ورطة']]) if (c[k] < MIN_PER_LEVEL) thin.push(`${label}/${lbl} (${c[k]})`);
}
if (thin.length) console.log(`\n⚠ أقل من ${MIN_PER_LEVEL} أسئلة: ${thin.join('، ')}`);
console.log('');

if (checkOnly) {
  console.log(bad.length ? '✗ التحقق انتهى وفيه أخطاء. لم يُحفظ شيء.' : '✓ التحقق ناجح. لم يُحفظ شيء (وضع --check).');
  process.exit(bad.length ? 1 : 0);
}
if (bad.length && !skipBad) {
  console.log('✗ لم يُحفظ شيء بسبب الأسطر المرفوضة. أصلحها وأعد الاستيراد، أو أضف --skip-bad لحفظ السليمة فقط.');
  process.exit(1);
}
if (!questions.length) {
  console.log('✗ لا توجد أسئلة سليمة للحفظ.');
  process.exit(1);
}
if (fs.existsSync(DEST)) fs.copyFileSync(DEST, DEST.replace(/\.json$/, '.backup.json'));
fs.writeFileSync(DEST, JSON.stringify(questions, null, 2) + '\n');
console.log(`✓ حُفظ ${questions.length} سؤالاً في server/data/questions.json (والنسخة السابقة في questions.backup.json).`);
console.log('  أعد تشغيل الخادم (npm start) لتظهر الأسئلة الجديدة.');
